-- ============================================================
-- GymHub Database Schema
-- Course Project - PHP & MySQL Web Application
-- ============================================================

-- ============================================================
-- TABLE: users
-- Stores all registered users (members and admins)
-- ============================================================
CREATE TABLE users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,          -- bcrypt hashed
    role        ENUM('member','admin') NOT NULL DEFAULT 'member',
    avatar      VARCHAR(255) DEFAULT 'default-avatar.png',
    phone       VARCHAR(20)  DEFAULT NULL,
    status      ENUM('active','disabled') NOT NULL DEFAULT 'active',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- TABLE: memberships
-- The 3 membership tier products users can subscribe to
-- ============================================================
CREATE TABLE memberships (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50)   NOT NULL,
    price       DECIMAL(8,2)  NOT NULL,
    duration    INT           NOT NULL,         -- duration in days
    features    TEXT          NOT NULL,         -- JSON array of feature strings
    status      ENUM('active','inactive') NOT NULL DEFAULT 'active'
);

-- ============================================================
-- TABLE: user_memberships
-- Links users to their purchased membership tier
-- ============================================================
CREATE TABLE user_memberships (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT  NOT NULL,
    membership_id INT  NOT NULL,
    start_date    DATE NOT NULL,
    end_date      DATE NOT NULL,
    FOREIGN KEY (user_id)       REFERENCES users(id)       ON DELETE CASCADE,
    FOREIGN KEY (membership_id) REFERENCES memberships(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: instructors
-- Instructor profiles (linked to a user account)
-- ============================================================
CREATE TABLE instructors (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT          NOT NULL,
    bio          TEXT         DEFAULT NULL,
    specialties  VARCHAR(255) DEFAULT NULL,
    photo        VARCHAR(255) DEFAULT 'default-instructor.png',
    rating       DECIMAL(3,2) DEFAULT 0.00,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: classes
-- The 20 fitness class "products" offered by GymHub
-- Each class has one option type with two choices (option_a / option_b)
-- ============================================================
CREATE TABLE classes (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    title         VARCHAR(100)  NOT NULL,
    category      VARCHAR(50)   NOT NULL,
    description   TEXT          NOT NULL,
    instructor_id INT           DEFAULT NULL,
    capacity      INT           NOT NULL DEFAULT 20,
    duration_min  INT           NOT NULL,       -- class length in minutes
    price         DECIMAL(8,2)  NOT NULL,       -- base price per session
    option_label  VARCHAR(50)   NOT NULL,       -- e.g. "Level", "Style", "Format"
    option_a      VARCHAR(50)   NOT NULL,       -- e.g. "Beginner"
    option_b      VARCHAR(50)   NOT NULL,       -- e.g. "Advanced"
    image         VARCHAR(255)  DEFAULT 'default-class.jpg',
    video_url     VARCHAR(255)  DEFAULT NULL,
    status        ENUM('active','inactive') NOT NULL DEFAULT 'active',
    FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE SET NULL
);

-- ============================================================
-- TABLE: class_schedule
-- Scheduled sessions for each class (date + time slots)
-- ============================================================
CREATE TABLE class_schedule (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    class_id    INT         NOT NULL,
    date        DATE        NOT NULL,
    time        TIME        NOT NULL,
    room        VARCHAR(50) DEFAULT 'Main Floor',
    spots_left  INT         NOT NULL DEFAULT 20,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: bookings
-- Records each user booking a scheduled class session
-- ============================================================
CREATE TABLE bookings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT  NOT NULL,
    schedule_id INT  NOT NULL,
    option_choice VARCHAR(50) NOT NULL,         -- which option (a or b) the user picked
    status      ENUM('confirmed','cancelled','completed') NOT NULL DEFAULT 'confirmed',
    booked_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)     REFERENCES users(id)           ON DELETE CASCADE,
    FOREIGN KEY (schedule_id) REFERENCES class_schedule(id)  ON DELETE CASCADE
);

-- ============================================================
-- TABLE: ratings
-- User ratings and reviews for classes
-- ============================================================
CREATE TABLE ratings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT           NOT NULL,
    class_id    INT           NOT NULL,
    stars       TINYINT       NOT NULL CHECK (stars BETWEEN 1 AND 5),
    comment     TEXT          DEFAULT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_rating (user_id, class_id),  -- one rating per user per class
    FOREIGN KEY (user_id)  REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(id)  ON DELETE CASCADE
);

-- ============================================================
-- TABLE: questions
-- User-submitted questions to trainers
-- ============================================================
CREATE TABLE questions (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT          NOT NULL,
    title       VARCHAR(200) NOT NULL,
    body        TEXT         NOT NULL,
    attachment  VARCHAR(255) DEFAULT NULL,       -- optional file upload path
    status      ENUM('open','answered','closed') NOT NULL DEFAULT 'open',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: answers
-- Admin/trainer responses to user questions
-- ============================================================
CREATE TABLE answers (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    question_id INT  NOT NULL,
    admin_id    INT  NOT NULL,
    body        TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id)    REFERENCES users(id)     ON DELETE CASCADE
);

-- ============================================================
-- TABLE: locations
-- Physical gym locations shown on interactive map
-- ============================================================
CREATE TABLE locations (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)   NOT NULL,
    address     VARCHAR(255)   NOT NULL,
    city        VARCHAR(100)   NOT NULL,
    lat         DECIMAL(10,7)  NOT NULL,
    lng         DECIMAL(10,7)  NOT NULL,
    phone       VARCHAR(20)    DEFAULT NULL,
    hours       VARCHAR(255)   DEFAULT NULL,
    photo       VARCHAR(255)   DEFAULT 'default-location.jpg'
);

-- ============================================================
-- TABLE: progress
-- User fitness progress log (for data visualization charts)
-- ============================================================
CREATE TABLE progress (
    id                INT  AUTO_INCREMENT PRIMARY KEY,
    user_id           INT  NOT NULL,
    log_date          DATE NOT NULL,
    weight_kg         DECIMAL(5,2) DEFAULT NULL,
    sessions_attended INT          DEFAULT 0,
    notes             TEXT         DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
-- TABLE: site_settings
-- Controls active theme and maintenance mode (admin use)
-- ============================================================
CREATE TABLE site_settings (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    setting_key      VARCHAR(50)  NOT NULL UNIQUE,
    setting_value    VARCHAR(255) NOT NULL,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- Admin user (password: Admin@123)
INSERT INTO users (first_name, last_name, email, password, role) VALUES
('Admin', 'GymHub', 'admin@gymhub.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Sample member users (password: Password@1)
INSERT INTO users (first_name, last_name, email, password, role, phone) VALUES
('James',   'Carter',   'james@example.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member', '555-0101'),
('Sofia',   'Martinez', 'sofia@example.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member', '555-0102'),
('Liam',    'Nguyen',   'liam@example.com',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member', '555-0103'),
('Amara',   'Osei',     'amara@example.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member', '555-0104'),
('Noah',    'Kim',      'noah@example.com',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member', '555-0105');

-- Membership tiers
INSERT INTO memberships (name, price, duration, features) VALUES
('Basic',    29.99, 30,  '["Access to all group classes","Locker room access","1 guest pass/month"]'),
('Pro',      59.99, 30,  '["Everything in Basic","Unlimited class bookings","Access to all locations","2 guest passes/month","Free towel service"]'),
('Elite',    99.99, 30,  '["Everything in Pro","Personal trainer session/month","Nutrition consultation","Priority booking","Exclusive Elite lounge"]');

-- Instructor users (password: Password@1)
INSERT INTO users (first_name, last_name, email, password, role) VALUES
('Marcus',  'Reid',    'marcus@gymhub.com',  '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member'),
('Priya',   'Sharma',  'priya@gymhub.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member'),
('Dante',   'Flores',  'dante@gymhub.com',   '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member'),
('Yuki',    'Tanaka',  'yuki@gymhub.com',    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'member');

-- Instructor profiles
INSERT INTO instructors (user_id, bio, specialties, rating) VALUES
(7,  'Marcus is a certified strength coach with 10 years of experience in powerlifting and functional fitness.', 'Strength, CrossFit, Boot Camp', 4.90),
(8,  'Priya brings calm and precision to every class, trained in Hatha and Vinyasa yoga across India and Canada.', 'Yoga, Pilates, Meditation', 4.95),
(9,  'Dante is a former kickboxing champion who channels competitive energy into dynamic group classes.', 'Kickboxing, Boxing, Martial Arts', 4.85),
(10, 'Yuki specializes in low-impact and recovery-focused training with a background in sports physiotherapy.', 'Aqua Aerobics, Stretch & Recover, Senior Fit', 4.80);

-- ============================================================
-- 20 FITNESS CLASSES (products) with one option pair each
-- ============================================================
INSERT INTO classes (title, category, description, instructor_id, capacity, duration_min, price, option_label, option_a, option_b, image) VALUES
(
  'Power Lifting',
  'Strength',
  'Build raw strength using barbells, squat racks, and progressive overload techniques. Coached by certified strength specialists.',
  1, 15, 60, 18.00, 'Level', 'Beginner', 'Advanced', 'class-powerlifting.jpg'
),
(
  'HIIT Blast',
  'Cardio',
  'High-intensity interval training designed to torch calories and boost cardiovascular endurance in a short, powerful session.',
  1, 20, 45, 15.00, 'Duration', '30 min', '60 min', 'class-hiit.jpg'
),
(
  'Yoga Flow',
  'Yoga',
  'A fluid, breath-led yoga practice linking movement and mindfulness. Suitable for all levels seeking balance and flexibility.',
  2, 18, 60, 14.00, 'Session Time', 'Morning', 'Evening', 'class-yoga.jpg'
),
(
  'Spin Cycle',
  'Cardio',
  'High-energy indoor cycling class with pumping music and a coach guiding you through climbs, sprints, and recoveries.',
  1, 20, 45, 16.00, 'Ride Style', 'Endurance', 'Interval', 'class-spin.jpg'
),
(
  'Boxing Fundamentals',
  'Combat',
  'Learn proper stance, footwork, and punching combinations in a structured boxing class. All skill levels welcome.',
  3, 16, 60, 17.00, 'Equipment', 'Gloves Included', 'Own Gear', 'class-boxing.jpg'
),
(
  'Pilates Core',
  'Pilates',
  'Targeted core strengthening and postural alignment exercises rooted in classical Pilates methodology.',
  2, 12, 50, 16.00, 'Format', 'Mat', 'Reformer', 'class-pilates.jpg'
),
(
  'Zumba Party',
  'Dance',
  'A feel-good dance fitness class blending Latin and global rhythms into a full-body cardio workout.',
  2, 25, 45, 13.00, 'Music Style', 'Latin', 'Hip-Hop', 'class-zumba.jpg'
),
(
  'CrossFit WOD',
  'CrossFit',
  'Workout of the Day — constantly varied functional movements performed at high intensity. Community-driven and coach-led.',
  1, 16, 60, 19.00, 'Intensity', 'Scaled', 'Rx', 'class-crossfit.jpg'
),
(
  'Aqua Aerobics',
  'Swimming',
  'Pool-based aerobic exercise that is easy on the joints but highly effective for cardio and toning.',
  4, 20, 45, 14.00, 'Intensity', 'Low Impact', 'High Impact', 'class-aqua.jpg'
),
(
  'Kickboxing',
  'Combat',
  'Combine martial arts techniques with fast-paced cardio. Improve coordination, power, and confidence with every session.',
  3, 18, 60, 17.00, 'Level', 'Beginner', 'Advanced', 'class-kickboxing.jpg'
),
(
  'Stretch & Recover',
  'Recovery',
  'Guided stretching and mobility work to reduce muscle soreness, improve flexibility, and accelerate recovery between workouts.',
  4, 15, 45, 12.00, 'Focus Area', 'Full Body', 'Target Area', 'class-stretch.jpg'
),
(
  'Boot Camp',
  'Strength',
  'Military-inspired full-body conditioning using bodyweight, resistance bands, and functional equipment.',
  1, 20, 60, 16.00, 'Environment', 'Indoor', 'Outdoor', 'class-bootcamp.jpg'
),
(
  'Barre Fusion',
  'Dance',
  'Ballet-inspired workout at the barre that sculpts and tones the entire body with precise, controlled movements.',
  2, 15, 50, 15.00, 'Style', 'Classic', 'Cardio Barre', 'class-barre.jpg'
),
(
  'Meditation & Breathwork',
  'Wellness',
  'Guided sessions combining mindfulness meditation with breathwork techniques to reduce stress and improve mental clarity.',
  2, 20, 40, 12.00, 'Session Type', 'Guided', 'Silent', 'class-meditation.jpg'
),
(
  'TRX Suspension',
  'Strength',
  'Leverage bodyweight and gravity using TRX suspension straps to build strength, balance, flexibility, and core stability.',
  1, 14, 50, 16.00, 'Focus', 'Upper Body', 'Full Body', 'class-trx.jpg'
),
(
  'Functional Fitness',
  'Strength',
  'Train movements, not just muscles. This class improves everyday functional strength, mobility, and coordination.',
  1, 18, 55, 15.00, 'Focus', 'Mobility', 'Strength', 'class-functional.jpg'
),
(
  'Martial Arts',
  'Combat',
  'Traditional martial arts fundamentals covering discipline, technique, and self-defence across multiple styles.',
  3, 20, 60, 17.00, 'Age Group', 'Kids', 'Adults', 'class-martialarts.jpg'
),
(
  'Senior Fit',
  'Wellness',
  'Low-impact fitness program tailored for older adults, focusing on balance, flexibility, strength, and social connection.',
  4, 20, 45, 12.00, 'Format', 'Chair-Based', 'Standing', 'class-seniorfit.jpg'
),
(
  'Prenatal Yoga',
  'Yoga',
  'Safe and nurturing yoga practice designed for expectant mothers at all stages of pregnancy. Always consult your doctor first.',
  2, 10, 50, 15.00, 'Trimester', 'Gentle', 'Active', 'class-prenatal.jpg'
),
(
  'Kids Sport Camp',
  'Kids',
  'Fun, active, and structured sports sessions that develop coordination, teamwork, and a love of movement in young athletes.',
  3, 20, 60, 14.00, 'Age Group', 'Ages 5-8', 'Ages 9-12', 'class-kids.jpg'
);

-- ============================================================
-- GYM LOCATIONS
-- ============================================================
INSERT INTO locations (name, address, city, lat, lng, phone, hours) VALUES
('GymHub Downtown',   '123 King St W',        'Windsor',  42.3149, -83.0364, '519-555-0201', 'Mon-Fri 5am-11pm | Sat-Sun 7am-9pm'),
('GymHub Westside',   '456 Tecumseh Rd W',    'Windsor',  42.3081, -83.0700, '519-555-0202', 'Mon-Fri 6am-10pm | Sat-Sun 8am-8pm'),
('GymHub Riverside',  '789 Riverside Dr E',   'Windsor',  42.3224, -83.0145, '519-555-0203', 'Mon-Sun 6am-10pm');

-- ============================================================
-- SITE SETTINGS (theme + maintenance flag)
-- ============================================================
INSERT INTO site_settings (setting_key, setting_value) VALUES
('active_theme',      'powerzone'),
('maintenance_mode',  'off'),
('site_name',         'GymHub'),
('contact_email',     'info@gymhub.com');

-- ============================================================
-- SAMPLE CLASS SCHEDULE (next 7 days)
-- ============================================================
INSERT INTO class_schedule (class_id, date, time, room, spots_left) VALUES
(1,  DATE_ADD(CURDATE(), INTERVAL 1 DAY), '07:00:00', 'Weight Room',   12),
(2,  DATE_ADD(CURDATE(), INTERVAL 1 DAY), '08:00:00', 'Studio A',      15),
(3,  DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00:00', 'Studio B',      10),
(4,  DATE_ADD(CURDATE(), INTERVAL 1 DAY), '06:30:00', 'Spin Room',     18),
(5,  DATE_ADD(CURDATE(), INTERVAL 2 DAY), '10:00:00', 'Boxing Ring',   12),
(6,  DATE_ADD(CURDATE(), INTERVAL 2 DAY), '11:00:00', 'Studio B',       8),
(7,  DATE_ADD(CURDATE(), INTERVAL 2 DAY), '18:00:00', 'Studio A',      20),
(8,  DATE_ADD(CURDATE(), INTERVAL 3 DAY), '07:00:00', 'Main Floor',    14),
(9,  DATE_ADD(CURDATE(), INTERVAL 3 DAY), '10:00:00', 'Pool',          16),
(10, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '19:00:00', 'Boxing Ring',   15),
(11, DATE_ADD(CURDATE(), INTERVAL 4 DAY), '08:00:00', 'Studio B',      12),
(12, DATE_ADD(CURDATE(), INTERVAL 4 DAY), '06:00:00', 'Outdoor Pad',   18),
(13, DATE_ADD(CURDATE(), INTERVAL 4 DAY), '17:30:00', 'Studio A',      14),
(14, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '07:30:00', 'Wellness Room', 20),
(15, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '09:00:00', 'TRX Zone',      12),
(16, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '18:00:00', 'Main Floor',    16),
(17, DATE_ADD(CURDATE(), INTERVAL 6 DAY), '10:00:00', 'Dojo',          18),
(18, DATE_ADD(CURDATE(), INTERVAL 6 DAY), '11:00:00', 'Studio B',      20),
(19, DATE_ADD(CURDATE(), INTERVAL 7 DAY), '09:30:00', 'Studio A',       8),
(20, DATE_ADD(CURDATE(), INTERVAL 7 DAY), '14:00:00', 'Main Floor',    20);

-- ============================================================
-- SAMPLE RATINGS
-- ============================================================
INSERT INTO ratings (user_id, class_id, stars, comment) VALUES
(2, 1,  5, 'Marcus is an incredible coach. Felt stronger after just 3 sessions!'),
(3, 3,  5, 'Priya''s yoga class is so peaceful and grounding. My favourite class.'),
(4, 5,  4, 'Great boxing intro. Would love even more technique drills.'),
(5, 2,  5, 'HIIT Blast is no joke — best cardio workout I have ever had.'),
(6, 8,  4, 'CrossFit WOD really pushes your limits. Amazing community vibe.'),
(2, 7,  5, 'Zumba is so much fun, I don''t even feel like I''m working out!'),
(3, 14, 5, 'The meditation session helped me manage stress massively.'),
(4, 10, 4, 'Kickboxing is challenging but Dante makes it feel achievable.');

-- ============================================================
-- SAMPLE QUESTIONS
-- ============================================================
INSERT INTO questions (user_id, title, body, status) VALUES
(2, 'Which class is best for weight loss?',        'Hi, I am new to the gym and looking to lose about 15 lbs. Which class would you recommend I start with?', 'answered'),
(3, 'Can I do yoga if I have lower back pain?',    'I have a mild herniated disc. Is yoga safe for me? Are there modifications available?', 'answered'),
(4, 'Do I need my own boxing gloves?',             'I signed up for Boxing Fundamentals. Should I buy my own gloves or are they sanitized and provided?', 'open'),
(5, 'Is CrossFit suitable for complete beginners?','I have never done CrossFit. I am worried it might be too intense. What should I know before signing up?', 'open');

-- Sample answers
INSERT INTO answers (question_id, admin_id, body) VALUES
(1, 1, 'Welcome to GymHub! For weight loss we recommend starting with HIIT Blast or Boot Camp — both are high-calorie-burn classes. Pair with Stretch & Recover on rest days. Our Pro membership gives you unlimited bookings so you can mix and match freely!'),
(2, 1, 'Great question. Yoga is actually wonderful for lower back support when done correctly. Please let Priya know about your condition before class — she will provide modifications. We also recommend our Stretch & Recover class as a gentle starting point.');

-- ============================================================
-- END OF GYMHUB.SQL
-- ============================================================
