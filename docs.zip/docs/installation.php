<?php
/**
 * GymHub - Wiki: Installation Guide
 * wiki/installation.php
 *
 * Step-by-step guide for installing GymHub on a new web server.
 * Fifth and final of the 5 required wiki/help pages.
 *
 * WIKI REQUIREMENT: One of five required help documentation pages.
 * INSTALLATION DOCUMENTATION REQUIREMENT: This page satisfies the
 * "Installation documentation (how can someone install your app
 * on a different website?)" requirement from the project spec.
 *
 * Content covers:
 *   - Server requirements (PHP, MySQL versions)
 *   - Downloading the source code from GitHub
 *   - Uploading files to the server
 *   - Creating and importing the database
 *   - Configuring the database credentials
 *   - Creating the first admin account
 *   - Troubleshooting common issues
 *
 * No database queries needed — static content only.
 */

$page_title       = 'Installation Guide | GymHub Help';
$page_description = 'How to install GymHub on a new web server. Full step-by-step guide covering requirements, file upload, database setup, and configuration.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help Wiki</span>
        <h1>Installation Guide</h1>
        <p>How to install GymHub on a new web server from scratch.</p>
    </div>
</section>

<section class="wiki-page section-pad">
    <div class="container">
        <div class="wiki-grid">

            <!-- ── Sidebar navigation ── -->
            <nav class="wiki-nav">
                <h4>Help Pages</h4>
                <ul>
                    <li><a href="getting-started.php">🚀 Getting Started</a></li>
                    <li><a href="booking-guide.php">📅 Booking Guide</a></li>
                    <li><a href="account-help.php">👤 Account Help</a></li>
                    <li><a href="admin-guide.php">⚙️ Admin Guide</a></li>
                    <li class="active"><a href="installation.php">🛠 Installation</a></li>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="<?= SITE_URL ?>/docs/database.php">📊 Database Schema</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/contact.php">📧 Contact Support</a></li>
                    </ul>
                </div>
            </nav>

            <!-- ── Main content ── -->
            <div class="wiki-content">

                <p class="wiki-intro">
                    GymHub is a PHP/MySQL web application. This guide explains how to set it up
                    on any standard web hosting account in about 10 minutes.
                </p>

                <!-- Requirements -->
                <h2>Server Requirements</h2>
                <p>Before installing, make sure your hosting account supports:</p>
                <ul class="wiki-list">
                    <li><strong>PHP 8.0 or higher</strong> — GymHub uses PHP 8.0+ syntax (match expressions, named arguments)</li>
                    <li><strong>MySQL 5.7 or higher</strong> (or MariaDB 10.3+)</li>
                    <li><strong>PDO and PDO_MySQL</strong> PHP extensions enabled</li>
                    <li><strong>File uploads enabled</strong> — needed for trainer Q&amp;A attachments</li>
                    <li>Standard shared hosting (cPanel, Plesk) works perfectly</li>
                </ul>

                <div class="wiki-callout">
                    <h4>✅ Tested On</h4>
                    <p>GymHub has been tested and confirmed working on uWindsor myweb.cs.uwindsor.ca
                    shared hosting with PHP 8.x and MySQL.</p>
                </div>

                <!-- Step 1: Download -->
                <h2 style="margin-top:var(--space-2xl);">Step-by-Step Installation</h2>

                <div class="wiki-step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Download the Source Code</h3>
                        <p>
                            Download the latest GymHub source code from GitHub.
                            Click the green <strong>Code</strong> button → <strong>Download ZIP</strong>.
                            Extract the ZIP file on your computer.
                        </p>
                        <p>
                            Alternatively, if you have Git installed, clone the repository:
                        </p>
                        <div class="code-block">
                            <code>git clone https://github.com/seehrar/gymhub.git</code>
                        </div>
                    </div>
                </div>

                <!-- Step 2: Upload files -->
                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Upload Files to Your Server</h3>
                        <p>
                            Using your hosting file manager or an FTP client (like FileZilla):
                        </p>
                        <ul class="wiki-list">
                            <li>Navigate to your public web directory (e.g. <code>public_html/</code> or <code>www/</code>)</li>
                            <li>Create a subfolder for the project (e.g. <code>gymhub/</code>) or upload to the root</li>
                            <li>Upload all the GymHub files and folders into that directory</li>
                            <li>Make sure the folder structure is preserved — <code>config/</code>, <code>pages/</code>, <code>admin/</code>, etc.</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 3: Create database -->
                <div class="wiki-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Create the Database</h3>
                        <p>
                            Log in to your hosting control panel (cPanel or phpMyAdmin directly):
                        </p>
                        <ul class="wiki-list">
                            <li>Create a new MySQL database — name it something like <code>yourname_gymhub</code></li>
                            <li>Create a database user with a strong password</li>
                            <li>Grant the user <strong>All Privileges</strong> on the new database</li>
                        </ul>
                    </div>
                </div>

                <!-- Step 4: Import SQL -->
                <div class="wiki-step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h3>Import the Database Schema</h3>
                        <p>
                            Open <strong>phpMyAdmin</strong> and select your newly created database.
                        </p>
                        <ul class="wiki-list">
                            <li>Click the <strong>Import</strong> tab at the top</li>
                            <li>Click <strong>Choose File</strong> and select <code>sql/gymhub.sql</code> from the project files you downloaded</li>
                            <li>Click <strong>Import</strong> at the bottom</li>
                        </ul>
                        <p>
                            This creates all 13 tables and inserts seed data including
                            sample classes, users, and settings.
                        </p>
                    </div>
                </div>

                <!-- Step 5: Configure -->
                <div class="wiki-step">
                    <div class="step-number">5</div>
                    <div class="step-content">
                        <h3>Configure Database Credentials</h3>
                        <p>
                            Open <code>config/db.php</code> in a text editor and update
                            these four lines to match your hosting credentials:
                        </p>
                        <div class="code-block">
<pre><code>define('DB_HOST', 'localhost');
define('DB_NAME', 'yourname_gymhub');   // your database name
define('DB_USER', 'yourname');          // your database username
define('DB_PASS', 'your_password');     // your database password
define('SITE_URL', 'https://your-domain.com/gymhub'); // no trailing slash</code></pre>
                        </div>
                        <p>
                            <strong>SITE_URL</strong> must be the full URL to the folder where
                            you uploaded the files. No trailing slash at the end.
                        </p>
                    </div>
                </div>

                <!-- Step 6: Create admin -->
                <div class="wiki-step">
                    <div class="step-number">6</div>
                    <div class="step-content">
                        <h3>Create Your Admin Account</h3>
                        <p>Two ways to create an admin account:</p>
                        <p><strong>Option A (recommended):</strong> Register a normal account at
                        <code>/pages/register.php</code>, then open phpMyAdmin → users table →
                        find your row → change the <code>role</code> column from <code>member</code>
                        to <code>admin</code>.</p>
                        <p><strong>Option B:</strong> Run this SQL in phpMyAdmin, replacing the values:</p>
                        <div class="code-block">
<pre><code>INSERT INTO users (first_name, last_name, email, password, role, status)
VALUES (
  'Admin', 'User',
  'admin@yoursite.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uSc/kei',
  'admin', 'active'
);
-- Default password is: password
-- Change it immediately after logging in!</code></pre>
                        </div>
                    </div>
                </div>

                <!-- Step 7: Visit site -->
                <div class="wiki-step">
                    <div class="step-number">7</div>
                    <div class="step-content">
                        <h3>Visit Your Site</h3>
                        <p>
                            Open a browser and go to your SITE_URL.
                            You should see the GymHub homepage.
                            Log in with your admin account to access the admin panel.
                        </p>
                        <p>
                            If you see a database error, double-check the credentials in
                            <code>config/db.php</code> and make sure the SQL was imported successfully.
                        </p>
                    </div>
                </div>

                <!-- Troubleshooting -->
                <h2 style="margin-top:var(--space-2xl);">Troubleshooting</h2>

                <div class="faq-list">

                    <div class="faq-item">
                        <div class="faq-q">❓ I see a blank white page</div>
                        <p class="faq-a">Enable PHP error reporting or check your server's error log. Most likely cause: incorrect database credentials in <code>config/db.php</code>.</p>
                    </div>

                    <div class="faq-item">
                        <div class="faq-q">❓ CSS and images aren't loading</div>
                        <p class="faq-a">The <code>SITE_URL</code> in <code>config/db.php</code> is wrong. Check it matches the exact URL you're visiting. Right-click any image → Inspect to see the URL it's trying to load.</p>
                    </div>

                    <div class="faq-item">
                        <div class="faq-q">❓ Login redirects me in a loop</div>
                        <p class="faq-a">Make sure <code>ob_start()</code> is at the top of <code>config/db.php</code> and that PHP sessions are enabled on your hosting. On some servers you may need to set a custom session save path.</p>
                    </div>

                    <div class="faq-item">
                        <div class="faq-q">❓ File uploads aren't working</div>
                        <p class="faq-a">Check that <code>public/assets/uploads/</code> exists and is writable (chmod 755). PHP's <code>upload_max_filesize</code> must be at least 5MB.</p>
                    </div>

                    <div class="faq-item">
                        <div class="faq-q">❓ The schedule page is empty</div>
                        <p class="faq-a">The seed data includes schedule entries that may have expired. Run the schedule refresh SQL from the project README to insert new sessions starting from today.</p>
                    </div>

                </div>

                <!-- Page navigation -->
                <div class="wiki-nav-btns">
                    <a href="admin-guide.php" class="btn btn-secondary">← Admin Guide</a>
                    <a href="<?= SITE_URL ?>/docs/database.php" class="btn btn-secondary">Database Schema →</a>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.wiki-intro{color:var(--color-text-light);font-size:1.05rem;line-height:1.8;margin-bottom:var(--space-2xl);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.wiki-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.6rem;margin:var(--space-md) 0 var(--space-lg)}
.wiki-list li{color:var(--color-text-light);font-size:.95rem;line-height:1.7}
.wiki-list strong{color:var(--color-text)}
.code-block{background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-md);margin:var(--space-md) 0;overflow-x:auto}
.code-block code,.code-block pre{font-family:monospace;font-size:.85rem;color:var(--color-accent);white-space:pre-wrap;word-break:break-all}
.code-block pre{margin:0}
code{background:var(--color-surface-2);border:1px solid var(--color-border);padding:.15rem .5rem;border-radius:3px;font-size:.85rem;color:var(--color-accent);font-family:monospace}
.faq-list{display:flex;flex-direction:column;gap:var(--space-md)}
.faq-item{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.faq-q{font-weight:700;color:var(--color-text);margin-bottom:var(--space-sm)}
.faq-a{color:var(--color-text-light);font-size:.9rem;line-height:1.7;margin:0}
.wiki-nav-btns{display:flex;justify-content:space-between;margin-top:var(--space-2xl);padding-top:var(--space-xl);border-top:1px solid var(--color-border)}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
