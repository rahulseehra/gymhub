<?php
/**
 * GymHub - Database Documentation
 * docs/database.php
 *
 * Visual reference of the full GymHub MySQL database schema.
 *
 * REQUIREMENT 5: This page satisfies the "MySQL database design included"
 * documentation requirement. It shows every table, every column, its
 * data type, constraints, and a plain-English description.
 *
 * What this page shows:
 *   - Live record counts pulled from the database in real time
 *   - Entity relationship summary (which tables JOIN to which)
 *   - Quick-jump navigation to each table
 *   - Detailed column table for each of the 13 database tables
 *   - Link to the SQL schema file for installation reference
 *
 * Requires: config/db.php for database connection
 */

$page_title       = 'Database Documentation | GymHub';
$page_description = 'GymHub MySQL database schema documentation. All 13 tables with column names, types, and descriptions.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// ── Fetch live record counts from every table ─────────────────────────────────
// These are shown in the stat cards and next to each table heading.
// fetchColumn() returns just the single COUNT(*) number directly.
$table_counts = [];
$tables = ['users','memberships','user_memberships','instructors','classes',
           'class_schedule','bookings','ratings','questions','answers',
           'locations','progress','site_settings'];

foreach ($tables as $table) {
    try {
        // COUNT(*) returns the total number of rows in the table
        $table_counts[$table] = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
    } catch (Exception $e) {
        // If a table doesn't exist yet, show N/A instead of crashing
        $table_counts[$table] = 'N/A';
    }
}

// ── Full schema definition array ─────────────────────────────────────────────
// Each table has a description and a columns array.
// Column format: [column_name, data_type, constraint_or_note, human_description]
// This drives the entire schema display — to document a new table, just add it here.
$schema = [
    'users' => [
        'description' => 'Stores all registered users including members and administrators.',
        'columns' => [
            ['id',         'INT',          'AUTO_INCREMENT PRIMARY KEY', 'Unique user identifier'],
            ['first_name', 'VARCHAR(50)',  'NOT NULL',                   'User\'s first name'],
            ['last_name',  'VARCHAR(50)',  'NOT NULL',                   'User\'s last name'],
            ['email',      'VARCHAR(100)', 'NOT NULL UNIQUE',            'Login email — must be unique'],
            ['password',   'VARCHAR(255)', 'NOT NULL',                   'bcrypt hashed password — never plain text'],
            ['role',       'ENUM',         'member | admin',             'Access level — admin gets admin panel'],
            ['avatar',     'VARCHAR(255)', 'DEFAULT NULL',               'Profile photo filename'],
            ['phone',      'VARCHAR(20)',  'DEFAULT NULL',               'Optional phone number'],
            ['status',     'ENUM',         'active | disabled',          'Disabled accounts cannot log in'],
            ['created_at', 'TIMESTAMP',    'DEFAULT CURRENT_TIMESTAMP',  'When account was registered'],
        ]
    ],
    'memberships' => [
        'description' => 'The three membership tier products available for purchase: Basic, Pro, and Elite.',
        'columns' => [
            ['id',       'INT',           'AUTO_INCREMENT PRIMARY KEY', 'Unique plan ID'],
            ['name',     'VARCHAR(50)',   'NOT NULL',                   'Plan name (Basic / Pro / Elite)'],
            ['price',    'DECIMAL(8,2)', 'NOT NULL',                   'Monthly price in CAD dollars'],
            ['duration', 'INT',           'NOT NULL',                   'Plan length in days (30 = 1 month)'],
            ['features', 'TEXT',          'NOT NULL',                   'JSON array of feature strings'],
            ['status',   'ENUM',          'active | inactive',          'Inactive plans are hidden from members'],
        ]
    ],
    'user_memberships' => [
        'description' => 'Links a user to their purchased membership plan with start and expiry dates.',
        'columns' => [
            ['id',            'INT',  'AUTO_INCREMENT PRIMARY KEY',    'Unique record ID'],
            ['user_id',       'INT',  'FOREIGN KEY → users.id',       'The member who purchased'],
            ['membership_id', 'INT',  'FOREIGN KEY → memberships.id', 'Which plan was purchased'],
            ['start_date',    'DATE', 'NOT NULL',                      'Date membership begins'],
            ['end_date',      'DATE', 'NOT NULL',                      'Date membership expires'],
        ]
    ],
    'instructors' => [
        'description' => 'Instructor profiles linked to user accounts. Stores bio, specialties, photo, and calculated rating.',
        'columns' => [
            ['id',          'INT',          'AUTO_INCREMENT PRIMARY KEY', 'Unique instructor ID'],
            ['user_id',     'INT',          'FOREIGN KEY → users.id',    'Linked user account (for name/email)'],
            ['bio',         'TEXT',         'DEFAULT NULL',               'Instructor biography paragraph'],
            ['specialties', 'VARCHAR(255)', 'DEFAULT NULL',               'Comma-separated specialty list'],
            ['photo',       'VARCHAR(255)', 'DEFAULT NULL',               'Profile photo filename'],
            ['rating',      'DECIMAL(3,2)','DEFAULT 0.00',               'Average star rating (0.00–5.00)'],
        ]
    ],
    'classes' => [
        'description' => 'The 20 fitness class products. Each class has two bookable format options (e.g. Beginner/Advanced).',
        'columns' => [
            ['id',            'INT',          'AUTO_INCREMENT PRIMARY KEY',  'Unique class ID'],
            ['title',         'VARCHAR(100)', 'NOT NULL',                    'Class display name'],
            ['category',      'VARCHAR(50)',  'NOT NULL',                    'Category (Strength/Cardio/Yoga etc)'],
            ['description',   'TEXT',         'NOT NULL',                    'Full class description text'],
            ['instructor_id', 'INT',          'FOREIGN KEY → instructors.id','Assigned instructor'],
            ['capacity',      'INT',          'DEFAULT 20',                  'Max participants per session'],
            ['duration_min',  'INT',          'NOT NULL',                    'Session length in minutes'],
            ['price',         'DECIMAL(8,2)','NOT NULL',                    'Price per session in dollars'],
            ['option_label',  'VARCHAR(50)',  'NOT NULL',                    'Option type label (e.g. Level)'],
            ['option_a',      'VARCHAR(50)',  'NOT NULL',                    'First option choice (e.g. Beginner)'],
            ['option_b',      'VARCHAR(50)',  'NOT NULL',                    'Second option choice (e.g. Advanced)'],
            ['image',         'VARCHAR(255)', 'DEFAULT NULL',                'Class image filename'],
            ['status',        'ENUM',         'active | inactive',           'Inactive classes are hidden from catalog'],
        ]
    ],
    'class_schedule' => [
        'description' => 'Individual scheduled sessions for each class. Each row is one bookable time slot on a specific date.',
        'columns' => [
            ['id',         'INT',         'AUTO_INCREMENT PRIMARY KEY', 'Unique session ID'],
            ['class_id',   'INT',         'FOREIGN KEY → classes.id',  'Which class this session belongs to'],
            ['date',       'DATE',        'NOT NULL',                   'Session date (YYYY-MM-DD)'],
            ['time',       'TIME',        'NOT NULL',                   'Session start time (HH:MM:SS)'],
            ['room',       'VARCHAR(50)', 'DEFAULT Main Floor',         'Room or area name within the gym'],
            ['spots_left', 'INT',         'NOT NULL',                   'Remaining bookable spots (decremented on booking)'],
        ]
    ],
    'bookings' => [
        'description' => 'Records each member booking a scheduled class session. Tracks option chosen and booking status.',
        'columns' => [
            ['id',            'INT',         'AUTO_INCREMENT PRIMARY KEY',       'Unique booking ID'],
            ['user_id',       'INT',         'FOREIGN KEY → users.id',          'Member who made the booking'],
            ['schedule_id',   'INT',         'FOREIGN KEY → class_schedule.id', 'Specific session booked'],
            ['option_choice', 'VARCHAR(50)', 'NOT NULL',                         'Which option the member chose'],
            ['status',        'ENUM',        'confirmed | cancelled | completed','Booking status'],
            ['booked_at',     'TIMESTAMP',   'DEFAULT CURRENT_TIMESTAMP',        'When booking was made'],
        ]
    ],
    'ratings' => [
        'description' => 'Member star ratings and reviews for classes. UNIQUE KEY on (user_id, class_id) — one rating per member per class.',
        'columns' => [
            ['id',         'INT',      'AUTO_INCREMENT PRIMARY KEY', 'Unique rating ID'],
            ['user_id',    'INT',      'FOREIGN KEY → users.id',    'Member who submitted the rating'],
            ['class_id',   'INT',      'FOREIGN KEY → classes.id',  'Class being rated'],
            ['stars',      'TINYINT',  '1–5 CHECK constraint',      'Star rating (1=Terrible, 5=Excellent)'],
            ['comment',    'TEXT',     'DEFAULT NULL',               'Optional written review text'],
            ['created_at', 'TIMESTAMP','DEFAULT CURRENT_TIMESTAMP', 'When rating was submitted'],
        ]
    ],
    'questions' => [
        'description' => 'Questions submitted by members via the Ask a Trainer page. Supports optional file attachments.',
        'columns' => [
            ['id',         'INT',          'AUTO_INCREMENT PRIMARY KEY', 'Unique question ID'],
            ['user_id',    'INT',          'FOREIGN KEY → users.id',    'Member who submitted the question'],
            ['title',      'VARCHAR(200)', 'NOT NULL',                   'Question subject line'],
            ['body',       'TEXT',         'NOT NULL',                   'Full question text'],
            ['attachment', 'VARCHAR(255)', 'DEFAULT NULL',               'Optional uploaded file path'],
            ['status',     'ENUM',         'open | answered | closed',  'open = awaiting response'],
            ['created_at', 'TIMESTAMP',    'DEFAULT CURRENT_TIMESTAMP', 'When question was submitted'],
        ]
    ],
    'answers' => [
        'description' => 'Admin or trainer responses to member questions. One answer per question (admins can update it).',
        'columns' => [
            ['id',          'INT',      'AUTO_INCREMENT PRIMARY KEY',  'Unique answer ID'],
            ['question_id', 'INT',      'FOREIGN KEY → questions.id', 'The question being answered'],
            ['admin_id',    'INT',      'FOREIGN KEY → users.id',     'Admin/trainer who wrote the answer'],
            ['body',        'TEXT',     'NOT NULL',                    'The answer text'],
            ['created_at',  'TIMESTAMP','DEFAULT CURRENT_TIMESTAMP',  'When the answer was submitted'],
        ]
    ],
    'locations' => [
        'description' => 'Physical GymHub gym locations. Lat/lng coordinates are used by the Leaflet.js interactive map.',
        'columns' => [
            ['id',      'INT',           'AUTO_INCREMENT PRIMARY KEY', 'Unique location ID'],
            ['name',    'VARCHAR(100)',   'NOT NULL',                   'Location display name'],
            ['address', 'VARCHAR(255)',   'NOT NULL',                   'Street address'],
            ['city',    'VARCHAR(100)',   'NOT NULL',                   'City name'],
            ['lat',     'DECIMAL(10,7)', 'NOT NULL',                   'GPS latitude coordinate'],
            ['lng',     'DECIMAL(10,7)', 'NOT NULL',                   'GPS longitude coordinate'],
            ['phone',   'VARCHAR(20)',    'DEFAULT NULL',               'Location phone number'],
            ['hours',   'VARCHAR(255)',   'DEFAULT NULL',               'Opening hours description string'],
            ['photo',   'VARCHAR(255)',   'DEFAULT NULL',               'Location photo filename'],
        ]
    ],
    'progress' => [
        'description' => 'Member fitness progress log entries. UNIQUE KEY on (user_id, log_date) — one entry per member per day.',
        'columns' => [
            ['id',                'INT',          'AUTO_INCREMENT PRIMARY KEY', 'Unique entry ID'],
            ['user_id',          'INT',          'FOREIGN KEY → users.id',    'Member who logged the entry'],
            ['log_date',         'DATE',         'NOT NULL',                   'Date of the log entry'],
            ['weight_kg',        'DECIMAL(5,2)', 'DEFAULT NULL',               'Logged weight in kilograms'],
            ['sessions_attended','INT',          'DEFAULT 0',                  'Auto-counted from bookings table'],
            ['notes',            'TEXT',         'DEFAULT NULL',               'Member\'s personal notes'],
        ]
    ],
    'site_settings' => [
        'description' => 'Key-value store for site-wide configuration. Currently used for active theme and maintenance mode.',
        'columns' => [
            ['id',            'INT',          'AUTO_INCREMENT PRIMARY KEY', 'Unique setting ID'],
            ['setting_key',   'VARCHAR(50)',  'NOT NULL UNIQUE',            'Setting name (e.g. active_theme)'],
            ['setting_value', 'VARCHAR(255)', 'NOT NULL',                   'Setting value (e.g. powerzone)'],
            ['updated_at',    'TIMESTAMP',    'ON UPDATE CURRENT_TIMESTAMP','Automatically updated on change'],
        ]
    ],
];
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Documentation</span>
        <h1>Database Schema</h1>
        <p>Full reference of all <?= count($schema) ?> GymHub MySQL tables, columns, and relationships.</p>
    </div>
</section>

<section class="docs-page section-pad">
    <div class="container">

        <!-- Live stats strip — counts pulled from the actual database -->
        <div class="docs-stats">
            <div class="docs-stat">
                <strong><?= count($schema) ?></strong>
                <span>Tables</span>
            </div>
            <div class="docs-stat">
                <!-- array_sum adds up all the record counts -->
                <strong><?= array_sum(array_filter($table_counts, 'is_numeric')) ?></strong>
                <span>Total Records</span>
            </div>
            <div class="docs-stat">
                <strong><?= $table_counts['classes'] ?></strong>
                <span>Classes</span>
            </div>
            <div class="docs-stat">
                <strong><?= $table_counts['users'] ?></strong>
                <span>Users</span>
            </div>
            <div class="docs-stat">
                <strong><?= $table_counts['bookings'] ?></strong>
                <span>Bookings</span>
            </div>
        </div>

        <!-- Entity relationship summary -->
        <div class="docs-card" style="margin-bottom:var(--space-2xl);">
            <h2>Key Relationships</h2>
            <p style="color:var(--color-text-muted);margin-bottom:var(--space-lg);">
                How the main tables connect to each other.
            </p>
            <div class="er-grid">
                <div class="er-item"><code>users</code> → <code>bookings</code> (one user, many bookings)</div>
                <div class="er-item"><code>users</code> → <code>user_memberships</code> (one user, one active plan)</div>
                <div class="er-item"><code>users</code> → <code>ratings</code> (one user, one rating per class)</div>
                <div class="er-item"><code>users</code> → <code>questions</code> (one user, many questions)</div>
                <div class="er-item"><code>users</code> → <code>instructors</code> (one-to-one)</div>
                <div class="er-item"><code>classes</code> → <code>class_schedule</code> (one class, many sessions)</div>
                <div class="er-item"><code>class_schedule</code> → <code>bookings</code> (one session, many bookings)</div>
                <div class="er-item"><code>questions</code> → <code>answers</code> (one question, one answer)</div>
            </div>
        </div>

        <!-- Quick-jump navigation pills -->
        <div class="table-nav">
            <?php foreach (array_keys($schema) as $tbl): ?>
            <a href="#table-<?= $tbl ?>" class="table-nav-link">
                <?= $tbl ?>
                <span class="record-count"><?= $table_counts[$tbl] ?></span>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- ── Individual table documentation cards ── -->
        <!-- Loop through each table and render a card with header and columns table -->
        <?php foreach ($schema as $table_name => $table): ?>
        <div class="table-schema" id="table-<?= $table_name ?>">
            <div class="table-schema-header">
                <div>
                    <h3><?= h($table_name) ?></h3>
                    <p><?= h($table['description']) ?></p>
                </div>
                <!-- Live record count badge -->
                <div class="table-record-count">
                    <strong><?= $table_counts[$table_name] ?></strong>
                    <span>records</span>
                </div>
            </div>
            <div style="overflow-x:auto;">
                <table class="schema-table">
                    <thead>
                        <tr>
                            <th>Column</th>
                            <th>Type</th>
                            <th>Constraint</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($table['columns'] as $col): ?>
                        <tr>
                            <!-- Column name in orange monospace -->
                            <td><code class="col-name"><?= h($col[0]) ?></code></td>
                            <!-- Data type in blue monospace -->
                            <td><span class="col-type"><?= h($col[1]) ?></span></td>
                            <!-- Constraint/notes in grey -->
                            <td><span class="col-constraint"><?= h($col[2]) ?></span></td>
                            <!-- Plain-English description -->
                            <td><?= h($col[3]) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; ?>

        <!-- SQL file reference -->
        <div class="docs-card" style="margin-top:var(--space-2xl);text-align:center;">
            <h3>Full SQL Schema File</h3>
            <p style="color:var(--color-text-muted);margin-bottom:var(--space-lg);">
                The complete CREATE TABLE statements and seed data are in
                <code>sql/gymhub.sql</code> in the GitHub repository.
                See the <a href="installation.php">Installation Guide</a> for import instructions.
            </p>
            <a href="installation.php" class="btn btn-primary">View Installation Guide</a>
        </div>

    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.docs-stats{display:grid;grid-template-columns:repeat(5,1fr);gap:var(--space-md);margin-bottom:var(--space-2xl)}
.docs-stat{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg);text-align:center}
.docs-stat strong{display:block;font-family:var(--font-display);font-size:2rem;font-weight:900;color:var(--color-accent);line-height:1}
.docs-stat span{font-size:.78rem;color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.06em}
.docs-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.docs-card h2{margin-bottom:var(--space-sm)}
.er-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:var(--space-sm)}
.er-item{font-size:.875rem;color:var(--color-text-light);padding:var(--space-sm);background:var(--color-surface-2);border-radius:var(--radius-sm)}
.er-item code{color:var(--color-accent);font-size:.8rem}
.table-nav{display:flex;flex-wrap:wrap;gap:var(--space-sm);margin-bottom:var(--space-2xl)}
.table-nav-link{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-full);padding:.3rem .9rem;font-family:var(--font-display);font-size:.8rem;font-weight:700;color:var(--color-text-muted);text-decoration:none;transition:all var(--transition-fast);display:flex;align-items:center;gap:.4rem}
.table-nav-link:hover{border-color:var(--color-accent);color:var(--color-accent)}
.record-count{background:var(--color-accent);color:#000;font-size:.7rem;padding:.1rem .4rem;border-radius:var(--radius-full)}
.table-schema{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;margin-bottom:var(--space-xl)}
.table-schema-header{padding:var(--space-lg) var(--space-xl);border-bottom:1px solid var(--color-border);display:flex;align-items:flex-start;justify-content:space-between;gap:var(--space-lg);background:var(--color-surface-2)}
.table-schema-header h3{font-size:1.1rem;margin-bottom:.25rem;color:var(--color-accent)}
.table-schema-header p{color:var(--color-text-muted);font-size:.875rem;margin:0}
.table-record-count{text-align:center;flex-shrink:0}
.table-record-count strong{display:block;font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--color-accent);line-height:1}
.table-record-count span{font-size:.72rem;color:var(--color-text-muted);text-transform:uppercase}
.schema-table{width:100%;border-collapse:collapse}
.schema-table th{text-align:left;padding:.65rem var(--space-lg);background:var(--color-surface);border-bottom:1px solid var(--color-border);font-family:var(--font-display);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--color-text-muted)}
.schema-table td{padding:.65rem var(--space-lg);border-bottom:1px solid var(--color-border);font-size:.875rem;color:var(--color-text-light);vertical-align:middle}
.schema-table tr:last-child td{border-bottom:none}
.schema-table tr:hover td{background:var(--color-surface-2)}
.col-name{background:var(--color-surface-2);border:1px solid var(--color-border);padding:.15rem .5rem;border-radius:3px;font-size:.85rem;color:var(--color-accent);font-family:monospace}
.col-type{background:rgba(74,158,218,.1);color:#4a9eda;font-size:.78rem;font-family:monospace;padding:.15rem .5rem;border-radius:3px}
.col-constraint{color:var(--color-text-muted);font-size:.82rem}
@media(max-width:900px){.docs-stats{grid-template-columns:repeat(3,1fr)}}
@media(max-width:480px){.docs-stats{grid-template-columns:repeat(2,1fr)}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
