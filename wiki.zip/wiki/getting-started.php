<?php
/**
 * GymHub - Wiki: Getting Started Guide
 * wiki/getting-started.php
 *
 * Step-by-step guide for new GymHub members.
 * This is the first of 5 required wiki/help pages.
 *
 * WIKI REQUIREMENT: One of five required help documentation pages.
 * Context-sensitive help links on pages throughout the site
 * point here when appropriate (e.g. classes.php, membership.php).
 *
 * Content covers:
 *   Step 1 — Create your account
 *   Step 2 — Browse classes
 *   Step 3 — Choose a membership
 *   Step 4 — Book a class
 *   Step 5 — Track your progress
 *
 * No database queries needed — static content only.
 */

$page_title       = 'Getting Started | GymHub Help';
$page_description = 'New to GymHub? This step-by-step guide walks you through creating an account, browsing classes, and booking your first session.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help Wiki</span>
        <h1>Getting Started with GymHub</h1>
        <p>New here? This guide walks you through everything you need to know to get up and running.</p>
    </div>
</section>

<section class="wiki-page section-pad">
    <div class="container">
        <div class="wiki-grid">

            <!-- ── Sidebar navigation ── -->
            <!-- Links to all five wiki pages so users can navigate between them -->
            <nav class="wiki-nav">
                <h4>Help Pages</h4>
                <ul>
                    <!-- active class highlights the current page -->
                    <li class="active"><a href="getting-started.php">🚀 Getting Started</a></li>
                    <li><a href="booking-guide.php">📅 Booking Guide</a></li>
                    <li><a href="account-help.php">👤 Account Help</a></li>
                    <li><a href="admin-guide.php">⚙️ Admin Guide</a></li>
                    <li><a href="installation.php">🛠 Installation</a></li>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Still Need Help?</h4>
                    <ul>
                        <li><a href="<?= SITE_URL ?>/pages/faq.php">📋 FAQ</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/ask-trainer.php">💬 Ask a Trainer</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/contact.php">📧 Contact Us</a></li>
                    </ul>
                </div>
            </nav>

            <!-- ── Main wiki content ── -->
            <div class="wiki-content">

                <p class="wiki-intro">
                    Welcome to GymHub! Follow these five steps to go from brand new to booking
                    your first fitness class in minutes.
                </p>

                <!-- Step 1 -->
                <div class="wiki-step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Create Your Free Account</h3>
                        <p>
                            Click <strong>Join Now</strong> in the top navigation bar, or go directly to
                            <a href="<?= SITE_URL ?>/pages/register.php">Register</a>.
                            Fill in your first name, last name, email address, and a secure password.
                            Your account is created instantly — no email verification required.
                        </p>
                        <p>
                            <strong>Password requirements:</strong> at least 8 characters,
                            one uppercase letter, and one number.
                        </p>
                        <a href="<?= SITE_URL ?>/pages/register.php" class="btn btn-primary btn-sm">
                            Create Account →
                        </a>
                    </div>
                </div>

                <!-- Step 2 -->
                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Browse Our Classes</h3>
                        <p>
                            Go to the <a href="<?= SITE_URL ?>/pages/classes.php">Classes</a> page
                            to see all 20+ available fitness classes. You can:
                        </p>
                        <ul style="list-style:disc;padding-left:1.5rem;color:var(--color-text-light);margin-bottom:var(--space-md);">
                            <li>Filter by category (Strength, Yoga, Cardio, Combat, etc.)</li>
                            <li>Search by class name or keyword</li>
                            <li>Sort by price, duration, or rating</li>
                            <li>Click any class to see the full description, instructor, and available sessions</li>
                        </ul>
                        <p>
                            Each class offers two options (e.g. Beginner or Advanced) — you choose
                            which option you want when booking.
                        </p>
                    </div>
                </div>

                <!-- Step 3 -->
                <div class="wiki-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Choose a Membership Plan</h3>
                        <p>
                            Visit the <a href="<?= SITE_URL ?>/pages/membership.php">Membership</a> page
                            to see our three plans. Use the <strong>Quote Calculator</strong> on that page
                            if you're unsure which plan is right for you — answer a few questions and
                            it will recommend the best option based on your goals.
                        </p>
                        <ul style="list-style:disc;padding-left:1.5rem;color:var(--color-text-light);margin-bottom:var(--space-md);">
                            <li><strong>Basic</strong> — Group classes, locker rooms, one location</li>
                            <li><strong>Pro</strong> — Unlimited bookings, all locations</li>
                            <li><strong>Elite</strong> — Personal training, nutrition consultation, priority booking</li>
                        </ul>
                        <p>All plans are month-to-month — cancel anytime from your profile.</p>
                    </div>
                </div>

                <!-- Step 4 -->
                <div class="wiki-step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h3>Book Your First Class</h3>
                        <p>
                            Click any class on the <a href="<?= SITE_URL ?>/pages/classes.php">Classes</a>
                            page to open its detail page. On the right side you'll see the booking panel:
                        </p>
                        <ul style="list-style:disc;padding-left:1.5rem;color:var(--color-text-light);margin-bottom:var(--space-md);">
                            <li>Select your option (e.g. Beginner or Advanced)</li>
                            <li>Choose a session date and time from the dropdown</li>
                            <li>Click <strong>Confirm Booking</strong></li>
                        </ul>
                        <p>
                            Your booking is confirmed immediately. You can view and manage all your
                            bookings on the <a href="<?= SITE_URL ?>/pages/bookings.php">My Bookings</a> page.
                            Free cancellation is available up to 24 hours before the class starts.
                        </p>
                        <a href="<?= SITE_URL ?>/pages/classes.php" class="btn btn-secondary btn-sm">
                            Browse Classes →
                        </a>
                    </div>
                </div>

                <!-- Step 5 -->
                <div class="wiki-step">
                    <div class="step-number">5</div>
                    <div class="step-content">
                        <h3>Track Your Progress</h3>
                        <p>
                            Visit the <a href="<?= SITE_URL ?>/pages/progress.php">Progress Tracker</a>
                            to log your weight and notes each day. Your data is shown in three interactive charts:
                        </p>
                        <ul style="list-style:disc;padding-left:1.5rem;color:var(--color-text-light);margin-bottom:var(--space-md);">
                            <li>Weight over time (line chart)</li>
                            <li>Sessions attended per day (bar chart)</li>
                            <li>Class categories breakdown (doughnut chart)</li>
                        </ul>
                    </div>
                </div>

                <!-- Helpful tips callout box -->
                <div class="wiki-callout">
                    <h4>💡 Pro Tips</h4>
                    <ul>
                        <li>Use the <a href="<?= SITE_URL ?>/pages/schedule.php">Schedule</a> page to quickly find classes happening this week</li>
                        <li>Have a fitness question? Use <a href="<?= SITE_URL ?>/pages/ask-trainer.php">Ask a Trainer</a> — instructors respond within 24 hours</li>
                        <li>After attending a class, leave a review on the <a href="<?= SITE_URL ?>/pages/rate-class.php">Rate a Class</a> page to help other members</li>
                        <li>You can attend one free class before choosing a membership plan</li>
                    </ul>
                </div>

                <!-- Navigation to next wiki page -->
                <div class="wiki-nav-btns">
                    <span></span>
                    <a href="booking-guide.php" class="btn btn-secondary">
                        Next: Booking Guide →
                    </a>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.wiki-intro{color:var(--color-text-light);font-size:1.05rem;line-height:1.8;margin-bottom:var(--space-2xl);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.wiki-nav-btns{display:flex;justify-content:space-between;margin-top:var(--space-2xl);padding-top:var(--space-xl);border-top:1px solid var(--color-border)}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
