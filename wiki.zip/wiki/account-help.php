<?php
/**
 * GymHub - Wiki: Account Help
 * wiki/account-help.php
 *
 * Help guide for managing a GymHub member account.
 * Third of 5 required wiki/help pages.
 *
 * WIKI REQUIREMENT: One of five required help documentation pages.
 * Context-sensitive help links on the profile page point here.
 *
 * Content covers:
 *   - Updating profile information
 *   - Changing your password
 *   - Managing your membership plan
 *   - Using the progress tracker
 *   - Deleting your account
 *
 * No database queries needed — static content only.
 */

$page_title       = 'Account Help | GymHub Help';
$page_description = 'Help with your GymHub account — updating profile, changing passwords, managing membership, and tracking progress.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help Wiki</span>
        <h1>Account Help</h1>
        <p>Everything you need to know about managing your GymHub account.</p>
    </div>
</section>

<section class="wiki-page section-pad">
    <div class="container">
        <div class="wiki-grid">

            <!-- ── Sidebar navigation ── -->
            <nav class="wiki-nav">
                <h4>Help Pages</h4>
                <ul>
                    <li><a href="getting-started.php">🚀 Getting Started</a></li>
                    <li><a href="booking-guide.php">📅 Booking Guide</a></li>
                    <li class="active"><a href="account-help.php">👤 Account Help</a></li>
                    <li><a href="admin-guide.php">⚙️ Admin Guide</a></li>
                    <li><a href="installation.php">🛠 Installation</a></li>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="<?= SITE_URL ?>/pages/profile.php">👤 My Profile</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/membership.php">🏆 Membership Plans</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/progress.php">📈 Progress Tracker</a></li>
                    </ul>
                </div>
            </nav>

            <!-- ── Main content ── -->
            <div class="wiki-content">

                <p class="wiki-intro">
                    Your GymHub account lets you book classes, track progress, and connect
                    with trainers. This page explains how to manage every aspect of your account.
                </p>

                <!-- Section 1: Update profile -->
                <h2>Updating Your Profile</h2>
                <p>
                    Go to <a href="<?= SITE_URL ?>/pages/profile.php">My Profile</a> by clicking
                    your name in the top navigation. The <strong>Edit Profile</strong> form lets you:
                </p>
                <ul class="wiki-list">
                    <li>Update your first and last name</li>
                    <li>Add or change your phone number</li>
                </ul>
                <p>
                    Your <strong>email address cannot be changed</strong> after registration.
                    If you need to update your email, please <a href="<?= SITE_URL ?>/pages/contact.php">contact us</a>.
                </p>

                <!-- Section 2: Change password -->
                <h2 style="margin-top:var(--space-2xl);">Changing Your Password</h2>

                <div class="wiki-step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Go to My Profile</h3>
                        <p>Click your name in the top navigation → <strong>My Profile</strong>.</p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Scroll to Change Password</h3>
                        <p>
                            Find the <strong>Change Password</strong> section below the Edit Profile form.
                            Enter your current password first — this confirms it's really you.
                            Then enter and confirm your new password.
                        </p>
                        <p>Password requirements: minimum 8 characters, one uppercase letter, one number.</p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Click Change Password</h3>
                        <p>
                            You'll see a green success message when the password has been updated.
                            Your next login will use the new password.
                        </p>
                    </div>
                </div>

                <!-- Section 3: Membership -->
                <h2 style="margin-top:var(--space-2xl);">Managing Your Membership</h2>
                <p>
                    Visit the <a href="<?= SITE_URL ?>/pages/membership.php">Membership</a> page to
                    see all available plans. Click <strong>Get [Plan Name]</strong> on any card to
                    activate that plan. Your previous plan is automatically replaced.
                </p>
                <p>
                    Your current active plan and its expiry date are shown on your
                    <a href="<?= SITE_URL ?>/pages/profile.php">Profile</a> page in the sidebar.
                    Plans renew every 30 days.
                </p>

                <div class="wiki-callout">
                    <h4>💡 Not sure which plan to choose?</h4>
                    <p>
                        Use the <strong>Quote Calculator</strong> on the Membership page.
                        Answer a few questions about your workout habits and it will recommend
                        the best plan for your needs with an estimated monthly price.
                    </p>
                </div>

                <!-- Section 4: Progress tracker -->
                <h2 style="margin-top:var(--space-2xl);">Using the Progress Tracker</h2>
                <p>
                    The <a href="<?= SITE_URL ?>/pages/progress.php">Progress Tracker</a> lets you
                    log your weight and notes each day. Sessions attended are counted automatically
                    from your bookings — you don't need to enter them manually.
                </p>
                <ul class="wiki-list">
                    <li><strong>Weight chart</strong> — Line chart showing your weight trend over the last 30 log entries</li>
                    <li><strong>Sessions chart</strong> — Bar chart of classes attended per day</li>
                    <li><strong>Category chart</strong> — Doughnut chart showing which class types you've attended most</li>
                </ul>
                <p>
                    You can log an entry for any past date. If you log an entry for a date
                    you've already logged, the existing entry is updated rather than duplicated.
                </p>

                <!-- Section 5: Delete account -->
                <h2 style="margin-top:var(--space-2xl);">Deleting Your Account</h2>
                <p>
                    Account deletion is not available through the website interface.
                    To request deletion of your account and all associated data, please
                    <a href="<?= SITE_URL ?>/pages/contact.php">contact us</a> with your
                    registered email address. We will process the request within 5 business days.
                </p>

                <!-- Page navigation -->
                <div class="wiki-nav-btns">
                    <a href="booking-guide.php" class="btn btn-secondary">← Booking Guide</a>
                    <a href="admin-guide.php"   class="btn btn-secondary">Admin Guide →</a>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.wiki-intro{color:var(--color-text-light);font-size:1.05rem;line-height:1.8;margin-bottom:var(--space-2xl);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.wiki-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.6rem;margin:var(--space-md) 0 var(--space-lg)}
.wiki-list li{color:var(--color-text-light);font-size:.95rem;line-height:1.7}
.wiki-list strong{color:var(--color-text)}
.wiki-nav-btns{display:flex;justify-content:space-between;margin-top:var(--space-2xl);padding-top:var(--space-xl);border-top:1px solid var(--color-border)}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
