<?php
/**
 * GymHub - Wiki: Booking Guide
 * wiki/booking-guide.php
 *
 * Step-by-step help guide for booking and cancelling classes.
 * This is the second of 5 required wiki/help pages.
 *
 * WIKI REQUIREMENT: One of five required help documentation pages.
 * Context-sensitive help links on the bookings page and class
 * detail page point directly here.
 *
 * Content covers:
 *   - How to find and book a class
 *   - Understanding class options
 *   - How to view your bookings
 *   - Cancellation rules and process
 *   - What to do if a class is full
 *
 * No database queries needed — static content only.
 */

$page_title       = 'Booking Guide | GymHub Help';
$page_description = 'How to book and cancel GymHub fitness classes. Step-by-step instructions with screenshots and tips.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help Wiki</span>
        <h1>Booking Guide</h1>
        <p>Everything you need to know about booking, managing, and cancelling your GymHub classes.</p>
    </div>
</section>

<section class="wiki-page section-pad">
    <div class="container">
        <div class="wiki-grid">

            <!-- ── Sidebar navigation ── -->
            <nav class="wiki-nav">
                <h4>Help Pages</h4>
                <ul>
                    <li><a href="getting-started.php">🚀 Getting Started</a></li>
                    <li class="active"><a href="booking-guide.php">📅 Booking Guide</a></li>
                    <li><a href="account-help.php">👤 Account Help</a></li>
                    <li><a href="admin-guide.php">⚙️ Admin Guide</a></li>
                    <li><a href="installation.php">🛠 Installation</a></li>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Still Need Help?</h4>
                    <ul>
                        <li><a href="<?= SITE_URL ?>/pages/faq.php">📋 FAQ</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/ask-trainer.php">💬 Ask a Trainer</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/contact.php">📧 Contact Us</a></li>
                    </ul>
                </div>
            </nav>

            <!-- ── Main content ── -->
            <div class="wiki-content">

                <p class="wiki-intro">
                    Booking a class at GymHub takes less than a minute. This guide covers
                    the full process from finding a class to cancelling a booking.
                </p>

                <!-- Section 1: How to book -->
                <h2>How to Book a Class</h2>

                <div class="wiki-step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Browse and find a class</h3>
                        <p>
                            Go to the <a href="<?= SITE_URL ?>/pages/classes.php">Classes</a> page
                            or the <a href="<?= SITE_URL ?>/pages/schedule.php">Schedule</a> page.
                            Use the category filter pills or search bar to narrow down classes.
                            Click any class card to open its full detail page.
                        </p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Choose your option</h3>
                        <p>
                            Every GymHub class offers two format options — for example
                            <strong>Beginner</strong> or <strong>Advanced</strong>, or
                            <strong>Morning</strong> or <strong>Evening</strong>.
                            In the booking panel on the right side of the class page,
                            click your preferred option radio button.
                        </p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <h3>Select a session date and time</h3>
                        <p>
                            The session dropdown shows all upcoming available slots
                            for that class. Each option shows the date, time, room,
                            and number of spots remaining.
                            Select the session you want to attend.
                        </p>
                        <p>
                            Sessions showing <strong>0 spots</strong> are fully booked
                            and won't appear in the dropdown.
                        </p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">4</div>
                    <div class="step-content">
                        <h3>Confirm your booking</h3>
                        <p>
                            Click the <strong>Confirm Booking</strong> button. You must be
                            logged in — if you aren't, you'll be redirected to login first
                            and then returned to the booking page automatically.
                        </p>
                        <p>
                            Your booking is confirmed immediately. The spot count decreases
                            by one so other members see the updated availability.
                        </p>
                        <a href="<?= SITE_URL ?>/pages/classes.php" class="btn btn-primary btn-sm">
                            Browse Classes to Book →
                        </a>
                    </div>
                </div>

                <!-- Section 2: Viewing bookings -->
                <h2 style="margin-top:var(--space-2xl);">Viewing Your Bookings</h2>
                <p>
                    All your bookings — upcoming and past — appear on the
                    <a href="<?= SITE_URL ?>/pages/bookings.php">My Bookings</a> page.
                </p>
                <ul class="wiki-list">
                    <li><strong>Upcoming</strong> — Shows confirmed sessions in the future as visual cards with all session details.</li>
                    <li><strong>History</strong> — Shows past and cancelled bookings in a compact table. Each has a Rate button so you can leave a review.</li>
                </ul>

                <!-- Section 3: Cancellation -->
                <h2 style="margin-top:var(--space-2xl);">Cancelling a Booking</h2>

                <div class="wiki-callout">
                    <h4>⚠️ Cancellation Policy</h4>
                    <p>
                        Free cancellation is available up to <strong>24 hours before the class start time</strong>.
                        Cancellations made within 24 hours of the class are not eligible for a refund.
                        The booking will show a 🔒 lock icon when cancellation is no longer available.
                    </p>
                </div>

                <div class="wiki-step" style="margin-top:var(--space-xl);">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <h3>Go to My Bookings</h3>
                        <p>
                            Click your name in the top navigation → select <strong>My Bookings</strong>,
                            or go directly to
                            <a href="<?= SITE_URL ?>/pages/bookings.php">My Bookings</a>.
                        </p>
                    </div>
                </div>

                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <h3>Find the booking and click Cancel</h3>
                        <p>
                            Each upcoming booking card has a red <strong>Cancel Booking</strong> button
                            if cancellation is still available (more than 24 hours away).
                            Click it and confirm the prompt to cancel.
                        </p>
                        <p>
                            When you cancel, your spot is automatically returned to the class
                            so another member can book it.
                        </p>
                    </div>
                </div>

                <!-- Section 4: Full class -->
                <h2 style="margin-top:var(--space-2xl);">What if a Class is Full?</h2>
                <p>
                    If a session is fully booked, it won't appear in the dropdown on the class detail page.
                    Here are your options:
                </p>
                <ul class="wiki-list">
                    <li>Check the <a href="<?= SITE_URL ?>/pages/schedule.php">Schedule</a> — the same class may have other sessions on different days.</li>
                    <li>Browse <a href="<?= SITE_URL ?>/pages/classes.php">similar classes</a> in the same category.</li>
                    <li><a href="<?= SITE_URL ?>/pages/ask-trainer.php">Ask a Trainer</a> to recommend an alternative.</li>
                </ul>

                <!-- Page navigation -->
                <div class="wiki-nav-btns">
                    <a href="getting-started.php" class="btn btn-secondary">← Getting Started</a>
                    <a href="account-help.php"    class="btn btn-secondary">Account Help →</a>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.wiki-intro{color:var(--color-text-light);font-size:1.05rem;line-height:1.8;margin-bottom:var(--space-2xl);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.wiki-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.6rem;margin:var(--space-md) 0 var(--space-lg)}
.wiki-list li{color:var(--color-text-light);font-size:.95rem;line-height:1.7}
.wiki-list strong{color:var(--color-text)}
.wiki-nav-btns{display:flex;justify-content:space-between;margin-top:var(--space-2xl);padding-top:var(--space-xl);border-top:1px solid var(--color-border)}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
