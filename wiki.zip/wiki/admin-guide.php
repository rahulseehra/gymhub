<?php
/**
 * GymHub - Wiki: Admin Guide
 * wiki/admin-guide.php
 *
 * Documentation for GymHub administrators explaining how to use
 * the admin panel and all its features.
 * Fourth of 5 required wiki/help pages.
 *
 * WIKI REQUIREMENT: One of five required help documentation pages.
 * ADMIN DOCUMENTATION REQUIREMENT: This page also satisfies the
 * "Admin user documentation" requirement from the project spec.
 *
 * Content covers:
 *   - How to access the admin panel
 *   - Dashboard overview
 *   - Managing classes (add, edit, activate, deactivate)
 *   - Managing users (enable, disable, promote)
 *   - Answering trainer Q&A questions
 *   - Switching themes
 *   - Using the site monitoring page
 *
 * No database queries needed — static content only.
 */

$page_title       = 'Admin Guide | GymHub Help';
$page_description = 'GymHub admin panel documentation. How to manage classes, users, bookings, Q&A, themes, and site monitoring.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help Wiki</span>
        <h1>Admin Guide</h1>
        <p>Complete documentation for the GymHub admin panel.</p>
    </div>
</section>

<section class="wiki-page section-pad">
    <div class="container">
        <div class="wiki-grid">

            <!-- ── Sidebar navigation ── -->
            <nav class="wiki-nav">
                <h4>Help Pages</h4>
                <ul>
                    <li><a href="getting-started.php">🚀 Getting Started</a></li>
                    <li><a href="booking-guide.php">📅 Booking Guide</a></li>
                    <li><a href="account-help.php">👤 Account Help</a></li>
                    <li class="active"><a href="admin-guide.php">⚙️ Admin Guide</a></li>
                    <li><a href="installation.php">🛠 Installation</a></li>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Admin Panel Pages</h4>
                    <ul>
                        <?php if (is_admin()): ?>
                        <!-- Direct links to admin pages — only shown to admins -->
                        <li><a href="<?= SITE_URL ?>/admin/dashboard.php">📊 Dashboard</a></li>
                        <li><a href="<?= SITE_URL ?>/admin/classes.php">🏋️ Manage Classes</a></li>
                        <li><a href="<?= SITE_URL ?>/admin/users.php">👥 Manage Users</a></li>
                        <li><a href="<?= SITE_URL ?>/admin/qa.php">💬 Q&amp;A</a></li>
                        <li><a href="<?= SITE_URL ?>/admin/theme.php">🎨 Themes</a></li>
                        <li><a href="<?= SITE_URL ?>/admin/monitoring.php">🔌 Monitoring</a></li>
                        <?php else: ?>
                        <li><a href="<?= SITE_URL ?>/pages/login.php">Log in as Admin</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>

            <!-- ── Main content ── -->
            <div class="wiki-content">

                <p class="wiki-intro">
                    The GymHub admin panel gives administrators full control over classes,
                    users, bookings, content, and site settings. This guide covers every
                    section of the panel.
                </p>

                <!-- Section 1: Access -->
                <h2>Accessing the Admin Panel</h2>
                <p>
                    To access the admin panel, your account must have the <strong>admin role</strong>.
                    Log in with an admin account and the admin panel link will appear in your dropdown menu.
                    You can also go directly to:
                    <code><?= SITE_URL ?>/admin/dashboard.php</code>
                </p>
                <p>
                    Non-admin accounts are automatically redirected to the login page when
                    they try to visit any admin URL.
                </p>

                <!-- Section 2: Dashboard -->
                <h2 style="margin-top:var(--space-2xl);">Dashboard</h2>
                <p>The dashboard (<code>admin/dashboard.php</code>) is your overview page. It shows:</p>
                <ul class="wiki-list">
                    <li><strong>4 stat cards</strong> — total members, confirmed bookings, active classes, open questions</li>
                    <li><strong>Total revenue</strong> — sum of all confirmed booking prices</li>
                    <li><strong>Bar chart</strong> — bookings broken down by class category (Chart.js)</li>
                    <li><strong>Recent bookings table</strong> — latest 8 bookings with status</li>
                    <li><strong>New members table</strong> — most recently registered accounts</li>
                    <li><strong>Quick action buttons</strong> — shortcuts to common tasks</li>
                </ul>

                <!-- Section 3: Manage classes -->
                <h2 style="margin-top:var(--space-2xl);">Managing Classes</h2>
                <p>Go to <strong>Manage Classes</strong> in the sidebar (<code>admin/classes.php</code>).</p>

                <h3>Adding a New Class</h3>
                <div class="wiki-step">
                    <div class="step-number">1</div>
                    <div class="step-content">
                        <p>Click the <strong>➕ Add Class</strong> button at the top right of the classes table.</p>
                    </div>
                </div>
                <div class="wiki-step">
                    <div class="step-number">2</div>
                    <div class="step-content">
                        <p>Fill in the form: title, category, description, instructor, capacity, duration, price, and the two option choices (e.g. Beginner / Advanced).</p>
                    </div>
                </div>
                <div class="wiki-step">
                    <div class="step-number">3</div>
                    <div class="step-content">
                        <p>Set Status to <strong>Active</strong> so the class appears in the member catalog. Click <strong>Add Class</strong>.</p>
                    </div>
                </div>

                <h3 style="margin-top:var(--space-lg);">Editing or Deactivating a Class</h3>
                <ul class="wiki-list">
                    <li>Click <strong>Edit</strong> next to any class to update its details.</li>
                    <li>Click <strong>Deactivate</strong> to hide the class from members without deleting it. Click <strong>Activate</strong> to bring it back.</li>
                </ul>

                <!-- Section 4: Manage users -->
                <h2 style="margin-top:var(--space-2xl);">Managing Users</h2>
                <p>Go to <strong>Manage Users</strong> (<code>admin/users.php</code>) to see all registered accounts.</p>
                <ul class="wiki-list">
                    <li><strong>Disable</strong> — Prevents the user from logging in. Their data is kept. Click Enable to restore access.</li>
                    <li><strong>Make Admin</strong> — Promotes a member to admin role, giving full admin panel access. Use with caution.</li>
                    <li><strong>Make Member</strong> — Demotes an admin back to regular member role.</li>
                    <li>You cannot modify your own account from this panel — this prevents accidental lockout.</li>
                    <li>Use the search bar to find users by name or email.</li>
                </ul>

                <!-- Section 5: Q&A -->
                <h2 style="margin-top:var(--space-2xl);">Answering Trainer Questions</h2>
                <p>
                    Go to <strong>Trainer Q&amp;A</strong> (<code>admin/qa.php</code>) to see
                    all questions submitted by members via the Ask a Trainer page.
                </p>
                <ul class="wiki-list">
                    <li>The default filter shows <strong>Open</strong> questions (unanswered).</li>
                    <li>Type your response in the answer box and click <strong>Submit Answer</strong>. The question status changes to "answered" automatically.</li>
                    <li>You can update a previous answer by resubmitting the form.</li>
                    <li>Click <strong>Close Question</strong> to archive a question without answering it.</li>
                </ul>

                <!-- Section 6: Themes -->
                <h2 style="margin-top:var(--space-2xl);">Switching Themes</h2>
                <p>
                    Go to <strong>Theme Switcher</strong> (<code>admin/theme.php</code>).
                    Three themes are available:
                </p>
                <ul class="wiki-list">
                    <li><strong>PowerZone</strong> — Dark charcoal with electric orange (default)</li>
                    <li><strong>ZenFit</strong> — Light white with sage green (calm/wellness feel)</li>
                    <li><strong>BlueSteel</strong> — Deep navy with steel blue (premium/professional)</li>
                </ul>
                <p>
                    Click <strong>Apply Theme</strong> on any card. The change takes effect
                    immediately across the entire site for all visitors.
                    The active theme name is stored in the database (site_settings table).
                </p>

                <!-- Section 7: Monitoring -->
                <h2 style="margin-top:var(--space-2xl);">Site Monitoring</h2>
                <p>
                    Go to <strong>Site Monitoring</strong> (<code>admin/monitoring.php</code>)
                    to see real-time status checks for all major site services.
                </p>
                <ul class="wiki-list">
                    <li>🟢 <strong>Online</strong> — Service is working correctly</li>
                    <li>🟡 <strong>Warning</strong> — Working but something needs attention (e.g. no upcoming schedule)</li>
                    <li>🔴 <strong>Offline</strong> — Service has failed and needs immediate attention</li>
                </ul>
                <p>
                    Click <strong>🔄 Refresh</strong> to re-run all checks.
                    The server information table at the bottom shows PHP version,
                    server details, and current configuration.
                </p>

                <!-- Page navigation -->
                <div class="wiki-nav-btns">
                    <a href="account-help.php"  class="btn btn-secondary">← Account Help</a>
                    <a href="installation.php"  class="btn btn-secondary">Installation →</a>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.wiki-intro{color:var(--color-text-light);font-size:1.05rem;line-height:1.8;margin-bottom:var(--space-2xl);background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.wiki-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.6rem;margin:var(--space-md) 0 var(--space-lg)}
.wiki-list li{color:var(--color-text-light);font-size:.95rem;line-height:1.7}
.wiki-list strong{color:var(--color-text)}
code{background:var(--color-surface-2);border:1px solid var(--color-border);padding:.15rem .5rem;border-radius:3px;font-size:.85rem;color:var(--color-accent);font-family:monospace}
.wiki-nav-btns{display:flex;justify-content:space-between;margin-top:var(--space-2xl);padding-top:var(--space-xl);border-top:1px solid var(--color-border)}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
