<?php
/**
 * GymHub - Admin: Trainer Q&A
 * admin/qa.php
 *
 * Allows admins to view and respond to questions submitted by members
 * via the "Ask a Trainer" page. This is the admin side of that feature.
 *
 * What admins can do here:
 *   - See all questions filtered by status (open, answered, closed)
 *   - Type and submit an answer to any open question
 *   - Update a previously submitted answer
 *   - Close a question without answering it
 *
 * When a question is answered, its status automatically changes to 'answered'.
 * The member can see the response on their ask-trainer.php page.
 */

$page_title = 'Trainer Q&A';
$admin_page = 'qa';

require_once __DIR__ . '/admin-auth.php';

$success = '';

// ── Handle answer submission ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_answer'])) {
    $question_id = (int)($_POST['question_id'] ?? 0);
    $body        = trim($_POST['answer_body']  ?? '');

    if ($question_id && $body) {
        // Delete any existing answer first (handles the "update answer" case)
        // Then insert the new one — simpler than a conditional INSERT/UPDATE
        $pdo->prepare("DELETE FROM answers WHERE question_id=?")->execute([$question_id]);
        $pdo->prepare("INSERT INTO answers (question_id, admin_id, body) VALUES (?,?,?)")
            ->execute([$question_id, $_SESSION['user_id'], $body]);

        // Update question status to 'answered' so the member sees it resolved
        $pdo->prepare("UPDATE questions SET status='answered' WHERE id=?")->execute([$question_id]);
        $success = 'Answer submitted successfully!';
    }
}

// ── Handle close question ─────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['close_question'])) {
    $qid = (int)($_POST['question_id'] ?? 0);
    if ($qid) {
        $pdo->prepare("UPDATE questions SET status='closed' WHERE id=?")->execute([$qid]);
        $success = 'Question closed.';
    }
}

// ── Load questions ────────────────────────────────────────────────────────────
// Read the status filter from URL — default to 'open' so unanswered ones show first
$filter = $_GET['filter'] ?? 'open';

// Build WHERE clause — skip it if showing all
$where = $filter !== 'all' ? "WHERE q.status = '$filter'" : '';

// Load questions with their existing answers (if any) via LEFT JOIN
$questions = $pdo->query("
    SELECT q.*,
           CONCAT(u.first_name,' ',u.last_name) AS member_name,
           a.body AS answer_body,
           a.created_at AS answer_date,
           CONCAT(au.first_name,' ',au.last_name) AS answered_by
    FROM questions q
    JOIN users u    ON q.user_id    = u.id       -- the member who asked
    LEFT JOIN answers a  ON a.question_id = q.id -- their answer (may not exist yet)
    LEFT JOIN users au   ON a.admin_id    = au.id -- the admin who answered
    $where
    ORDER BY q.created_at DESC
")->fetchAll();

require_once __DIR__ . '/admin-header.php';
?>

<?php if ($success): ?>
<div class="alert alert-success"><?= h($success) ?></div>
<?php endif; ?>

<!-- Status filter tabs -->
<div style="display:flex;gap:var(--space-sm);margin-bottom:var(--space-lg);">
    <a href="qa.php?filter=open"     class="btn btn-sm <?= $filter === 'open'     ? 'btn-primary' : 'btn-secondary' ?>">Open</a>
    <a href="qa.php?filter=answered" class="btn btn-sm <?= $filter === 'answered' ? 'btn-primary' : 'btn-secondary' ?>">Answered</a>
    <a href="qa.php?filter=closed"   class="btn btn-sm <?= $filter === 'closed'   ? 'btn-primary' : 'btn-secondary' ?>">Closed</a>
    <a href="qa.php?filter=all"      class="btn btn-sm <?= $filter === 'all'      ? 'btn-primary' : 'btn-secondary' ?>">All</a>
</div>

<!-- Empty state message -->
<?php if (empty($questions)): ?>
<div class="admin-form-card" style="text-align:center;color:var(--color-text-muted);">
    <p style="font-size:2rem;">✅</p>
    <p>No <?= $filter !== 'all' ? $filter : '' ?> questions found.</p>
</div>
<?php endif; ?>

<!-- Loop through each question and show it as a card -->
<?php foreach ($questions as $q): ?>
<div class="admin-form-card" style="margin-bottom:var(--space-lg);">

    <!-- Question header: title, member name, date, status badge -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;
                margin-bottom:var(--space-md);flex-wrap:wrap;gap:var(--space-sm);">
        <div>
            <h3 style="margin-bottom:0.25rem;"><?= h($q['title']) ?></h3>
            <small style="color:var(--color-text-muted);">
                From <strong><?= h($q['member_name']) ?></strong>
                · <?= date('M j, Y g:i A', strtotime($q['created_at'])) ?>
            </small>
        </div>
        <span class="badge badge--<?= $q['status'] === 'open' ? 'warning' : ($q['status'] === 'answered' ? 'success' : 'muted') ?>">
            <?= ucfirst($q['status']) ?>
        </span>
    </div>

    <!-- Question body text -->
    <div style="background:var(--color-surface-2);border:1px solid var(--color-border);
                border-radius:var(--radius-md);padding:var(--space-md);margin-bottom:var(--space-lg);">
        <p style="color:var(--color-text-light);line-height:1.7;margin:0;"><?= h($q['body']) ?></p>
        <!-- File attachment link if one was uploaded -->
        <?php if ($q['attachment']): ?>
        <a href="<?= SITE_URL ?>/public/assets/uploads/<?= h($q['attachment']) ?>"
           target="_blank" style="color:var(--color-accent);font-size:0.875rem;
           margin-top:var(--space-sm);display:inline-block;">
            📎 View Attachment
        </a>
        <?php endif; ?>
    </div>

    <!-- Show existing answer in a green box if there is one -->
    <?php if ($q['answer_body']): ?>
    <div style="background:rgba(34,197,94,0.05);border:1px solid var(--color-success);
                border-radius:var(--radius-md);padding:var(--space-md);margin-bottom:var(--space-md);">
        <p style="font-size:0.8rem;color:var(--color-success);font-weight:600;margin-bottom:var(--space-sm);">
            ✅ Answered by <?= h($q['answered_by']) ?> · <?= date('M j, Y', strtotime($q['answer_date'])) ?>
        </p>
        <p style="color:var(--color-text-light);margin:0;"><?= h($q['answer_body']) ?></p>
    </div>
    <?php endif; ?>

    <!-- Answer form — only shown for non-closed questions -->
    <?php if ($q['status'] !== 'closed'): ?>
    <form method="POST" action="" class="admin-form">
        <input type="hidden" name="question_id" value="<?= $q['id'] ?>">
        <div class="form-group">
            <label><?= $q['answer_body'] ? 'Update Answer' : 'Write Your Answer' ?></label>
            <!-- Pre-fills with existing answer text if updating -->
            <textarea name="answer_body" rows="4"
                      placeholder="Type your response here..."
                      required><?= h($q['answer_body'] ?? '') ?></textarea>
        </div>
        <div style="display:flex;gap:var(--space-sm);">
            <button type="submit" name="submit_answer" class="btn btn-primary btn-sm">
                <?= $q['answer_body'] ? 'Update Answer' : 'Submit Answer' ?>
            </button>
            <!-- Close question without answer — asks for confirmation first -->
            <button type="submit" name="close_question" class="btn btn-secondary btn-sm"
                    onclick="return confirm('Close this question without answering?')">
                Close Question
            </button>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
