<?php
/**
 * GymHub - Admin Panel Footer
 * admin/admin-footer.php
 *
 * Included at the bottom of every admin page.
 * It closes the divs opened in admin-header.php and outputs:
 *   1. Closing tags for .admin-content, .admin-main-wrap, .admin-layout
 *   2. The toggleSidebar() JavaScript function
 *   3. Closing </body> and </html> tags
 *
 * The toggleSidebar function is called by the ☰ button in the topbar.
 * It slides the sidebar off-screen on small screens to give more room
 * for the content. Clicking again brings the sidebar back.
 *
 * Note: There is no PHP opening tag at the top of this file because
 * it only outputs HTML — no PHP logic is needed here.
 */
?>

        </div><!-- closes .admin-content opened in admin-header.php -->
    </div><!-- closes .admin-main-wrap opened in admin-header.php -->
</div><!-- closes .admin-layout opened in admin-header.php -->

<!--
    Sidebar toggle JavaScript.
    Called when the ☰ hamburger button in the topbar is clicked.
    Slides the sidebar off-screen and expands the main content to full
    width. Clicking again reverses the effect. Works by toggling a CSS
    transform on the sidebar and adjusting the margin of the main wrap.
-->
<script>
function toggleSidebar() {
    const sidebar = document.getElementById('admin-sidebar');
    const main    = document.getElementById('admin-main-wrap');

    // Check current state — is the sidebar already hidden?
    const collapsed = sidebar.style.transform === 'translateX(-240px)';

    if (collapsed) {
        // Sidebar is hidden — bring it back into view
        sidebar.style.transform = '';                     // remove the slide-left transform
        main.style.marginLeft   = '240px';                // push content right to make room
        main.style.width        = 'calc(100% - 240px)';  // shrink content width to fit
    } else {
        // Sidebar is visible — hide it to free up screen space
        sidebar.style.transform = 'translateX(-240px)';  // slide sidebar off to the left
        main.style.marginLeft   = '0';                   // content takes the full width
        main.style.width        = '100%';
    }
}
</script>

</body>
</html>
