<?php
/**
 * GymHub - Admin: Theme Switcher
 * admin/theme.php
 *
 * Allows the admin to switch between three site-wide colour themes.
 * The active theme name is stored in the site_settings database table.
 * Every page reads it on load and includes the matching CSS file.
 *
 * Available themes:
 *   powerzone  → Dark charcoal + electric orange (default)
 *   zenfit     → Light white + sage green (calm/yoga feel)
 *   bluesteel  → Deep navy + steel blue (professional/premium)
 *
 * How it works:
 *   1. Admin clicks "Apply Theme" on one of the theme cards
 *   2. A POST form submits the theme name to this page
 *   3. We validate it against the whitelist (prevent unexpected values)
 *   4. We update the site_settings table with the new theme name
 *   5. header.php reads this value on every page and loads theme-X.css
 *   6. The whole site instantly looks different for all visitors
 *
 * This satisfies the "3 different site templates" requirement.
 */

$page_title = 'Theme Switcher';
$admin_page = 'theme';

require_once __DIR__ . '/admin-auth.php';

$success = '';

// ── Handle theme change ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['theme'])) {
    // Whitelist of allowed theme names — prevents setting an arbitrary value
    $allowed = ['powerzone', 'zenfit', 'bluesteel'];
    $theme   = in_array($_POST['theme'], $allowed) ? $_POST['theme'] : 'powerzone';

    // Update the active_theme value in the database
    $pdo->prepare("UPDATE site_settings SET setting_value=? WHERE setting_key='active_theme'")
        ->execute([$theme]);

    $success = 'Theme changed to ' . ucfirst($theme) . '! Refresh the site to see the change.';
}

// Read the currently active theme to highlight it in the UI
$current_theme = get_setting('active_theme') ?: 'powerzone';

// Theme definitions — each has a name, description, colour swatches, and preview label
$themes = [
    'powerzone' => [
        'name'    => 'PowerZone',
        'desc'    => 'Dark charcoal background with electric orange accents. Bold and energetic — the default GymHub look.',
        'colors'  => ['#0f0f0f', '#f97316', '#1a1a1a'], // shown as colour swatches
        'preview' => '🔥 Dark & Powerful',
    ],
    'zenfit' => [
        'name'    => 'ZenFit',
        'desc'    => 'Clean white background with calming sage green accents. Perfect for yoga and wellness-focused sessions.',
        'colors'  => ['#f8f7f4', '#5a7f5a', '#ffffff'],
        'preview' => '🌿 Light & Calm',
    ],
    'bluesteel' => [
        'name'    => 'BlueSteel',
        'desc'    => 'Deep navy background with steel blue accents. Professional and premium — great for a corporate feel.',
        'colors'  => ['#0d1b2a', '#4a9eda', '#132338'],
        'preview' => '💎 Navy & Professional',
    ],
];

require_once __DIR__ . '/admin-header.php';
?>

<?php if ($success): ?>
<div class="alert alert-success"><?= h($success) ?></div>
<?php endif; ?>

<!-- Theme selection card -->
<div class="admin-form-card" style="margin-bottom:var(--space-xl);">
    <h3>Site-Wide Theme</h3>
    <p style="color:var(--color-text-muted);margin-bottom:var(--space-xl);">
        Select a theme to apply it across the entire GymHub website instantly.
        The active theme is stored in the database and loads for all visitors.
    </p>

    <!-- Three theme cards in a grid -->
    <div class="theme-grid">
        <?php foreach ($themes as $slug => $theme): ?>
        <div class="theme-card <?= $current_theme === $slug ? 'theme-card--active' : '' ?>">

            <!-- Colour swatch preview — three coloured strips from the theme palette -->
            <div class="theme-preview">
                <?php foreach ($theme['colors'] as $color): ?>
                <div class="color-swatch" style="background:<?= $color ?>"></div>
                <?php endforeach; ?>
            </div>

            <div class="theme-info">
                <h4><?= $theme['name'] ?></h4>
                <p class="theme-preview-label"><?= $theme['preview'] ?></p>
                <p><?= $theme['desc'] ?></p>

                <?php if ($current_theme === $slug): ?>
                <!-- Currently active theme shows a badge instead of a button -->
                <span class="badge badge--success">✓ Currently Active</span>
                <?php else: ?>
                <!-- Other themes have an "Apply Theme" button that POSTs to this page -->
                <form method="POST" action="">
                    <input type="hidden" name="theme" value="<?= $slug ?>">
                    <button type="submit" class="btn btn-primary btn-sm">Apply Theme</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Developer info about how themes work technically -->
<div class="admin-form-card">
    <h3>How Themes Work</h3>
    <p style="color:var(--color-text-muted);line-height:1.8;">
        Each theme is a CSS file that overrides the colour variables defined in <code>main.css</code>.
        To add a new theme, create <code>public/css/theme-yourname.css</code> with overriding
        CSS variables, add it to the whitelist in this file's PHP, and add it to the $themes array above.
    </p>
    <div style="margin-top:var(--space-md);">
        <strong style="display:block;margin-bottom:var(--space-sm);color:var(--color-text);">Current theme files:</strong>
        <ul style="list-style:none;display:flex;flex-direction:column;gap:0.4rem;">
            <?php foreach (array_keys($themes) as $slug): ?>
            <li>
                <code style="background:var(--color-surface-2);padding:0.2rem 0.5rem;
                             border-radius:3px;font-size:0.85rem;color:var(--color-accent);">
                    public/css/theme-<?= $slug ?>.css
                    <?= $current_theme === $slug ? '← active' : '' ?>
                </code>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
