<?php
/**
 * GymHub - Admin: Site Monitoring
 * admin/monitoring.php
 *
 * A real-time status dashboard that checks all major site features
 * and reports whether each one is working correctly.
 *
 * Each "check" tests one aspect of the system and returns a status:
 *   online  → everything working fine (green dot)
 *   warning → working but something needs attention (yellow dot)
 *   offline → something is broken (red dot)
 *
 * Checks performed:
 *   1.  Database connection
 *   2.  Users table
 *   3.  Classes table
 *   4.  Bookings table
 *   5.  Session handling
 *   6.  File uploads directory
 *   7.  PHP version
 *   8.  Site settings table
 *   9.  Upcoming class schedule
 *  10.  Open Q&A questions
 *
 * Also shows a server information table at the bottom.
 *
 * This satisfies the "monitoring page reporting the status of the website"
 * backend requirement.
 */

$page_title = 'Site Monitoring';
$admin_page = 'monitoring';

require_once __DIR__ . '/admin-auth.php';

// ── Run all service checks ────────────────────────────────────────────────────
// Each check adds an entry to the $checks array with:
//   name   → the human-readable service name
//   status → 'online', 'warning', or 'offline'
//   detail → a short description of the result
$checks = [];

// Check 1: Database connection
// If we got here, the DB is connected (db.php would have crashed otherwise)
// But we run a simple query to double-confirm it's responding
try {
    $pdo->query("SELECT 1"); // the simplest possible query
    $checks['database'] = ['name' => 'Database Connection', 'status' => 'online', 'detail' => 'MySQL connected successfully'];
} catch (Exception $e) {
    $checks['database'] = ['name' => 'Database Connection', 'status' => 'offline', 'detail' => $e->getMessage()];
}

// Check 2: Users table
try {
    $count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $checks['users_table'] = ['name' => 'Users Table', 'status' => 'online', 'detail' => "$count records"];
} catch (Exception $e) {
    $checks['users_table'] = ['name' => 'Users Table', 'status' => 'offline', 'detail' => 'Table error'];
}

// Check 3: Classes table
try {
    $count = $pdo->query("SELECT COUNT(*) FROM classes WHERE status='active'")->fetchColumn();
    $checks['classes_table'] = ['name' => 'Classes Table', 'status' => 'online', 'detail' => "$count active classes"];
} catch (Exception $e) {
    $checks['classes_table'] = ['name' => 'Classes Table', 'status' => 'offline', 'detail' => 'Table error'];
}

// Check 4: Bookings table
try {
    $count = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
    $checks['bookings_table'] = ['name' => 'Bookings Table', 'status' => 'online', 'detail' => "$count total bookings"];
} catch (Exception $e) {
    $checks['bookings_table'] = ['name' => 'Bookings Table', 'status' => 'offline', 'detail' => 'Table error'];
}

// Check 5: Session handling — verifies PHP sessions are working
$checks['sessions'] = [
    'name'   => 'Session Handling',
    'status' => session_status() === PHP_SESSION_ACTIVE ? 'online' : 'offline',
    'detail' => session_status() === PHP_SESSION_ACTIVE
        ? 'Session active (ID: ' . substr(session_id(), 0, 12) . '...)'
        : 'Session not started'
];

// Check 6: File uploads directory
// The uploads folder is created automatically on first upload, but we check
// that it exists and is writable so trainer Q&A attachments will work
$upload_dir = dirname(__DIR__) . '/public/assets/uploads/';
$checks['uploads'] = [
    'name'   => 'File Uploads Directory',
    'status' => is_dir($upload_dir) && is_writable($upload_dir) ? 'online' : 'warning',
    'detail' => is_dir($upload_dir)
        ? (is_writable($upload_dir) ? 'Directory exists and is writable' : 'Directory exists but not writable')
        : 'Directory missing — will be created on first upload'
];

// Check 7: PHP version — we need 8.0+ for modern syntax we use
$php_ver = phpversion();
$checks['php'] = [
    'name'   => 'PHP Version',
    'status' => version_compare($php_ver, '8.0', '>=') ? 'online' : 'warning',
    'detail' => "PHP $php_ver" . (version_compare($php_ver, '8.0', '>=') ? ' — OK' : ' — PHP 8.0+ recommended')
];

// Check 8: Site settings table — needed for theme switching to work
try {
    $theme = get_setting('active_theme');
    $checks['site_settings'] = ['name' => 'Site Settings', 'status' => 'online', 'detail' => "Active theme: $theme"];
} catch (Exception $e) {
    $checks['site_settings'] = ['name' => 'Site Settings', 'status' => 'offline', 'detail' => 'Settings table error'];
}

// Check 9: Scheduled classes — warns if no upcoming sessions exist
// (Members won't be able to book anything if the schedule is empty)
try {
    $upcoming = $pdo->query("SELECT COUNT(*) FROM class_schedule WHERE date >= CURDATE()")->fetchColumn();
    $checks['schedule'] = [
        'name'   => 'Class Schedule',
        'status' => $upcoming > 0 ? 'online' : 'warning',
        'detail' => "$upcoming upcoming sessions"
    ];
} catch (Exception $e) {
    $checks['schedule'] = ['name' => 'Class Schedule', 'status' => 'offline', 'detail' => 'Error reading schedule'];
}

// Check 10: Open Q&A questions — just informational, always 'online'
try {
    $open_q = $pdo->query("SELECT COUNT(*) FROM questions WHERE status='open'")->fetchColumn();
    $checks['qa'] = [
        'name'   => 'Trainer Q&A',
        'status' => 'online',
        'detail' => "$open_q open question(s) awaiting response"
    ];
} catch (Exception $e) {
    $checks['qa'] = ['name' => 'Trainer Q&A', 'status' => 'offline', 'detail' => 'Error'];
}

// ── Summary counts for the banner ────────────────────────────────────────────
$online  = count(array_filter($checks, fn($c) => $c['status'] === 'online'));
$warning = count(array_filter($checks, fn($c) => $c['status'] === 'warning'));
$offline = count(array_filter($checks, fn($c) => $c['status'] === 'offline'));
$total   = count($checks);

require_once __DIR__ . '/admin-header.php';
?>

<!-- Overall status banner — colour changes based on worst status found -->
<div class="monitoring-banner monitoring-banner--<?= $offline > 0 ? 'danger' : ($warning > 0 ? 'warning' : 'success') ?>">
    <div class="monitoring-banner-icon">
        <?= $offline > 0 ? '🔴' : ($warning > 0 ? '🟡' : '🟢') ?>
    </div>
    <div>
        <h3><?= $offline > 0 ? 'System Issues Detected' : ($warning > 0 ? 'System Running with Warnings' : 'All Systems Operational') ?></h3>
        <p><?= $online ?>/<?= $total ?> services online · <?= $warning ?> warnings · <?= $offline ?> offline</p>
    </div>
    <div class="monitoring-timestamp">
        Last checked: <?= date('M j, Y g:i:s A') ?>
        <br>
        <!-- Refresh button simply reloads the page to re-run all checks -->
        <a href="monitoring.php" class="btn btn-secondary btn-sm" style="margin-top:0.5rem;">
            🔄 Refresh
        </a>
    </div>
</div>

<!-- Individual service check cards — two columns -->
<div class="monitoring-grid">
    <?php foreach ($checks as $check): ?>
    <div class="check-card check-card--<?= $check['status'] ?>">
        <!-- Animated pulsing dot for online services -->
        <div class="check-status-dot"></div>
        <div class="check-info">
            <strong><?= h($check['name']) ?></strong>
            <span><?= h($check['detail']) ?></span>
        </div>
        <span class="badge badge--<?= $check['status'] === 'online' ? 'success' : ($check['status'] === 'warning' ? 'warning' : 'danger') ?>">
            <?= ucfirst($check['status']) ?>
        </span>
    </div>
    <?php endforeach; ?>
</div>

<!-- Server information table — useful for debugging and documentation -->
<div class="admin-form-card" style="margin-top:var(--space-xl);">
    <h3>System Information</h3>
    <table class="admin-table" style="margin-top:var(--space-md);">
        <tbody>
            <tr><td><strong>PHP Version</strong></td><td><?= phpversion() ?></td></tr>
            <tr><td><strong>Server Software</strong></td><td><?= h($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') ?></td></tr>
            <tr><td><strong>Document Root</strong></td><td><?= h($_SERVER['DOCUMENT_ROOT'] ?? 'Unknown') ?></td></tr>
            <tr><td><strong>Current Server Time</strong></td><td><?= date('Y-m-d H:i:s') ?></td></tr>
            <tr><td><strong>PHP Max Upload Size</strong></td><td><?= ini_get('upload_max_filesize') ?></td></tr>
            <tr><td><strong>PHP Memory Limit</strong></td><td><?= ini_get('memory_limit') ?></td></tr>
            <tr><td><strong>Active Theme</strong></td><td><?= ucfirst(get_setting('active_theme')) ?></td></tr>
            <tr><td><strong>Maintenance Mode</strong></td><td><?= ucfirst(get_setting('maintenance_mode')) ?></td></tr>
            <tr><td><strong>Site Name</strong></td><td><?= h(get_setting('site_name')) ?></td></tr>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
