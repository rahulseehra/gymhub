<?php
/**
 * GymHub - Admin: Manage Users
 * admin/users.php
 *
 * Shows a searchable table of all registered users.
 * Admins can:
 *   - Enable or disable any user account (disabled users cannot log in)
 *   - Promote a member to admin role
 *   - Demote an admin back to member role
 *
 * Safety: An admin cannot modify their own account from this page.
 * This prevents accidentally locking yourself out.
 *
 * This satisfies the "User account administration features" requirement.
 */

$page_title = 'Manage Users';
$admin_page = 'users';

require_once __DIR__ . '/admin-auth.php';

$success = '';

// ── Handle POST actions ───────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action  = $_POST['action']  ?? '';
    $user_id = (int)($_POST['user_id'] ?? 0);

    // Safety check — admins cannot modify their own account from this panel
    if ($user_id === (int)$_SESSION['user_id']) {
        $success = 'You cannot modify your own account from this panel.';

    } elseif ($action === 'toggle_status' && $user_id) {
        // Enable or disable the user's account
        $new_status = $_POST['new_status'] ?? 'active';
        if (!in_array($new_status, ['active', 'disabled'])) $new_status = 'active';
        $pdo->prepare("UPDATE users SET status=? WHERE id=?")->execute([$new_status, $user_id]);
        $success = 'User account status updated.';

    } elseif ($action === 'make_admin' && $user_id) {
        // Promote member to admin — gives full admin panel access
        $pdo->prepare("UPDATE users SET role='admin' WHERE id=?")->execute([$user_id]);
        $success = 'User promoted to admin.';

    } elseif ($action === 'make_member' && $user_id) {
        // Demote admin back to regular member
        $pdo->prepare("UPDATE users SET role='member' WHERE id=?")->execute([$user_id]);
        $success = 'User role changed to member.';
    }
}

// ── Search filter ─────────────────────────────────────────────────────────────
// Allows searching by first name, last name, or email address
$search = trim($_GET['search'] ?? '');
$params = [];
$where  = [];

if ($search) {
    // Use LIKE with % wildcards for partial matching
    $where[]  = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Build the query — include a subquery to count each user's bookings
$sql = "SELECT u.*,
               (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.id AND b.status='confirmed') AS booking_count
        FROM users u"
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

require_once __DIR__ . '/admin-header.php';
?>

<?php if ($success): ?>
<div class="alert alert-success"><?= h($success) ?></div>
<?php endif; ?>

<div class="admin-table-card">
    <div class="admin-table-header">
        <h3>All Users (<?= count($users) ?>)</h3>
        <!-- Search form — submits as GET so the URL is shareable/bookmarkable -->
        <form method="GET" style="display:flex;gap:var(--space-sm);">
            <input type="text" name="search" value="<?= h($search) ?>"
                   placeholder="Search by name or email..."
                   style="background:var(--color-surface-2);border:1px solid var(--color-border);
                          color:var(--color-text);padding:0.4rem 0.75rem;border-radius:var(--radius-sm);
                          font-family:var(--font-body);outline:none;">
            <button type="submit" class="btn btn-secondary btn-sm">Search</button>
            <?php if ($search): ?>
            <a href="users.php" class="btn btn-secondary btn-sm">Clear</a>
            <?php endif; ?>
        </form>
    </div>
    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Bookings</th>
                    <th>Joined</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:var(--space-sm);">
                            <!-- Avatar circle shows first letter of name -->
                            <div style="width:30px;height:30px;border-radius:50%;background:var(--color-accent);
                                        color:#000;font-family:var(--font-display);font-weight:900;
                                        display:flex;align-items:center;justify-content:center;
                                        font-size:0.8rem;flex-shrink:0;">
                                <?= strtoupper(substr($u['first_name'], 0, 1)) ?>
                            </div>
                            <?= h($u['first_name'] . ' ' . $u['last_name']) ?>
                            <!-- "You" badge on the currently logged-in admin's row -->
                            <?php if ($u['id'] == $_SESSION['user_id']): ?>
                            <span class="badge badge--accent">You</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td><?= h($u['email']) ?></td>
                    <td>
                        <span class="badge badge--<?= $u['role'] === 'admin' ? 'danger' : 'muted' ?>">
                            <?= ucfirst($u['role']) ?>
                        </span>
                    </td>
                    <td><?= $u['booking_count'] ?></td>
                    <td><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <span class="badge badge--<?= $u['status'] === 'active' ? 'success' : 'danger' ?>">
                            <?= ucfirst($u['status']) ?>
                        </span>
                    </td>
                    <td>
                        <!-- Action buttons are hidden for the currently logged-in admin -->
                        <?php if ($u['id'] != $_SESSION['user_id']): ?>
                        <div class="table-actions">
                            <!-- Enable/Disable button -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action"     value="toggle_status">
                                <input type="hidden" name="user_id"    value="<?= $u['id'] ?>">
                                <input type="hidden" name="new_status" value="<?= $u['status'] === 'active' ? 'disabled' : 'active' ?>">
                                <button type="submit"
                                        class="btn btn-sm <?= $u['status'] === 'active' ? 'btn-danger' : 'btn-secondary' ?>">
                                    <?= $u['status'] === 'active' ? 'Disable' : 'Enable' ?>
                                </button>
                            </form>
                            <!-- Role toggle — promote or demote -->
                            <?php if ($u['role'] === 'member'): ?>
                            <form method="POST" style="display:inline;"
                                  onsubmit="return confirm('Promote this user to admin?')">
                                <input type="hidden" name="action"  value="make_admin">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <button type="submit" class="btn btn-secondary btn-sm">Make Admin</button>
                            </form>
                            <?php else: ?>
                            <form method="POST" style="display:inline;"
                                  onsubmit="return confirm('Demote this admin to member?')">
                                <input type="hidden" name="action"  value="make_member">
                                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                <button type="submit" class="btn btn-secondary btn-sm">Make Member</button>
                            </form>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <span style="color:var(--color-text-muted);font-size:0.8rem;">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
