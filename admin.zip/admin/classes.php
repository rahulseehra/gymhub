<?php
/**
 * GymHub - Admin: Manage Classes
 * admin/classes.php
 *
 * Allows admins to add, edit, and activate/deactivate fitness classes.
 * This is the content management page for the 20 class "products".
 *
 * Three URL actions controlled via ?action= parameter:
 *   list  (default) — shows the full classes table
 *   add             — shows the empty Add New Class form
 *   edit&id=X       — shows the Edit form pre-filled with class X's data
 *
 * Three POST form_action values handled:
 *   add            — INSERT a new class record into the database
 *   edit           — UPDATE an existing class record
 *   toggle_status  — Switch a class between active and inactive
 *
 * This satisfies the "Enable the editing functionality of data records"
 * admin panel requirement from the project spec.
 *
 * HOW TO ADD A NEW CLASS (for non-developers):
 *   1. Log in as admin
 *   2. Go to Admin → Manage Classes
 *   3. Click "Add Class"
 *   4. Fill in all fields and set Status to Active
 *   5. Click Add Class — it will immediately appear in the member catalog
 */

$page_title = 'Manage Classes';
$admin_page = 'classes'; // highlights "Manage Classes" in the sidebar

// Load auth guard — non-admins are redirected to login immediately
require_once __DIR__ . '/admin-auth.php';

$success = '';
$errors  = [];

// Read which action to show — defaults to 'list' if not in URL
$action  = $_GET['action'] ?? 'list';

// When editing, read the class ID from the URL
$edit_id    = (int)($_GET['id'] ?? 0);
$edit_class = null; // will hold the existing class data when action=edit

// ── Load instructors for the assignment dropdown ──────────────────────────────
// Loaded regardless of action because the form needs them on both add and edit
$instructors = $pdo->query("
    SELECT i.id, CONCAT(u.first_name, ' ', u.last_name) AS name
    FROM instructors i
    JOIN users u ON i.user_id = u.id
    ORDER BY name ASC
")->fetchAll();

// ── Handle POST form submissions ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $post_action = $_POST['form_action'] ?? '';

    // ── Add or edit a class ───────────────────────────────────────────────────
    if (in_array($post_action, ['add', 'edit'])) {

        // Collect and sanitize all text form fields
        $title         = trim($_POST['title']          ?? '');
        $category      = trim($_POST['category']       ?? '');
        $description   = trim($_POST['description']    ?? '');
        $instructor_id = (int)($_POST['instructor_id'] ?? 0); // 0 = no instructor
        $capacity      = (int)($_POST['capacity']      ?? 20);
        $duration_min  = (int)($_POST['duration_min']  ?? 60);
        $price         = (float)($_POST['price']       ?? 0);
        $option_label  = trim($_POST['option_label']   ?? 'Level');
        $option_a      = trim($_POST['option_a']       ?? '');
        $option_b      = trim($_POST['option_b']       ?? '');

        // Whitelist status to prevent unexpected values being inserted
        $status = ($_POST['status'] ?? '') === 'active' ? 'active' : 'inactive';

        // Validate required fields
        if (empty($title))       $errors[] = 'Class title is required.';
        if (empty($category))    $errors[] = 'Category is required.';
        if (empty($description)) $errors[] = 'Description is required.';
        if ($price <= 0)         $errors[] = 'Price must be greater than $0.';
        if (empty($option_a))    $errors[] = 'Option A is required (e.g. Beginner).';
        if (empty($option_b))    $errors[] = 'Option B is required (e.g. Advanced).';

        if (empty($errors)) {

            if ($post_action === 'add') {
                // INSERT a brand new class record
                $pdo->prepare("
                    INSERT INTO classes
                        (title, category, description, instructor_id,
                         capacity, duration_min, price,
                         option_label, option_a, option_b, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ")->execute([
                    $title, $category, $description,
                    $instructor_id ?: null, // store NULL if no instructor selected
                    $capacity, $duration_min, $price,
                    $option_label, $option_a, $option_b, $status
                ]);
                $success = "Class '{$title}' added successfully! It is now {$status}.";
                $action  = 'list'; // return to list after adding

            } else {
                // UPDATE existing class record
                // Read the class ID from the hidden form field (not the URL)
                $edit_id_post = (int)($_POST['edit_id'] ?? 0);
                $pdo->prepare("
                    UPDATE classes
                    SET title=?, category=?, description=?,
                        instructor_id=?, capacity=?, duration_min=?,
                        price=?, option_label=?, option_a=?, option_b=?, status=?
                    WHERE id=?
                ")->execute([
                    $title, $category, $description,
                    $instructor_id ?: null,
                    $capacity, $duration_min, $price,
                    $option_label, $option_a, $option_b, $status,
                    $edit_id_post
                ]);
                $success = "Class '{$title}' updated successfully!";
                $action  = 'list'; // return to list after saving
            }
        }
    }

    // ── Toggle class active/inactive ─────────────────────────────────────────
    if ($post_action === 'toggle_status') {
        $toggle_id  = (int)($_POST['class_id']   ?? 0);
        // Whitelist to prevent arbitrary status values
        $new_status = $_POST['new_status'] ?? 'active';
        if (!in_array($new_status, ['active', 'inactive'])) $new_status = 'active';

        $pdo->prepare("UPDATE classes SET status=? WHERE id=?")
            ->execute([$new_status, $toggle_id]);

        $label   = $new_status === 'active' ? 'activated' : 'deactivated';
        $success = "Class {$label} successfully.";
    }
}

// ── Load existing class data when editing ─────────────────────────────────────
// Only runs when action=edit — fetches the class to pre-fill the form
if ($action === 'edit' && $edit_id) {
    $stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_class = $stmt->fetch();

    // If class ID doesn't exist in DB, fall back to list view
    if (!$edit_class) $action = 'list';
}

// ── Load all classes for the table ───────────────────────────────────────────
// LEFT JOIN instructors and users to show the instructor name in the table
// Active classes appear first, then inactive, both sorted alphabetically
$classes = $pdo->query("
    SELECT c.*,
           CONCAT(u.first_name, ' ', u.last_name) AS instructor_name
    FROM classes c
    LEFT JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN users u       ON i.user_id = u.id
    ORDER BY c.status DESC, c.title ASC
")->fetchAll();

// Allowed category names for the category dropdown
$categories = [
    'Strength', 'Cardio', 'Yoga', 'Combat', 'Pilates',
    'Dance', 'CrossFit', 'Swimming', 'Recovery', 'Wellness', 'Kids'
];

require_once __DIR__ . '/admin-header.php';
?>

<!-- Feedback messages from form submissions -->
<?php if ($success): ?>
<div class="alert alert-success"><?= h($success) ?></div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
<div class="alert alert-danger">
    <ul><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════
     ADD / EDIT FORM
     Only shown when action=add or action=edit.
     Hidden on the default list view.
     ══════════════════════════════════════════════════════════ -->
<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-form-card">
    <h3><?= $action === 'add' ? '➕ Add New Class' : '✏️ Edit: ' . h($edit_class['title']) ?></h3>

    <form method="POST" action="" class="admin-form">

        <!-- Hidden: tells the POST handler whether this is add or edit -->
        <input type="hidden" name="form_action" value="<?= $action ?>">

        <?php if ($action === 'edit'): ?>
        <!-- Hidden: passes the class ID back on edit so we know which record to UPDATE -->
        <input type="hidden" name="edit_id" value="<?= $edit_class['id'] ?>">
        <?php endif; ?>

        <!-- Title + Category -->
        <div class="form-row">
            <div class="form-group">
                <label>Class Title *</label>
                <!-- Value repopulated from $edit_class when editing, empty when adding -->
                <input type="text" name="title"
                       value="<?= h($edit_class['title'] ?? '') ?>"
                       placeholder="e.g. Morning HIIT Bootcamp" required>
            </div>
            <div class="form-group">
                <label>Category *</label>
                <select name="category" required>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat ?>"
                        <?= ($edit_class['category'] ?? '') === $cat ? 'selected' : '' ?>>
                        <?= $cat ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Description -->
        <div class="form-group">
            <label>Description *</label>
            <textarea name="description" rows="3"
                      placeholder="Describe what members will experience in this class..."
                      required><?= h($edit_class['description'] ?? '') ?></textarea>
        </div>

        <!-- Instructor + Capacity + Duration -->
        <div class="form-row-3">
            <div class="form-group">
                <label>Instructor</label>
                <select name="instructor_id">
                    <option value="">-- Unassigned --</option>
                    <?php foreach ($instructors as $inst): ?>
                    <option value="<?= $inst['id'] ?>"
                        <?= ($edit_class['instructor_id'] ?? '') == $inst['id'] ? 'selected' : '' ?>>
                        <?= h($inst['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Max Capacity</label>
                <input type="number" name="capacity"
                       value="<?= $edit_class['capacity'] ?? 20 ?>"
                       min="1" max="100"
                       title="Maximum number of participants per session">
            </div>
            <div class="form-group">
                <label>Duration (minutes)</label>
                <input type="number" name="duration_min"
                       value="<?= $edit_class['duration_min'] ?? 60 ?>"
                       min="15" max="180">
            </div>
        </div>

        <!-- Price + Status -->
        <div class="form-row">
            <div class="form-group">
                <label>Price per Session ($) *</label>
                <input type="number" name="price"
                       value="<?= $edit_class['price'] ?? '' ?>"
                       step="0.01" min="0.01" required
                       placeholder="e.g. 25.00">
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <!-- Active = visible in the member catalog -->
                    <option value="active"
                        <?= ($edit_class['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>
                        Active — visible to members
                    </option>
                    <!-- Inactive = hidden from catalog but data preserved -->
                    <option value="inactive"
                        <?= ($edit_class['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>
                        Inactive — hidden from members
                    </option>
                </select>
            </div>
        </div>

        <!-- Option fields — the two format choices members select when booking -->
        <div class="form-row-3">
            <div class="form-group">
                <label>Option Label (e.g. "Level")</label>
                <input type="text" name="option_label"
                       value="<?= h($edit_class['option_label'] ?? 'Level') ?>"
                       placeholder="Level">
            </div>
            <div class="form-group">
                <label>Option A * (e.g. "Beginner")</label>
                <input type="text" name="option_a"
                       value="<?= h($edit_class['option_a'] ?? '') ?>"
                       required placeholder="Beginner">
            </div>
            <div class="form-group">
                <label>Option B * (e.g. "Advanced")</label>
                <input type="text" name="option_b"
                       value="<?= h($edit_class['option_b'] ?? '') ?>"
                       required placeholder="Advanced">
            </div>
        </div>

        <!-- Submit and cancel buttons -->
        <div style="display:flex;gap:var(--space-md);">
            <button type="submit" class="btn btn-primary">
                <?= $action === 'add' ? '➕ Add Class' : '💾 Save Changes' ?>
            </button>
            <!-- Cancel returns to the list without saving -->
            <a href="classes.php" class="btn btn-secondary">Cancel</a>
        </div>

    </form>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════
     ALL CLASSES TABLE
     Always shown — even while the form is open above.
     Admins can see all classes at a glance while editing.
     ══════════════════════════════════════════════════════════ -->
<div class="admin-table-card">
    <div class="admin-table-header">
        <h3>All Classes (<?= count($classes) ?>)</h3>
        <!-- Button opens the Add Class form above -->
        <a href="classes.php?action=add" class="btn btn-primary btn-sm">➕ Add Class</a>
    </div>

    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Instructor</th>
                    <th>Price</th>
                    <th>Duration</th>
                    <th>Options</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($classes as $c): ?>
                <tr>
                    <td><strong><?= h($c['title']) ?></strong></td>
                    <td><?= h($c['category']) ?></td>
                    <td><?= h($c['instructor_name'] ?? '—') ?></td>
                    <td>$<?= number_format($c['price'], 2) ?></td>
                    <td><?= $c['duration_min'] ?> min</td>
                    <td>
                        <!-- Show both options in small text -->
                        <small style="color:var(--color-text-muted);">
                            <?= h($c['option_a']) ?> / <?= h($c['option_b']) ?>
                        </small>
                    </td>
                    <td>
                        <!-- Green badge for active, grey for inactive -->
                        <span class="badge badge--<?= $c['status'] === 'active' ? 'success' : 'muted' ?>">
                            <?= ucfirst($c['status']) ?>
                        </span>
                    </td>
                    <td>
                        <div class="table-actions">

                            <!-- Edit button — links to the edit form for this class -->
                            <a href="classes.php?action=edit&id=<?= $c['id'] ?>"
                               class="btn btn-secondary btn-sm">
                                ✏️ Edit
                            </a>

                            <!-- Toggle status form — activates or deactivates the class
                                 The new_status is always the OPPOSITE of the current status -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="form_action" value="toggle_status">
                                <input type="hidden" name="class_id"    value="<?= $c['id'] ?>">
                                <!-- Submit will set the class to the opposite status -->
                                <input type="hidden" name="new_status"
                                       value="<?= $c['status'] === 'active' ? 'inactive' : 'active' ?>">
                                <button type="submit"
                                        class="btn btn-sm <?= $c['status'] === 'active' ? 'btn-danger' : 'btn-secondary' ?>">
                                    <?= $c['status'] === 'active' ? '⏸ Deactivate' : '▶ Activate' ?>
                                </button>
                            </form>

                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
