<?php
/**
 * GymHub - Admin Dashboard
 * admin/dashboard.php
 *
 * The main overview page of the admin panel.
 * Shows key stats, recent activity, and quick action buttons.
 *
 * What this page displays:
 *   - Four stat cards: total members, confirmed bookings, active classes, open questions
 *   - Total revenue calculated from all confirmed bookings
 *   - A bar chart showing bookings broken down by class category (Chart.js)
 *   - A table of the 8 most recent bookings
 *   - A table of the 5 most recently registered members
 *   - Quick action buttons linking to common admin tasks
 */

$page_title = 'Dashboard';  // shown in browser tab and admin topbar
$admin_page = 'dashboard';  // highlights "Dashboard" in the sidebar

// Load auth guard first — redirects non-admins away immediately
require_once __DIR__ . '/admin-auth.php';

// ── Stats queries ─────────────────────────────────────────────────────────────
// These simple COUNT queries give us the headline numbers for the stat cards.
// fetchColumn() returns just the single number result directly.
$total_users    = $pdo->query("SELECT COUNT(*) FROM users WHERE role='member'")->fetchColumn();
$total_bookings = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='confirmed'")->fetchColumn();
$total_classes  = $pdo->query("SELECT COUNT(*) FROM classes WHERE status='active'")->fetchColumn();
$open_questions = $pdo->query("SELECT COUNT(*) FROM questions WHERE status='open'")->fetchColumn();

// Calculate total revenue by summing the price of every confirmed booking.
// We JOIN through class_schedule to get to the classes table where price lives.
$total_revenue = $pdo->query("
    SELECT SUM(c.price)
    FROM bookings b
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    WHERE b.status = 'confirmed'
")->fetchColumn();

// ── Recent bookings ───────────────────────────────────────────────────────────
// Get the 8 most recent bookings with member name, class name, date, and time.
// Multiple JOINs are needed because the data spans 4 tables.
$recent_bookings = $pdo->query("
    SELECT b.*, c.title, c.price,
           CONCAT(u.first_name,' ',u.last_name) AS member_name,
           cs.date, cs.time
    FROM bookings b
    JOIN users u          ON b.user_id      = u.id
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    ORDER BY b.booked_at DESC
    LIMIT 8
")->fetchAll();

// ── Recent registrations ──────────────────────────────────────────────────────
// Show the 5 most recently created member accounts.
$recent_users = $pdo->query("
    SELECT * FROM users
    WHERE role = 'member'
    ORDER BY created_at DESC
    LIMIT 5
")->fetchAll();

// ── Bookings by category ──────────────────────────────────────────────────────
// Used to build the bar chart. Counts confirmed bookings grouped by class category.
// json_encode() later converts this PHP array to JavaScript for Chart.js.
$cat_bookings = $pdo->query("
    SELECT c.category, COUNT(*) as cnt
    FROM bookings b
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    WHERE b.status = 'confirmed'
    GROUP BY c.category
    ORDER BY cnt DESC
")->fetchAll();

// Load the admin header (outputs HTML head, sidebar, topbar)
require_once __DIR__ . '/admin-header.php';
?>

<!-- ── Four stat cards ── -->
<div class="admin-stats">
    <div class="admin-stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-info">
            <strong><?= $total_users ?></strong>
            <span>Total Members</span>
        </div>
    </div>
    <div class="admin-stat-card">
        <div class="stat-icon">📅</div>
        <div class="stat-info">
            <strong><?= $total_bookings ?></strong>
            <span>Confirmed Bookings</span>
        </div>
    </div>
    <div class="admin-stat-card">
        <div class="stat-icon">🏋️</div>
        <div class="stat-info">
            <strong><?= $total_classes ?></strong>
            <span>Active Classes</span>
        </div>
    </div>
    <div class="admin-stat-card">
        <div class="stat-icon">💬</div>
        <div class="stat-info">
            <strong><?= $open_questions ?></strong>
            <span>Open Questions</span>
        </div>
    </div>
</div>

<!-- ── Main two-column grid: recent bookings table + right column ── -->
<div class="dashboard-grid">

    <!-- Left: recent bookings table -->
    <div class="admin-table-card">
        <div class="admin-table-header">
            <h3>Recent Bookings</h3>
            <a href="bookings.php" class="btn btn-secondary btn-sm">View All</a>
        </div>
        <div style="overflow-x:auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Member</th>
                        <th>Class</th>
                        <th>Date</th>
                        <th>Option</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_bookings as $b): ?>
                    <tr>
                        <td><?= h($b['member_name']) ?></td>
                        <td><?= h($b['title']) ?></td>
                        <td><?= date('M j, Y', strtotime($b['date'])) ?></td>
                        <td><?= h($b['option_choice']) ?></td>
                        <!-- Badge colour changes based on status value -->
                        <td>
                            <span class="badge badge--<?= $b['status'] === 'confirmed' ? 'success' : 'muted' ?>">
                                <?= ucfirst($b['status']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right column: revenue, chart, new members -->
    <div class="dashboard-right">

        <!-- Revenue total card -->
        <div class="admin-form-card" style="text-align:center;padding:var(--space-xl);">
            <p style="color:var(--color-text-muted);font-size:0.8rem;text-transform:uppercase;
                      letter-spacing:0.08em;font-family:var(--font-display);font-weight:700;">
                Total Revenue
            </p>
            <!-- (float) cast ensures we don't get an error if the SUM returns NULL -->
            <div style="font-family:var(--font-display);font-size:3rem;font-weight:900;color:var(--color-accent);">
                $<?= number_format((float)$total_revenue, 2) ?>
            </div>
            <p style="color:var(--color-text-muted);font-size:0.85rem;">From all confirmed bookings</p>
        </div>

        <!-- Bookings by category bar chart using Chart.js -->
        <div class="admin-form-card">
            <h3 style="margin-bottom:var(--space-md);">Bookings by Category</h3>
            <!-- Chart.js draws into this canvas element -->
            <canvas id="catChart" height="200"></canvas>
        </div>

        <!-- Recently registered members table -->
        <div class="admin-table-card">
            <div class="admin-table-header">
                <h3>New Members</h3>
                <a href="users.php" class="btn btn-secondary btn-sm">View All</a>
            </div>
            <table class="admin-table">
                <thead>
                    <tr><th>Name</th><th>Joined</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_users as $u): ?>
                    <tr>
                        <td><?= h($u['first_name'] . ' ' . $u['last_name']) ?></td>
                        <td><?= date('M j', strtotime($u['created_at'])) ?></td>
                        <td>
                            <span class="badge badge--<?= $u['status'] === 'active' ? 'success' : 'danger' ?>">
                                <?= ucfirst($u['status']) ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ── Quick action buttons ── -->
<div class="quick-actions">
    <h3>Quick Actions</h3>
    <div class="quick-actions-grid">
        <a href="classes.php?action=add" class="quick-action-card">
            <span>➕</span> Add New Class
        </a>
        <a href="qa.php" class="quick-action-card">
            <span>💬</span> Answer Questions
            <!-- Show badge with count of open questions -->
            <span class="badge badge--danger"><?= $open_questions ?></span>
        </a>
        <a href="theme.php" class="quick-action-card">
            <span>🎨</span> Switch Theme
        </a>
        <a href="monitoring.php" class="quick-action-card">
            <span>🔌</span> Site Monitoring
        </a>
    </div>
</div>

<!-- Chart.js library loaded from CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
// Pass PHP data to JavaScript using json_encode()
// This converts the PHP array into a JavaScript array safely
const catData = <?= json_encode($cat_bookings) ?>;

// Build the bar chart inside the #catChart canvas element
new Chart(document.getElementById('catChart'), {
    type: 'bar',
    data: {
        labels: catData.map(d => d.category),  // category names on X axis
        datasets: [{
            label: 'Bookings',
            data: catData.map(d => d.cnt),      // booking counts on Y axis
            backgroundColor: 'rgba(249,115,22,0.2)', // transparent orange bars
            borderColor: '#f97316',                   // solid orange border
            borderWidth: 2,
            borderRadius: 4  // rounded bar tops
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } }, // hide the legend (only one dataset)
        scales: {
            x: { ticks: { color: '#888' }, grid: { color: '#2e2e2e' } },
            y: { ticks: { color: '#888' }, grid: { color: '#2e2e2e' }, beginAtZero: true }
        }
    }
});
</script>

<style>
/* Dashboard-specific layout styles */
.dashboard-grid {
    display: grid;
    grid-template-columns: 1fr 360px; /* table takes most width, right column is fixed */
    gap: var(--space-xl);
    margin-bottom: var(--space-xl);
}
.dashboard-right { display: flex; flex-direction: column; gap: var(--space-lg); }
.quick-actions h3 { margin-bottom: var(--space-md); }
.quick-actions-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: var(--space-md); }
.quick-action-card {
    background: var(--color-surface); border: 1px solid var(--color-border);
    border-radius: var(--radius-lg); padding: var(--space-lg);
    text-align: center; text-decoration: none; color: var(--color-text-muted);
    font-size: 0.875rem; display: flex; flex-direction: column;
    gap: var(--space-sm); align-items: center; transition: all var(--transition-normal);
}
.quick-action-card span:first-child { font-size: 1.5rem; }
.quick-action-card:hover { border-color: var(--color-accent); color: var(--color-accent); transform: translateY(-2px); }
@media(max-width:1024px) {
    .dashboard-grid { grid-template-columns: 1fr; }
    .quick-actions-grid { grid-template-columns: repeat(2,1fr); }
}
</style>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
