<?php
/**
 * GymHub - Admin Authentication Guard
 * admin/admin-auth.php
 *
 * This tiny file is included at the very top of every admin page.
 * Its only job is to make sure the person trying to view the page
 * is actually logged in AND has the admin role.
 *
 * If they are not logged in → they get sent to the login page.
 * If they are logged in but not an admin → same thing, login page.
 * Only real admins get through and see the page content.
 *
 * This is called a "gate" or "guard" pattern — one reusable file
 * that protects all admin pages instead of repeating the same
 * check on every single admin file.
 *
 * HOW TO USE:
 * Add this as the second line of any admin page (after setting $page_title):
 *   require_once __DIR__ . '/admin-auth.php';
 */

// Load db.php first — we need is_logged_in() and is_admin() which are defined there.
// dirname(__DIR__) goes up one level from /admin/ to the project root, then into /config/
require_once dirname(__DIR__) . '/config/db.php';

// Check if the visitor is logged in AND has the admin role.
// If either check fails, redirect them to the login page immediately.
// We also pass the current URL as a 'redirect' parameter so after they
// log in they can be sent back to the admin page they were trying to reach.
if (!is_logged_in() || !is_admin()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
}
// If we get past this point, the user is confirmed to be an admin.
// The rest of the admin page code runs normally.
