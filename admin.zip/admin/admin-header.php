<?php
/**
 * GymHub - Admin Panel Header
 * admin/admin-header.php
 *
 * This file is included at the top of every admin page.
 * It outputs the full HTML <head>, the sidebar navigation,
 * and the top bar with the page title.
 *
 * HOW TO USE ON A NEW ADMIN PAGE:
 * Before including this file, set these variables:
 *
 *   $page_title = 'My Admin Page';   // shown in the topbar and browser tab
 *   $admin_page = 'dashboard';       // highlights the matching sidebar link
 *
 * Then include:
 *   require_once __DIR__ . '/admin-header.php';
 *
 * The active theme is read from the database so the admin panel
 * matches whatever theme is currently active on the public site.
 *
 * NOTE: This file uses <div class="admin-main-wrap"> instead of <main>
 * to avoid conflicts with public site CSS that targets the <main> element.
 */

// Start output buffering so redirects work even if output has started
ob_start();

// Start session if not already running
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load db config — gives us $pdo, SITE_URL, helper functions
require_once dirname(__DIR__) . '/config/db.php';

// Default values in case the admin page hasn't set them
$admin_page   = $admin_page   ?? '';
$active_theme = get_setting('active_theme') ?: 'powerzone'; // read theme from DB
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($page_title ?? 'Admin Panel') ?> | GymHub Admin</title>
    <!-- Tell search engines not to index admin pages — they're private -->
    <meta name="robots" content="noindex, nofollow">

    <!-- Google Fonts — same as public site for consistency -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Base site styles (colours, typography, buttons etc.) -->
    <link rel="stylesheet" href="<?= SITE_URL ?>/public/css/main.css">
    <!-- Active theme overrides (changes colour variables) -->
    <link rel="stylesheet" href="<?= SITE_URL ?>/public/css/theme-<?= h($active_theme) ?>.css">
    <!-- Admin-specific layout styles (sidebar, tables, admin forms) -->
    <link rel="stylesheet" href="<?= SITE_URL ?>/public/css/admin.css">

    <style>
        /*
         * Emergency inline overrides.
         * These use !important to guarantee the admin layout works
         * correctly regardless of CSS load order or caching issues.
         * They fix the narrow-column problem caused by public site
         * styles accidentally affecting the admin layout.
         */
        html, body { margin: 0; padding: 0; }
        body { display: block !important; }
        .announcement-bar { display: none !important; } /* hide public announcement bar */
        .site-header      { display: none !important; } /* hide public nav header */
        #main-content     { all: unset; display: block !important; } /* reset public main styles */

        /* Force the two-column admin layout to work */
        .admin-layout {
            display: flex !important;
            min-height: 100vh;
            width: 100%;
        }
        .admin-sidebar {
            width: 240px !important;
            min-width: 240px !important;
            flex-shrink: 0 !important;
            position: fixed !important;
            left: 0; top: 0;
            height: 100vh;
            overflow-y: auto;
            z-index: 200;
        }
        .admin-main-wrap {
            margin-left: 240px !important;
            flex: 1 !important;
            min-width: 0 !important;
            width: calc(100% - 240px) !important;
            display: flex !important;
            flex-direction: column !important;
        }
        .admin-content {
            padding: 24px !important;
            width: 100% !important;
            box-sizing: border-box !important;
        }
    </style>
</head>
<body class="theme-<?= h($active_theme) ?>">

<!-- Outer wrapper for the two-column admin layout (sidebar + main) -->
<div class="admin-layout">

    <!-- ════════════════════════════════════════════════════
         LEFT SIDEBAR NAVIGATION
         Fixed position, full height, always visible.
         Each link has an 'active' class if $admin_page matches.
         ════════════════════════════════════════════════════ -->
    <div class="admin-sidebar" id="admin-sidebar">

        <!-- Sidebar header — logo and ADMIN badge -->
        <div class="admin-sidebar-header">
            <a href="<?= SITE_URL ?>/index.php" class="admin-logo">
                <span>⚡</span> GYM<strong>HUB</strong>
            </a>
            <span class="admin-badge">Admin</span>
        </div>

        <!-- Navigation links grouped into sections -->
        <nav class="admin-nav">

            <!-- Overview section -->
            <div class="admin-nav-section">
                <span class="nav-section-label">Overview</span>
                <a href="<?= SITE_URL ?>/admin/dashboard.php"
                   class="admin-nav-link <?= $admin_page === 'dashboard' ? 'active' : '' ?>">
                    📊 Dashboard
                </a>
                <a href="<?= SITE_URL ?>/admin/monitoring.php"
                   class="admin-nav-link <?= $admin_page === 'monitoring' ? 'active' : '' ?>">
                    🔌 Site Monitoring
                </a>
            </div>

            <!-- Content management section -->
            <div class="admin-nav-section">
                <span class="nav-section-label">Content</span>
                <a href="<?= SITE_URL ?>/admin/classes.php"
                   class="admin-nav-link <?= $admin_page === 'classes' ? 'active' : '' ?>">
                    🏋️ Manage Classes
                </a>
                <a href="<?= SITE_URL ?>/admin/bookings.php"
                   class="admin-nav-link <?= $admin_page === 'bookings' ? 'active' : '' ?>">
                    📅 All Bookings
                </a>
                <a href="<?= SITE_URL ?>/admin/qa.php"
                   class="admin-nav-link <?= $admin_page === 'qa' ? 'active' : '' ?>">
                    💬 Trainer Q&amp;A
                </a>
            </div>

            <!-- User management section -->
            <div class="admin-nav-section">
                <span class="nav-section-label">Users</span>
                <a href="<?= SITE_URL ?>/admin/users.php"
                   class="admin-nav-link <?= $admin_page === 'users' ? 'active' : '' ?>">
                    👥 Manage Users
                </a>
            </div>

            <!-- Settings section -->
            <div class="admin-nav-section">
                <span class="nav-section-label">Settings</span>
                <a href="<?= SITE_URL ?>/admin/theme.php"
                   class="admin-nav-link <?= $admin_page === 'theme' ? 'active' : '' ?>">
                    🎨 Theme Switcher
                </a>
            </div>

            <!-- Site links section -->
            <div class="admin-nav-section">
                <span class="nav-section-label">Site</span>
                <a href="<?= SITE_URL ?>/index.php" class="admin-nav-link">
                    🌐 View Website
                </a>
                <!-- Red colour applied via admin-nav-link--danger CSS class -->
                <a href="<?= SITE_URL ?>/pages/logout.php" class="admin-nav-link admin-nav-link--danger">
                    🚪 Log Out
                </a>
            </div>
        </nav>

        <!-- Sidebar footer — shows logged-in admin's name and initial -->
        <div class="admin-sidebar-footer">
            <div class="admin-user-info">
                <!-- Avatar circle shows first letter of admin's name -->
                <div class="admin-avatar">
                    <?= strtoupper(substr($_SESSION['first_name'] ?? 'A', 0, 1)) ?>
                </div>
                <div>
                    <strong><?= h(($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '')) ?></strong>
                    <span>Administrator</span>
                </div>
            </div>
        </div>
    </div><!-- end .admin-sidebar -->

    <!-- ════════════════════════════════════════════════════
         MAIN CONTENT WRAPPER
         Everything to the right of the sidebar.
         We use a div (not <main>) to avoid public CSS conflicts.
         ════════════════════════════════════════════════════ -->
    <div class="admin-main-wrap" id="admin-main-wrap">

        <!-- Top bar — hamburger toggle, page title, theme indicator -->
        <div class="admin-topbar">
            <!-- Clicking this button runs toggleSidebar() in admin-footer.php -->
            <button class="sidebar-toggle" onclick="toggleSidebar()" aria-label="Toggle sidebar">☰</button>
            <h1 class="admin-page-title"><?= h($page_title ?? 'Admin Panel') ?></h1>
            <div class="admin-topbar-right">
                <span class="theme-indicator">Theme: <strong><?= ucfirst($active_theme) ?></strong></span>
            </div>
        </div>

        <!-- Page-specific content goes between this div and admin-footer.php -->
        <div class="admin-content">
