<?php
/**
 * GymHub - Admin: All Bookings
 * admin/bookings.php
 *
 * Shows a filterable table of every booking ever made on the site.
 * This is the admin view — it shows ALL members' bookings, not just one user's.
 * (The member-facing My Bookings page is at pages/bookings.php)
 *
 * Features:
 *   - Filter tabs: All / Confirmed / Cancelled / Completed
 *   - Shows member name, class name, date, time, room, option, price, status
 *   - Limited to 100 most recent bookings for performance
 *   - Colour-coded status badges: green=confirmed, red=cancelled, grey=completed
 *
 * This satisfies the "User account administration" and "editing data records"
 * admin panel requirements.
 */

$page_title = 'All Bookings';
$admin_page = 'bookings'; // highlights "All Bookings" link in sidebar

// Load auth guard — redirects anyone who isn't a logged-in admin
require_once __DIR__ . '/admin-auth.php';

// ── Read status filter from URL ───────────────────────────────────────────────
// Empty string means show all statuses (no filter applied)
$filter_status = $_GET['status'] ?? '';

// ── Build WHERE clause dynamically ───────────────────────────────────────────
// We only add a WHERE condition if a filter is actually selected
$where  = [];
$params = [];

if ($filter_status) {
    // Whitelist check: only allow known status values to prevent injection
    $allowed = ['confirmed', 'cancelled', 'completed'];
    if (in_array($filter_status, $allowed)) {
        $where[]  = "b.status = ?";
        $params[] = $filter_status;
    }
}

// ── Main query — joins 4 tables ───────────────────────────────────────────────
// bookings → users              to get the member's full name
// bookings → class_schedule     to get the session date, time, and room
// class_schedule → classes      to get the class name and price
// All JOINs use indexed foreign key columns for performance
$sql = "
    SELECT b.*,
           c.title, c.price,
           CONCAT(u.first_name, ' ', u.last_name) AS member_name,
           cs.date, cs.time, cs.room
    FROM bookings b
    JOIN users u           ON b.user_id      = u.id
    JOIN class_schedule cs ON b.schedule_id  = cs.id
    JOIN classes c         ON cs.class_id    = c.id"
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
    . " ORDER BY b.booked_at DESC
       LIMIT 100"; // cap at 100 for page performance

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

// ── Quick summary counts for the filter tab badges ────────────────────────────
// These run regardless of the current filter so all tabs show accurate counts
$counts = [];
foreach (['confirmed','cancelled','completed'] as $s) {
    $counts[$s] = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='$s'")->fetchColumn();
}
$counts['all'] = array_sum($counts);

require_once __DIR__ . '/admin-header.php';
?>

<!-- ── Filter tab buttons ── -->
<!-- Each tab links to the same page with a different ?status= parameter.
     The active tab gets btn-primary styling, others get btn-secondary. -->
<div class="filter-tabs">
    <a href="bookings.php"
       class="btn btn-sm <?= !$filter_status ? 'btn-primary' : 'btn-secondary' ?>">
        All
        <span class="tab-count"><?= $counts['all'] ?></span>
    </a>
    <a href="bookings.php?status=confirmed"
       class="btn btn-sm <?= $filter_status === 'confirmed'  ? 'btn-primary' : 'btn-secondary' ?>">
        Confirmed
        <span class="tab-count"><?= $counts['confirmed'] ?></span>
    </a>
    <a href="bookings.php?status=cancelled"
       class="btn btn-sm <?= $filter_status === 'cancelled'  ? 'btn-primary' : 'btn-secondary' ?>">
        Cancelled
        <span class="tab-count"><?= $counts['cancelled'] ?></span>
    </a>
    <a href="bookings.php?status=completed"
       class="btn btn-sm <?= $filter_status === 'completed'  ? 'btn-primary' : 'btn-secondary' ?>">
        Completed
        <span class="tab-count"><?= $counts['completed'] ?></span>
    </a>
</div>

<!-- ── Bookings table ── -->
<div class="admin-table-card">
    <div class="admin-table-header">
        <h3>
            <?= $filter_status ? ucfirst($filter_status) . ' Bookings' : 'All Bookings' ?>
            <!-- Show how many rows are currently being displayed -->
            <span style="color:var(--color-text-muted);font-size:.85rem;font-weight:400;">
                (showing <?= count($bookings) ?> of <?= $counts[$filter_status ?: 'all'] ?>)
            </span>
        </h3>
        <?php if (count($bookings) === 100): ?>
        <!-- Warning shown when the 100-row limit is hit -->
        <span style="font-size:.8rem;color:var(--color-warning);">
            ⚠ Showing most recent 100 only
        </span>
        <?php endif; ?>
    </div>

    <div style="overflow-x:auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Member</th>
                    <th>Class</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Room</th>
                    <th>Option Chosen</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Booked On</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $b): ?>
                <tr>
                    <td><?= h($b['member_name']) ?></td>
                    <td><strong><?= h($b['title']) ?></strong></td>

                    <!-- date() converts MySQL date string to readable format -->
                    <td><?= date('M j, Y', strtotime($b['date'])) ?></td>

                    <!-- 'g:i A' = 12-hour format with AM/PM, e.g. 7:00 AM -->
                    <td><?= date('g:i A', strtotime($b['time'])) ?></td>

                    <td><?= h($b['room']) ?></td>
                    <td><?= h($b['option_choice']) ?></td>
                    <td>$<?= number_format($b['price'], 2) ?></td>

                    <!-- Status badge: colour depends on which status value it is -->
                    <td>
                        <?php
                        // Map status to badge CSS modifier class
                        $badge = match($b['status']) {
                            'confirmed'  => 'success',
                            'cancelled'  => 'danger',
                            'completed'  => 'muted',
                            default      => 'muted',
                        };
                        ?>
                        <span class="badge badge--<?= $badge ?>">
                            <?= ucfirst($b['status']) ?>
                        </span>
                    </td>

                    <!-- date() formats the booked_at timestamp (shorter format for table) -->
                    <td><?= date('M j, Y', strtotime($b['booked_at'])) ?></td>
                </tr>
                <?php endforeach; ?>

                <?php if (empty($bookings)): ?>
                <!-- Empty state row when no bookings match the filter -->
                <tr>
                    <td colspan="9" style="text-align:center;color:var(--color-text-muted);
                                           padding:var(--space-2xl);">
                        No <?= $filter_status ? $filter_status : '' ?> bookings found.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
/* Filter tab row above the table */
.filter-tabs{display:flex;gap:var(--space-sm);margin-bottom:var(--space-lg);flex-wrap:wrap}

/* Small count badge inside each filter tab button */
.tab-count{
    background:rgba(0,0,0,.2);
    color:inherit;
    font-size:.7rem;
    padding:.1rem .4rem;
    border-radius:var(--radius-full);
    margin-left:.25rem;
}
</style>

<?php require_once __DIR__ . '/admin-footer.php'; ?>
