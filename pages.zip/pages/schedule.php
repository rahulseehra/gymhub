<?php
/**
 * GymHub - Weekly Class Schedule
 * pages/schedule.php
 *
 * Shows a 7-day timetable of upcoming class sessions.
 *
 * How it works:
 *   - Loads all sessions for the next 7 days from class_schedule table
 *   - Groups them into a PHP array keyed by date string
 *   - Renders day tabs across the top — clicking a tab shows that day's sessions
 *   - Category filter pills allow narrowing to one class type
 *   - Tab switching and filtering are done with JavaScript (no page reload)
 *
 * Data comes from class_schedule JOIN classes JOIN instructors.
 * Only sessions with spots remaining are shown.
 */

$page_title       = 'Class Schedule | GymHub';
$page_description = 'View the GymHub weekly class schedule. Find upcoming HIIT, yoga, boxing and 20+ class sessions across all locations.';
$page_keywords    = 'gym schedule Windsor, fitness class timetable, GymHub schedule, weekly classes';
$active_nav       = 'schedule';

require_once __DIR__ . '/../config/db.php';

// ── Load sessions for the next 7 days ─────────────────────────────────────────
// CURDATE() gives today's date in MySQL. DATE_ADD adds 6 days (today + 6 = 7 days total).
// We only show sessions with spots_left > 0 so fully booked sessions are hidden.
$stmt = $pdo->query("
    SELECT cs.*, c.title, c.category, c.duration_min, c.price,
           c.id AS class_id, c.image,
           CONCAT(u.first_name, ' ', u.last_name) AS instructor_name
    FROM class_schedule cs
    JOIN classes c         ON cs.class_id   = c.id
    LEFT JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN users u       ON i.user_id = u.id
    WHERE cs.date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
      AND c.status = 'active'
      AND cs.spots_left > 0
    ORDER BY cs.date ASC, cs.time ASC
");
$all_sessions = $stmt->fetchAll();

// ── Group sessions by date ────────────────────────────────────────────────────
// Convert the flat array into a nested array keyed by date string.
// e.g. $by_date['2025-04-06'] = [session1, session2, ...]
// This makes it easy to loop through one day at a time in the template.
$by_date = [];
foreach ($all_sessions as $session) {
    $by_date[$session['date']][] = $session;
}

// ── Build the 7-day tab array ─────────────────────────────────────────────────
// We always show all 7 days even if some have no sessions (shows "no classes" message).
$days = [];
for ($i = 0; $i < 7; $i++) {
    // strtotime("+$i days") gives the Unix timestamp for today+i days
    $days[] = date('Y-m-d', strtotime("+$i days"));
}

// ── Get unique categories for the filter pill buttons ─────────────────────────
// PDO::FETCH_COLUMN returns a flat array of just the first column values
$categories = $pdo->query("
    SELECT DISTINCT c.category FROM classes c
    JOIN class_schedule cs ON cs.class_id = c.id
    WHERE cs.date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
    ORDER BY c.category
")->fetchAll(PDO::FETCH_COLUMN);

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">This Week</span>
        <h1>Class Schedule</h1>
        <p>Browse this week's sessions and book your spot instantly.</p>
    </div>
</section>

<section class="schedule-page section-pad">
    <div class="container">

        <!-- ── Category filter pills ── -->
        <!-- Each pill adds/removes a 'hidden' class on matching cards via JavaScript -->
        <div class="schedule-filters">
            <!-- "All" shows every session — default state -->
            <button class="pill pill--active" onclick="filterCategory('all', this)">All</button>
            <?php foreach ($categories as $cat): ?>
            <button class="pill" onclick="filterCategory('<?= h(strtolower($cat)) ?>', this)">
                <?= h($cat) ?>
            </button>
            <?php endforeach; ?>
        </div>

        <!-- ── Day tab buttons ── -->
        <!-- Clicking a tab calls showDay() in JavaScript to toggle visibility -->
        <div class="day-tabs">
            <?php foreach ($days as $i => $day): ?>
            <button class="day-tab <?= $i === 0 ? 'day-tab--active' : '' ?>"
                    onclick="showDay('<?= $day ?>', this)"
                    data-day="<?= $day ?>">
                <!-- Date formatting: Mon, Apr 6 -->
                <span class="day-name"><?= date('D', strtotime($day)) ?></span>
                <span class="day-num"><?= date('M j', strtotime($day)) ?></span>
                <!-- Show session count badge on each tab -->
                <?php $count = count($by_date[$day] ?? []); ?>
                <?php if ($count): ?>
                <span class="day-count"><?= $count ?></span>
                <?php endif; ?>
            </button>
            <?php endforeach; ?>
        </div>

        <!-- ── Day content panels ── -->
        <!-- One panel per day — JavaScript shows/hides based on active tab -->
        <?php foreach ($days as $i => $day): ?>
        <div class="day-panel <?= $i === 0 ? 'day-panel--active' : '' ?>"
             id="day-<?= $day ?>">

            <!-- Section heading: full date e.g. "Monday, April 6" -->
            <h2 class="day-heading">
                <?= date('l, F j', strtotime($day)) ?>
                <?= $day === date('Y-m-d') ? '<span class="today-badge">Today</span>' : '' ?>
            </h2>

            <?php if (empty($by_date[$day])): ?>
            <!-- Empty state for days with no available sessions -->
            <div class="no-sessions">
                <p>No classes scheduled on this day. <a href="classes.php">Browse all classes →</a></p>
            </div>

            <?php else: ?>
            <!-- Session cards grid for this day -->
            <div class="sessions-grid">
                <?php foreach ($by_date[$day] as $s): ?>
                <!-- data-category used by JavaScript filter function -->
                <div class="session-card"
                     data-category="<?= h(strtolower($s['category'])) ?>">

                    <!-- Time badge — prominent display of start time -->
                    <div class="session-time">
                        <!-- 'g:i A' = 7:00 AM -->
                        <?= date('g:i A', strtotime($s['time'])) ?>
                    </div>

                    <div class="session-body">
                        <div class="session-header">
                            <span class="class-category-badge"><?= h($s['category']) ?></span>
                            <span class="session-spots
                                <?= $s['spots_left'] <= 3 ? 'session-spots--low' : '' ?>">
                                <?= $s['spots_left'] ?> spots
                            </span>
                        </div>

                        <h3 class="session-title"><?= h($s['title']) ?></h3>

                        <!-- Session metadata: duration, room, instructor -->
                        <div class="session-meta">
                            <span>⏱ <?= $s['duration_min'] ?> min</span>
                            <span>📍 <?= h($s['room']) ?></span>
                            <?php if ($s['instructor_name']): ?>
                            <span>👤 <?= h($s['instructor_name']) ?></span>
                            <?php endif; ?>
                        </div>

                        <!-- Price and book button side by side -->
                        <div class="session-footer">
                            <span class="session-price">$<?= number_format($s['price'], 2) ?></span>
                            <a href="class-detail.php?id=<?= $s['class_id'] ?>"
                               class="btn btn-primary btn-sm">Book Now</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

        </div><!-- end day-panel -->
        <?php endforeach; ?>

    </div>
</section>

<!-- ── JavaScript for tab switching and category filtering ── -->
<script>
/**
 * showDay(date, btn) — Switches the visible day panel
 * Hides all .day-panel elements, shows the one matching the given date.
 * Updates active state on all .day-tab buttons.
 *
 * @param {string} date - 'YYYY-MM-DD' string matching the panel's id
 * @param {HTMLElement} btn - The clicked tab button
 */
function showDay(date, btn) {
    // Hide all day panels
    document.querySelectorAll('.day-panel').forEach(p => p.classList.remove('day-panel--active'));
    // Remove active class from all tabs
    document.querySelectorAll('.day-tab').forEach(t => t.classList.remove('day-tab--active'));
    // Show the selected day's panel
    document.getElementById('day-' + date).classList.add('day-panel--active');
    // Mark this tab as active
    btn.classList.add('day-tab--active');
}

/**
 * filterCategory(cat, btn) — Shows only session cards matching a category
 * Adds/removes 'session-card--hidden' class on each card based on its data-category.
 * 'all' shows every card.
 *
 * @param {string} cat - Lowercase category name, or 'all'
 * @param {HTMLElement} btn - The clicked pill button
 */
function filterCategory(cat, btn) {
    // Update active state on all pill buttons
    document.querySelectorAll('.pill').forEach(p => p.classList.remove('pill--active'));
    btn.classList.add('pill--active');

    // Show or hide each session card based on its category
    document.querySelectorAll('.session-card').forEach(card => {
        if (cat === 'all' || card.dataset.category === cat) {
            card.classList.remove('session-card--hidden'); // show
        } else {
            card.classList.add('session-card--hidden');    // hide
        }
    });
}
</script>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}

/* Category filter pills */
.schedule-filters{display:flex;gap:var(--space-sm);flex-wrap:wrap;margin-bottom:var(--space-lg)}
.pill{font-family:var(--font-display);font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;padding:.3rem .9rem;border-radius:var(--radius-full);border:1px solid var(--color-border);color:var(--color-text-muted);background:var(--color-surface-2);cursor:pointer;transition:all var(--transition-fast)}
.pill:hover,.pill--active{background:var(--color-accent);border-color:var(--color-accent);color:#000}

/* Day tab buttons */
.day-tabs{display:flex;gap:.25rem;margin-bottom:var(--space-xl);overflow-x:auto;padding-bottom:.25rem}
.day-tab{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:.6rem 1rem;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:.15rem;min-width:80px;transition:all var(--transition-fast);position:relative;flex-shrink:0}
.day-tab:hover{border-color:var(--color-accent)}
.day-tab--active{background:var(--color-accent);border-color:var(--color-accent);color:#000}
.day-name{font-family:var(--font-display);font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em}
.day-num{font-size:.75rem;color:inherit;opacity:.8}
.day-count{position:absolute;top:-.4rem;right:-.4rem;background:#000;color:var(--color-accent);font-size:.65rem;font-weight:700;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.day-tab--active .day-count{background:rgba(0,0,0,.3);color:#000}

/* Day panels — only active one visible */
.day-panel{display:none}
.day-panel--active{display:block}

/* Day heading */
.day-heading{font-size:1.3rem;margin-bottom:var(--space-xl);display:flex;align-items:center;gap:var(--space-sm)}
.today-badge{background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:.15rem .55rem;border-radius:var(--radius-full)}

.no-sessions{color:var(--color-text-muted);font-size:.95rem;padding:var(--space-xl) 0}

/* Session cards grid */
.sessions-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:var(--space-md)}
.session-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;display:flex;flex-direction:column;transition:all var(--transition-normal)}
.session-card:hover{border-color:var(--color-accent);transform:translateY(-3px)}
.session-card--hidden{display:none} /* hidden by JS category filter */

/* Time banner at top of each card */
.session-time{background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:1.1rem;font-weight:900;text-align:center;padding:.5rem;letter-spacing:.03em}

/* Card body */
.session-body{padding:var(--space-md);display:flex;flex-direction:column;gap:var(--space-sm);flex:1}
.session-header{display:flex;justify-content:space-between;align-items:center;gap:var(--space-sm)}
.session-spots{font-family:var(--font-display);font-size:.72rem;font-weight:700;color:var(--color-success)}
.session-spots--low{color:var(--color-danger)} /* red when 3 or fewer spots */
.session-title{font-size:1rem;font-weight:700}
.session-meta{display:flex;flex-wrap:wrap;gap:var(--space-sm);font-size:.8rem;color:var(--color-text-muted)}
.session-footer{display:flex;justify-content:space-between;align-items:center;margin-top:auto;padding-top:var(--space-sm)}
.session-price{font-family:var(--font-display);font-weight:700;color:var(--color-accent);font-size:1rem}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
