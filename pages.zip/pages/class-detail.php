<?php
/**
 * GymHub - Class Detail & Booking
 * pages/class-detail.php
 *
 * Shows the full details of one fitness class and handles the booking form.
 * The class ID is passed via URL: class-detail.php?id=5
 *
 * What this page shows:
 *   - Class image, title, category badge, price, duration, rating
 *   - Full description text
 *   - Options comparison panel (side-by-side option_a vs option_b)
 *   - Instructor bio and rating
 *   - Member reviews (up to 5 most recent, 4+ stars)
 *   - Sticky booking sidebar: option radio buttons + session dropdown + confirm button
 *
 * Booking flow:
 *   1. User picks an option (radio button — option_a or option_b)
 *   2. User picks a session date/time (dropdown from class_schedule table)
 *   3. On POST: validate inputs, check spots available, check no duplicate booking
 *   4. If valid: INSERT into bookings, decrement spots_left by 1
 *   5. Show success message with link to My Bookings page
 *
 * Security:
 *   - class ID cast to (int) to prevent SQL injection
 *   - All output escaped with h() to prevent XSS
 *   - Booking requires is_logged_in() — guests redirected to login
 */

require_once __DIR__ . '/../config/db.php';

// Get the class ID from URL — cast to int prevents SQL injection
$class_id = (int)($_GET['id'] ?? 0);

// If no valid ID, redirect to classes catalog
if (!$class_id) redirect(SITE_URL . '/pages/classes.php');

// ── Load class data with instructor info ─────────────────────────────────────
// JOIN instructors and users to get the instructor's name, bio, rating, photo
$stmt = $pdo->prepare("
    SELECT c.*,
           i.bio, i.rating AS instructor_rating,
           i.specialties, i.photo AS instructor_photo,
           CONCAT(u.first_name, ' ', u.last_name) AS instructor_name
    FROM classes c
    LEFT JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN users u       ON i.user_id = u.id
    WHERE c.id = ? AND c.status = 'active'
");
$stmt->execute([$class_id]);
$class = $stmt->fetch();

// If class not found or inactive, go back to catalog
if (!$class) redirect(SITE_URL . '/pages/classes.php');

// ── SEO meta tags use real class data ────────────────────────────────────────
$page_title       = h($class['title']) . ' | GymHub';
$page_description = substr($class['description'], 0, 160); // Google shows max 160 chars
$active_nav       = 'classes';

// Context-sensitive help bar links to the booking guide wiki page
$help_link = 'booking-guide.php';
$help_text = 'How does booking work? Read the Booking Guide';

// ── Load upcoming available sessions for this class ──────────────────────────
// Only shows sessions from today onwards with spots remaining (> 0)
// Ordered by date and time ascending so nearest session appears first
$stmt = $pdo->prepare("
    SELECT * FROM class_schedule
    WHERE class_id = ?
      AND date >= CURDATE()
      AND spots_left > 0
    ORDER BY date ASC, time ASC
    LIMIT 10
");
$stmt->execute([$class_id]);
$schedules = $stmt->fetchAll();

// ── Load member ratings for this class ───────────────────────────────────────
// Shows the 5 most recent reviews with the reviewer's name
$stmt = $pdo->prepare("
    SELECT r.*, CONCAT(u.first_name, ' ', u.last_name) AS member_name
    FROM ratings r
    JOIN users u ON r.user_id = u.id
    WHERE r.class_id = ?
    ORDER BY r.created_at DESC
    LIMIT 5
");
$stmt->execute([$class_id]);
$ratings = $stmt->fetchAll();

// Calculate the average star rating and total review count
$avg_stmt = $pdo->prepare("SELECT AVG(stars) AS avg, COUNT(*) AS total FROM ratings WHERE class_id = ?");
$avg_stmt->execute([$class_id]);
$rating_data = $avg_stmt->fetch();

// ── Handle booking form submission ────────────────────────────────────────────
$booking_success = '';
$booking_error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book'])) {

    // Guests must log in first — redirect with return URL so they come back after login
    if (!is_logged_in()) {
        redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/class-detail.php?id=' . $class_id));
    }

    // Cast to int and trim to prevent injection
    $schedule_id   = (int)(trim($_POST['schedule_id']   ?? ''));
    $option_choice = trim($_POST['option_choice'] ?? '');

    // Validate: both fields are required
    if (!$schedule_id)       $booking_error = 'Please select a session date and time.';
    elseif (!$option_choice) $booking_error = 'Please select a class option.';
    else {
        // Re-verify the session still has spots — someone may have booked since page loaded
        $s = $pdo->prepare("SELECT * FROM class_schedule WHERE id = ? AND spots_left > 0");
        $s->execute([$schedule_id]);
        $schedule = $s->fetch();

        if (!$schedule) {
            $booking_error = 'Sorry — that session is now full or no longer available.';
        } else {
            // Check the user hasn't already booked this exact session
            // status != 'cancelled' so they can rebook after cancelling
            $dup = $pdo->prepare("
                SELECT id FROM bookings
                WHERE user_id = ? AND schedule_id = ? AND status != 'cancelled'
            ");
            $dup->execute([$_SESSION['user_id'], $schedule_id]);

            if ($dup->fetch()) {
                $booking_error = 'You have already booked this session.';
            } else {
                // All checks passed — create the booking record
                $pdo->prepare("
                    INSERT INTO bookings (user_id, schedule_id, option_choice, status)
                    VALUES (?, ?, ?, 'confirmed')
                ")->execute([$_SESSION['user_id'], $schedule_id, $option_choice]);

                // Decrement available spots so the session fills up correctly
                $pdo->prepare("
                    UPDATE class_schedule SET spots_left = spots_left - 1 WHERE id = ?
                ")->execute([$schedule_id]);

                $booking_success = 'Booking confirmed! 🎉 View it in <a href="bookings.php">My Bookings</a>.';
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Breadcrumb navigation bar -->
<nav class="breadcrumb-bar" aria-label="Breadcrumb">
    <div class="container">
        <a href="<?= SITE_URL ?>/index.php">Home</a> /
        <a href="classes.php">Classes</a> /
        <span><?= h($class['title']) ?></span>
    </div>
</nav>

<section class="class-detail-page section-pad">
    <div class="container">

        <!-- Two-column layout: class info left (wider), booking panel right (sticky) -->
        <div class="class-detail-grid">

            <!-- ── Left: class information ── -->
            <div class="class-detail-main">

                <!-- Header: category badge, title, metadata row -->
                <div class="class-detail-header">
                    <span class="class-category-badge"><?= h($class['category']) ?></span>
                    <h1><?= h($class['title']) ?></h1>
                    <div class="class-detail-meta">
                        <span title="Duration">⏱ <?= h($class['duration_min']) ?> min</span>
                        <span title="Max capacity">👥 Up to <?= h($class['capacity']) ?> people</span>
                        <?php if ($rating_data['total'] > 0): ?>
                        <!-- Only show if at least one review exists -->
                        <span>⭐ <?= number_format($rating_data['avg'], 1) ?>
                              (<?= $rating_data['total'] ?> review<?= $rating_data['total'] != 1 ? 's' : '' ?>)
                        </span>
                        <?php endif; ?>
                        <span class="class-price-large">$<?= number_format($class['price'], 2) ?>/session</span>
                    </div>
                </div>

                <!-- Full-width class image -->
                <div class="class-detail-image">
                    <img src="<?= SITE_URL ?>/public/assets/images/classes/<?= h($class['image']) ?>"
                         alt="<?= h($class['title']) ?> fitness class at GymHub"
                         onerror="this.src='<?= SITE_URL ?>/public/assets/images/classes/default-class.jpg'">
                </div>

                <!-- Full class description -->
                <div class="detail-section">
                    <h2>About This Class</h2>
                    <p><?= h($class['description']) ?></p>
                </div>

                <!-- Options comparison: shows both choices side by side -->
                <div class="detail-section">
                    <h2>Class Options: <?= h($class['option_label']) ?></h2>
                    <p>Choose your preferred format when booking:</p>
                    <div class="options-comparison">
                        <div class="option-box">
                            <strong><?= h($class['option_a']) ?></strong>
                            <p>Option A</p>
                        </div>
                        <div class="option-divider">or</div>
                        <div class="option-box">
                            <strong><?= h($class['option_b']) ?></strong>
                            <p>Option B</p>
                        </div>
                    </div>
                </div>

                <!-- Instructor section — only shown if an instructor is assigned -->
                <?php if ($class['instructor_name']): ?>
                <div class="detail-section">
                    <h2>Your Instructor</h2>
                    <div class="instructor-spotlight">
                        <div class="instructor-spotlight-photo">
                            <img src="<?= SITE_URL ?>/public/assets/images/instructors/<?= h($class['instructor_photo'] ?? 'default-instructor.png') ?>"
                                 alt="<?= h($class['instructor_name']) ?>"
                                 onerror="this.src='<?= SITE_URL ?>/public/assets/images/instructors/default-instructor.png'">
                        </div>
                        <div class="instructor-spotlight-info">
                            <h3><?= h($class['instructor_name']) ?></h3>
                            <p class="instructor-specialties"><?= h($class['specialties'] ?? '') ?></p>
                            <?php if ($class['instructor_rating']): ?>
                            <p style="font-size:.9rem;color:var(--color-text-muted);">
                                ⭐ <?= number_format($class['instructor_rating'], 2) ?> / 5.00
                            </p>
                            <?php endif; ?>
                            <p style="color:var(--color-text-light);line-height:1.7;font-size:.9rem;">
                                <?= h($class['bio'] ?? '') ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Member reviews — only shown if there are any -->
                <?php if (!empty($ratings)): ?>
                <div class="detail-section">
                    <h2>Member Reviews</h2>
                    <div class="ratings-list">
                        <?php foreach ($ratings as $r): ?>
                        <div class="rating-item">
                            <div class="rating-header">
                                <!-- Avatar circle: first letter of reviewer's name -->
                                <div class="rating-avatar">
                                    <?= strtoupper(substr($r['member_name'], 0, 1)) ?>
                                </div>
                                <div>
                                    <strong><?= h($r['member_name']) ?></strong>
                                    <!-- str_repeat outputs ⭐ N times based on star count -->
                                    <div><?= str_repeat('⭐', (int)$r['stars']) ?></div>
                                </div>
                                <span class="rating-date">
                                    <?= date('M j, Y', strtotime($r['created_at'])) ?>
                                </span>
                            </div>
                            <?php if ($r['comment']): ?>
                            <p class="rating-comment">"<?= h($r['comment']) ?>"</p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="rate-class.php?id=<?= $class_id ?>" class="btn btn-secondary btn-sm">
                        ✍️ Write a Review
                    </a>
                </div>
                <?php endif; ?>

            </div><!-- end class-detail-main -->

            <!-- ── Right: sticky booking panel ── -->
            <aside class="booking-panel">
                <div class="booking-card">
                    <h3>Book This Class</h3>

                    <!-- Price shown prominently -->
                    <div class="booking-price">
                        $<?= number_format($class['price'], 2) ?>
                        <span>per session</span>
                    </div>

                    <!-- Booking feedback messages -->
                    <?php if ($booking_success): ?>
                    <div class="alert alert-success"><?= $booking_success ?></div>
                    <?php endif; ?>
                    <?php if ($booking_error): ?>
                    <div class="alert alert-danger"><?= h($booking_error) ?></div>
                    <?php endif; ?>

                    <?php if (!is_logged_in()): ?>
                    <!-- Guest: show login prompt -->
                    <p style="color:var(--color-text-muted);font-size:.9rem;margin-bottom:var(--space-md);">
                        You must be logged in to book a class.
                    </p>
                    <a href="login.php?redirect=<?= urlencode(SITE_URL . '/pages/class-detail.php?id=' . $class_id) ?>"
                       class="btn btn-primary btn-full">Log In to Book</a>
                    <a href="register.php" class="btn btn-secondary btn-full"
                       style="margin-top:var(--space-sm);">Create Free Account</a>

                    <?php elseif (empty($schedules)): ?>
                    <!-- No upcoming sessions available -->
                    <p style="color:var(--color-text-muted);font-size:.9rem;line-height:1.6;">
                        No upcoming sessions available right now.<br>
                        <a href="ask-trainer.php">Ask a trainer</a> about upcoming dates.
                    </p>

                    <?php else: ?>
                    <!-- Booking form — logged in + sessions available -->
                    <form method="POST" action="" class="booking-form">

                        <!-- Option radio buttons — user picks option_a or option_b -->
                        <div class="form-group">
                            <label><?= h($class['option_label']) ?></label>
                            <div class="option-radio-group">
                                <label class="option-radio">
                                    <input type="radio" name="option_choice"
                                           value="<?= h($class['option_a']) ?>" required>
                                    <span><?= h($class['option_a']) ?></span>
                                </label>
                                <label class="option-radio">
                                    <input type="radio" name="option_choice"
                                           value="<?= h($class['option_b']) ?>">
                                    <span><?= h($class['option_b']) ?></span>
                                </label>
                            </div>
                        </div>

                        <!-- Session dropdown: shows date, time, room, spots remaining -->
                        <div class="form-group">
                            <label for="schedule_id">Choose a Session</label>
                            <select name="schedule_id" id="schedule_id" required
                                    style="background:var(--color-surface-2);border:1px solid var(--color-border);
                                           color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);
                                           font-family:var(--font-body);font-size:.9rem;outline:none;width:100%;">
                                <option value="">-- Select date &amp; time --</option>
                                <?php foreach ($schedules as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <!-- Format: Mon, Apr 7 at 7:00 AM — Weight Room (12 spots) -->
                                    <?= date('D, M j', strtotime($s['date'])) ?>
                                    at <?= date('g:i A', strtotime($s['time'])) ?>
                                    — <?= h($s['room']) ?>
                                    (<?= $s['spots_left'] ?> spot<?= $s['spots_left'] != 1 ? 's' : '' ?>)
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Submit button shows the price as a reminder -->
                        <button type="submit" name="book" class="btn btn-primary btn-full">
                            Confirm Booking — $<?= number_format($class['price'], 2) ?>
                        </button>

                        <!-- Cancellation policy reminder -->
                        <p style="font-size:.78rem;color:var(--color-text-muted);text-align:center;margin-top:var(--space-sm);">
                            ✓ Free cancellation up to 24 hours before class
                        </p>
                    </form>
                    <?php endif; ?>
                </div>

                <!-- Helper links below the booking card -->
                <div class="booking-extras">
                    <a href="<?= SITE_URL ?>/wiki/booking-guide.php" class="extras-link">
                        📖 How does booking work?
                    </a>
                    <a href="ask-trainer.php" class="extras-link">
                        💬 Ask a trainer about this class
                    </a>
                    <a href="classes.php?category=<?= urlencode(strtolower($class['category'])) ?>"
                       class="extras-link">
                        🔍 More <?= h($class['category']) ?> classes
                    </a>
                </div>
            </aside>

        </div>
    </div>
</section>

<style>
/* Breadcrumb bar */
.breadcrumb-bar{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:.6rem 0;font-size:.85rem;color:var(--color-text-muted)}
.breadcrumb-bar a{color:var(--color-text-muted)}
.breadcrumb-bar a:hover{color:var(--color-accent)}
.breadcrumb-bar span{color:var(--color-text)}

/* Two-column layout: content wider, sidebar fixed width */
.class-detail-grid{display:grid;grid-template-columns:1fr 340px;gap:var(--space-2xl);align-items:start}

/* Class header */
.class-detail-header{margin-bottom:var(--space-lg)}
.class-detail-header h1{margin:var(--space-sm) 0}
.class-detail-meta{display:flex;flex-wrap:wrap;gap:var(--space-md);color:var(--color-text-muted);font-size:.9rem;align-items:center}
.class-price-large{font-family:var(--font-display);font-weight:700;font-size:1.1rem;color:var(--color-accent)!important}

/* Class image */
.class-detail-image{border-radius:var(--radius-lg);overflow:hidden;margin-bottom:var(--space-xl);max-height:380px}
.class-detail-image img{width:100%;height:100%;object-fit:cover}

/* Content sections */
.detail-section{margin-bottom:var(--space-xl)}
.detail-section h2{font-size:1.25rem;margin-bottom:var(--space-md)}
.detail-section p{color:var(--color-text-light);line-height:1.7}

/* Options comparison panel */
.options-comparison{display:flex;align-items:center;gap:var(--space-md);margin-top:var(--space-md)}
.option-box{flex:1;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg);text-align:center}
.option-box strong{font-family:var(--font-display);font-size:1.2rem;color:var(--color-accent);display:block;margin-bottom:.3rem}
.option-box p{color:var(--color-text-muted);font-size:.85rem;margin:0}
.option-divider{color:var(--color-text-muted);flex-shrink:0;font-style:italic}

/* Instructor spotlight */
.instructor-spotlight{display:flex;gap:var(--space-lg);align-items:flex-start}
.instructor-spotlight-photo{width:90px;height:90px;border-radius:50%;overflow:hidden;flex-shrink:0}
.instructor-spotlight-photo img{width:100%;height:100%;object-fit:cover}
.instructor-spotlight-info{display:flex;flex-direction:column;gap:.4rem}
.instructor-spotlight-info h3{font-size:1.05rem}
.instructor-specialties{color:var(--color-accent);font-size:.8rem;text-transform:uppercase;letter-spacing:.05em;font-family:var(--font-display);font-weight:600}

/* Ratings list */
.ratings-list{display:flex;flex-direction:column;gap:var(--space-md);margin-bottom:var(--space-md)}
.rating-item{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-md)}
.rating-header{display:flex;align-items:center;gap:var(--space-sm);margin-bottom:var(--space-sm)}
.rating-avatar{width:34px;height:34px;border-radius:50%;background:var(--color-accent);color:#000;font-family:var(--font-display);font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.rating-header strong{color:var(--color-text);font-size:.9rem;display:block}
.rating-date{margin-left:auto;color:var(--color-text-muted);font-size:.78rem}
.rating-comment{color:var(--color-text-muted);font-size:.9rem;font-style:italic;margin:0}

/* Sticky booking card */
.booking-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl);position:sticky;top:90px}
.booking-card h3{margin-bottom:var(--space-sm)}
.booking-price{font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--color-accent);margin-bottom:var(--space-lg)}
.booking-price span{font-size:.85rem;font-weight:400;color:var(--color-text-muted)}
.booking-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}

/* Radio button option selector */
.option-radio-group{display:flex;gap:var(--space-sm)}
.option-radio{flex:1;display:flex;align-items:center;justify-content:center;gap:.4rem;padding:.6rem;cursor:pointer;background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-sm);transition:all var(--transition-fast);font-size:.9rem}
.option-radio input{accent-color:var(--color-accent)}
/* Highlight selected option with orange border */
.option-radio:has(input:checked){border-color:var(--color-accent);background:var(--color-accent-glow)}

.btn-full{width:100%;justify-content:center}

/* Links below booking card */
.booking-extras{margin-top:var(--space-md);display:flex;flex-direction:column;gap:.5rem}
.extras-link{color:var(--color-text-muted);font-size:.875rem;padding:.4rem 0;display:block;transition:color var(--transition-fast)}
.extras-link:hover{color:var(--color-accent)}

.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-md)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}

@media(max-width:900px){
    .class-detail-grid{grid-template-columns:1fr}
    .booking-card{position:static}
    .options-comparison{flex-direction:column}
    .instructor-spotlight{flex-direction:column}
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
