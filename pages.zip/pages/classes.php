<?php
/**
 * GymHub - Classes Catalog
 * pages/classes.php
 *
 * Shows all 20 fitness classes in a filterable, searchable grid.
 * All filtering is done server-side — PHP builds the SQL query
 * dynamically based on what the user has selected, then MySQL
 * returns only the matching rows.
 *
 * URL parameters accepted:
 *   ?search=yoga      — searches title, description, and category
 *   ?category=cardio  — filters to one category
 *   ?sort=price_asc   — changes the ORDER BY clause
 *   ?option=beginner  — filters by option_a or option_b value
 *
 * Dynamic HTML Form: The search bar and sort dropdown are the
 * interactive form elements on this page.
 */

$page_title       = 'Fitness Classes | GymHub';
$page_description = 'Browse all GymHub fitness classes — HIIT, yoga, boxing, CrossFit and more. Filter by category, level, and price. Book online instantly.';
$page_keywords    = 'fitness classes Windsor, HIIT classes, yoga Windsor, CrossFit, boxing classes, gym classes near me';
$active_nav       = 'classes';

// Context-sensitive help link — shown as a bar at the top of the page
// pointing users to the Getting Started wiki page
$help_link = 'getting-started.php';
$help_text = 'New to GymHub? Read the Getting Started guide';

require_once __DIR__ . '/../config/db.php';

// ── Read and sanitize URL filter inputs ───────────────────────────────────────
// trim() removes accidental whitespace, ?? '' gives a default empty string
$search   = trim($_GET['search']   ?? '');
$category = trim($_GET['category'] ?? '');
$sort     = trim($_GET['sort']     ?? 'title');
$option   = trim($_GET['option']   ?? '');

// Whitelist allowed sort values to prevent SQL injection via the sort parameter.
// Any value not in this list gets reset to 'title'.
$allowed_sorts = ['title', 'price_asc', 'price_desc', 'duration', 'rating'];
if (!in_array($sort, $allowed_sorts)) $sort = 'title';

// ── Build the SQL query dynamically ──────────────────────────────────────────
// We always filter for active classes only.
// Additional WHERE clauses are added based on which filters are active.
$where  = ["c.status = 'active'"];
$params = []; // values for prepared statement placeholders

// Search filter — checks three columns using LIKE for partial matching
if ($search !== '') {
    $where[]  = "(c.title LIKE ? OR c.description LIKE ? OR c.category LIKE ?)";
    $params[] = "%$search%"; // % means "any characters before"
    $params[] = "%$search%";
    $params[] = "%$search%"; // % means "any characters after"
}

// Category filter — exact match (case-insensitive using LOWER())
if ($category !== '') {
    $where[]  = "LOWER(c.category) = LOWER(?)";
    $params[] = $category;
}

// Option filter — matches either option_a or option_b column
if ($option !== '') {
    $where[]  = "(LOWER(c.option_a) = LOWER(?) OR LOWER(c.option_b) = LOWER(?))";
    $params[] = $option;
    $params[] = $option; // needed twice because we check two columns
}

// Map the sort parameter to an actual SQL ORDER BY clause
// match() is a PHP 8.0+ switch-like expression
$order = match($sort) {
    'price_asc'  => 'c.price ASC',
    'price_desc' => 'c.price DESC',
    'duration'   => 'c.duration_min ASC',
    'rating'     => 'i.rating DESC',      // sort by instructor rating
    default      => 'c.title ASC',        // alphabetical by default
};

// Assemble the full SQL — implode joins WHERE conditions with AND
$sql = "
    SELECT c.*,
           i.rating,
           CONCAT(u.first_name, ' ', u.last_name) AS instructor_name
    FROM   classes c
    LEFT JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN users u       ON i.user_id = u.id
    WHERE  " . implode(' AND ', $where) . "
    ORDER BY $order
";

// Execute with a prepared statement — all $params are bound safely
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$classes = $stmt->fetchAll();

// ── Get distinct category names for the filter pill buttons ──────────────────
// PDO::FETCH_COLUMN returns a flat array of just the first column values
$cats = $pdo->query("
    SELECT DISTINCT category FROM classes
    WHERE status='active'
    ORDER BY category
")->fetchAll(PDO::FETCH_COLUMN);

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Page hero banner -->
<section class="page-hero">
    <div class="container">
        <span class="section-tag">Our Classes</span>
        <h1>Find Your Perfect Class</h1>
        <p>Browse <?= count($classes) ?> world-class fitness sessions — from high-intensity cardio to mindful recovery.</p>
    </div>
</section>

<!-- ── Sticky filter bar ──────────────────────────────────────────────────────
     Stays at the top of the screen as the user scrolls through classes.
     The form uses GET (not POST) so filters are visible in the URL,
     which means users can bookmark or share filtered views.
     ──────────────────────────────────────────────────────────────────────── -->
<section class="filters-bar">
    <div class="container">
        <form method="GET" action="" class="filters-form" id="filters-form">

            <!-- Search input + submit button -->
            <div class="filter-search">
                <input type="text" name="search" placeholder="Search classes..."
                       value="<?= h($search) ?>" class="filter-input"
                       aria-label="Search classes">
                <button type="submit" class="btn btn-primary btn-sm">Search</button>
            </div>

            <!-- Sort dropdown — onchange auto-submits the form via JavaScript -->
            <div class="filter-group">
                <label for="sort" class="filter-label">Sort by</label>
                <select name="sort" id="sort" class="filter-select"
                        onchange="this.form.submit()">
                    <option value="title"      <?= $sort === 'title'      ? 'selected' : '' ?>>Name A–Z</option>
                    <option value="price_asc"  <?= $sort === 'price_asc'  ? 'selected' : '' ?>>Price: Low–High</option>
                    <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High–Low</option>
                    <option value="duration"   <?= $sort === 'duration'   ? 'selected' : '' ?>>Duration</option>
                    <option value="rating"     <?= $sort === 'rating'     ? 'selected' : '' ?>>Top Rated</option>
                </select>
            </div>

            <!-- Clear all filters link — only shown when at least one filter is active -->
            <?php if ($search || $category || $sort !== 'title' || $option): ?>
            <a href="classes.php" class="btn btn-secondary btn-sm">✕ Clear Filters</a>
            <?php endif; ?>
        </form>

        <!-- Category pill buttons — each links to the same page with a category filter -->
        <div class="category-pills">
            <!-- "All" pill — removes category filter -->
            <a href="classes.php?sort=<?= h($sort) ?>"
               class="pill <?= $category === '' ? 'pill--active' : '' ?>">All</a>
            <?php foreach ($cats as $cat): ?>
            <!-- Each category pill passes its slug in the URL -->
            <a href="classes.php?category=<?= urlencode(strtolower($cat)) ?>&sort=<?= h($sort) ?>"
               class="pill <?= strtolower($category) === strtolower($cat) ? 'pill--active' : '' ?>">
                <?= h($cat) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Results count line — tells user how many classes matched their filters -->
<div class="container results-count">
    <p>
        Showing <strong><?= count($classes) ?></strong> class<?= count($classes) !== 1 ? 'es' : '' ?>
        <?= $category ? ' in <strong>' . h(ucfirst($category)) . '</strong>' : '' ?>
        <?= $search   ? ' matching <strong>"' . h($search) . '"</strong>'   : '' ?>
    </p>
</div>

<!-- ── Classes grid ───────────────────────────────────────────────────────────
     Each card is an <article> element (semantically correct for content items).
     The option chips at the bottom are clickable — they filter by that option.
     ──────────────────────────────────────────────────────────────────────── -->
<section class="classes-catalog section-pad">
    <div class="container">
        <?php if (empty($classes)): ?>
        <!-- Empty state — shown when no classes match the current filters -->
        <div class="empty-state">
            <div class="empty-icon">🔍</div>
            <h3>No classes found</h3>
            <p>Try adjusting your search or filters.</p>
            <a href="classes.php" class="btn btn-primary">View All Classes</a>
        </div>
        <?php else: ?>
        <div class="classes-grid classes-grid--catalog">
            <?php foreach ($classes as $class): ?>
            <article class="class-card">
                <div class="class-card-image">
                    <!-- onerror fallback: if the image file is missing, show the default -->
                    <img src="<?= SITE_URL ?>/public/assets/images/classes/<?= h($class['image']) ?>"
                         alt="<?= h($class['title']) ?> fitness class at GymHub"
                         loading="lazy"
                         onerror="this.src='<?= SITE_URL ?>/public/assets/images/classes/default-class.jpg'">
                    <span class="class-category-badge"><?= h($class['category']) ?></span>
                    <span class="class-price-badge">$<?= number_format($class['price'], 2) ?></span>
                </div>
                <div class="class-card-body">
                    <h3 class="class-title"><?= h($class['title']) ?></h3>
                    <!-- substr limits to 110 chars to keep all cards the same height -->
                    <p class="class-description">
                        <?= h(substr($class['description'], 0, 110)) ?>...
                    </p>
                    <div class="class-meta">
                        <span title="Duration">⏱ <?= h($class['duration_min']) ?> min</span>
                        <span title="Max capacity">👥 <?= h($class['capacity']) ?> spots</span>
                        <?php if ($class['rating']): ?>
                        <span title="Average instructor rating">⭐ <?= number_format($class['rating'], 1) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($class['instructor_name']): ?>
                    <p class="class-instructor">👤 <?= h($class['instructor_name']) ?></p>
                    <?php endif; ?>
                    <!-- Option chips — clicking one filters the catalog by that option -->
                    <div class="class-options">
                        <span class="option-label"><?= h($class['option_label']) ?>:</span>
                        <a href="classes.php?option=<?= urlencode($class['option_a']) ?>&sort=<?= h($sort) ?>"
                           class="option-chip <?= strtolower($option) === strtolower($class['option_a']) ? 'option-chip--active' : '' ?>">
                            <?= h($class['option_a']) ?>
                        </a>
                        <a href="classes.php?option=<?= urlencode($class['option_b']) ?>&sort=<?= h($sort) ?>"
                           class="option-chip <?= strtolower($option) === strtolower($class['option_b']) ? 'option-chip--active' : '' ?>">
                            <?= h($class['option_b']) ?>
                        </a>
                    </div>
                    <!-- Link to class detail page — passes the class ID in the URL -->
                    <a href="class-detail.php?id=<?= $class['id'] ?>" class="btn btn-secondary btn-sm">
                        View & Book →
                    </a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<style>
/* ── Page-specific styles ── */

/* Hero banner at top of page */
.page-hero { background: var(--color-surface); border-bottom: 1px solid var(--color-border); padding: var(--space-2xl) 0 var(--space-xl); text-align: center; }
.page-hero p { color: var(--color-text-muted); margin-top: var(--space-sm); }

/* Filter bar sticks below the main nav as user scrolls */
.filters-bar { background: var(--color-surface); border-bottom: 1px solid var(--color-border); padding: var(--space-md) 0; position: sticky; top: 70px; z-index: 100; }

/* Search input + sort dropdown row */
.filters-form { display: flex; align-items: center; gap: var(--space-md); flex-wrap: wrap; margin-bottom: var(--space-md); }
.filter-search { display: flex; gap: var(--space-sm); flex: 1; min-width: 200px; }

/* Shared input styling */
.filter-input, .filter-select { background: var(--color-surface-2); border: 1px solid var(--color-border); color: var(--color-text); padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); font-family: var(--font-body); font-size: 0.9rem; outline: none; transition: border-color var(--transition-fast); }
.filter-input { flex: 1; }
.filter-input:focus, .filter-select:focus { border-color: var(--color-accent); }
.filter-label { font-size: 0.8rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.05em; display: block; margin-bottom: 0.25rem; }

/* Category pills row */
.category-pills { display: flex; gap: var(--space-sm); flex-wrap: wrap; }
.pill { font-family: var(--font-display); font-size: 0.8rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; padding: 0.3rem 0.9rem; border-radius: var(--radius-full); border: 1px solid var(--color-border); color: var(--color-text-muted); background: var(--color-surface-2); transition: all var(--transition-fast); text-decoration: none; }
.pill:hover, .pill--active { background: var(--color-accent); border-color: var(--color-accent); color: #000; }

/* Results count text */
.results-count { padding: var(--space-md) var(--space-lg); color: var(--color-text-muted); font-size: 0.9rem; }
.results-count strong { color: var(--color-accent); }

/* Wider grid on catalog page vs homepage */
.classes-grid--catalog { grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); }

/* Instructor name below class meta */
.class-instructor { font-size: 0.85rem; color: var(--color-text-muted); }

/* Option type label e.g. "Level:" */
.option-label { font-size: 0.75rem; color: var(--color-text-muted); text-transform: uppercase; letter-spacing: 0.04em; }

/* Active option chip highlighted in orange */
.option-chip--active { background: var(--color-accent) !important; border-color: var(--color-accent) !important; color: #000 !important; }

/* Empty state when no classes match filters */
.empty-state { text-align: center; padding: var(--space-3xl) var(--space-lg); display: flex; flex-direction: column; align-items: center; gap: var(--space-md); }
.empty-icon { font-size: 3rem; }
.empty-state h3 { color: var(--color-text-muted); }
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
