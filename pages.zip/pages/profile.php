<?php
/**
 * GymHub - My Profile
 * pages/profile.php
 *
 * The logged-in member's account management page.
 *
 * What this page shows:
 *   - Stats strip: total bookings, membership plan, join date, role
 *   - Sidebar: avatar, membership status, quick nav links
 *   - Edit profile form: update first name, last name, phone
 *   - Change password form: verify current password, set new one
 *
 * Two separate POST forms on the page, distinguished by a hidden
 * 'action' input field ('update_profile' or 'change_password').
 *
 * Security notes:
 *   - password_verify() used to check current password before allowing change
 *   - New password hashed with bcrypt before storing
 *   - Session variables updated immediately after name change so nav updates
 */

$page_title       = 'My Profile | GymHub';
$page_description = 'Manage your GymHub account — update your profile, change your password, and view your membership.';
$active_nav       = '';

// Context-sensitive help bar at the top of the page
$help_link = 'account-help.php';
$help_text = 'Need help with your account? Read Account Help';

require_once __DIR__ . '/../config/db.php';

// Redirect guests to login with return URL
if (!is_logged_in()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/profile.php'));
}

$user_id = $_SESSION['user_id'];
$errors  = [];
$success = '';

// ── Load current user data ────────────────────────────────────────────────────
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// ── Load active membership if any ────────────────────────────────────────────
// Only returns memberships that haven't expired (end_date >= today)
$stmt = $pdo->prepare("
    SELECT um.*, m.name, m.price
    FROM user_memberships um
    JOIN memberships m ON um.membership_id = m.id
    WHERE um.user_id = ? AND um.end_date >= CURDATE()
    ORDER BY um.end_date DESC LIMIT 1
");
$stmt->execute([$user_id]);
$membership = $stmt->fetch(); // null if no active plan

// ── Count total bookings for stats strip ─────────────────────────────────────
$total_bookings = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE user_id = ?");
$total_bookings->execute([$user_id]);
$total_bookings = $total_bookings->fetchColumn();

// ── Handle form submissions ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Read which form was submitted via hidden 'action' field
    $action = $_POST['action'] ?? '';

    // ── Update profile name and phone ─────────────────────────────────────────
    if ($action === 'update_profile') {
        $first_name = trim($_POST['first_name'] ?? '');
        $last_name  = trim($_POST['last_name']  ?? '');
        $phone      = trim($_POST['phone']      ?? '');

        if (empty($first_name)) $errors['first_name'] = 'First name is required.';
        if (empty($last_name))  $errors['last_name']  = 'Last name is required.';

        if (empty($errors)) {
            // Update the database record
            $pdo->prepare("UPDATE users SET first_name=?, last_name=?, phone=? WHERE id=?")
                ->execute([$first_name, $last_name, $phone ?: null, $user_id]);

            // Update session variables immediately so the nav shows new name
            $_SESSION['first_name'] = $first_name;
            $_SESSION['last_name']  = $last_name;

            $success = 'Profile updated successfully!';

            // Refresh local $user array so form shows updated values
            $user['first_name'] = $first_name;
            $user['last_name']  = $last_name;
            $user['phone']      = $phone;
        }
    }

    // ── Change password ───────────────────────────────────────────────────────
    if ($action === 'change_password') {
        $current  = $_POST['current_password']  ?? '';
        $new_pass = $_POST['new_password']       ?? '';
        $confirm  = $_POST['confirm_password']   ?? '';

        // password_verify() safely compares plain text against the bcrypt hash
        if (!password_verify($current, $user['password'])) {
            $errors['current_password'] = 'Current password is incorrect.';
        }
        if (strlen($new_pass) < 8) {
            $errors['new_password'] = 'New password must be at least 8 characters.';
        }
        if ($new_pass !== $confirm) {
            $errors['confirm_password'] = 'Passwords do not match.';
        }

        if (empty($errors)) {
            // Hash the new password before storing — never store plain text
            $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hashed, $user_id]);
            $success = 'Password changed successfully!';
        }
    }
}

// welcome=1 in URL means this is a fresh registration redirect
$welcome = isset($_GET['welcome']);

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">My Account</span>
        <h1>Welcome<?= $welcome ? ' to GymHub' : ' Back' ?>, <?= h($user['first_name']) ?>! 👋</h1>
        <p>Manage your profile, membership, and account settings.</p>
    </div>
</section>

<section class="profile-page section-pad">
    <div class="container">

        <!-- New registration welcome message -->
        <?php if ($welcome): ?>
        <div class="alert alert-success flash-message">
            🎉 Your account has been created! Welcome to GymHub.
            Start by <a href="classes.php">browsing our classes</a>.
        </div>
        <?php endif; ?>

        <!-- Form feedback messages -->
        <?php if ($success): ?>
        <div class="alert alert-success flash-message"><?= h($success) ?></div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
        </div>
        <?php endif; ?>

        <!-- Stats strip: 4 numbers at a glance -->
        <div class="profile-stats">
            <div class="profile-stat">
                <strong><?= $total_bookings ?></strong>
                <span>Total Bookings</span>
            </div>
            <div class="profile-stat">
                <!-- Show plan name or "None" if no active membership -->
                <strong><?= $membership ? h($membership['name']) : 'None' ?></strong>
                <span>Membership</span>
            </div>
            <div class="profile-stat">
                <!-- date() formats the created_at timestamp from DB -->
                <strong><?= date('M Y', strtotime($user['created_at'])) ?></strong>
                <span>Member Since</span>
            </div>
            <div class="profile-stat">
                <strong><?= ucfirst($user['role']) ?></strong>
                <span>Account Type</span>
            </div>
        </div>

        <div class="profile-grid">

            <!-- ── Left sidebar ── -->
            <aside class="profile-sidebar">

                <!-- Avatar card: initials, name, email, role badge -->
                <div class="avatar-card">
                    <!-- Circle shows first letter of first + last name -->
                    <div class="avatar-circle">
                        <?= strtoupper(substr($user['first_name'],0,1) . substr($user['last_name'],0,1)) ?>
                    </div>
                    <h3><?= h($user['first_name'] . ' ' . $user['last_name']) ?></h3>
                    <p class="profile-email"><?= h($user['email']) ?></p>
                    <span class="role-badge role-badge--<?= h($user['role']) ?>">
                        <?= ucfirst($user['role']) ?>
                    </span>
                </div>

                <!-- Membership status -->
                <div class="sidebar-card">
                    <h4>Membership</h4>
                    <?php if ($membership): ?>
                    <div class="membership-status">
                        <!-- Green pulsing dot = active plan -->
                        <span class="status-dot status-dot--green"></span>
                        <div>
                            <strong><?= h($membership['name']) ?> Plan</strong>
                            <p>Expires <?= date('M j, Y', strtotime($membership['end_date'])) ?></p>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="membership-status">
                        <!-- Grey dot = no active plan -->
                        <span class="status-dot status-dot--grey"></span>
                        <div>
                            <strong>No active plan</strong>
                            <p><a href="membership.php">Browse plans →</a></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Quick navigation links -->
                <div class="sidebar-card">
                    <h4>Quick Links</h4>
                    <ul class="quick-links">
                        <li><a href="bookings.php">📅 My Bookings</a></li>
                        <li><a href="progress.php">📈 Progress Tracker</a></li>
                        <li><a href="ask-trainer.php">💬 Ask a Trainer</a></li>
                        <li><a href="classes.php">🏋️ Browse Classes</a></li>
                        <li><a href="membership.php">🏆 Membership Plans</a></li>
                        <?php if (is_admin()): ?>
                        <!-- Admin panel link only visible to admins -->
                        <li><a href="<?= SITE_URL ?>/admin/dashboard.php">⚙️ Admin Panel</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </aside>

            <!-- ── Main: edit forms ── -->
            <div class="profile-main">

                <!-- Form 1: edit name and phone -->
                <div class="profile-card">
                    <h3>Edit Profile</h3>
                    <form method="POST" action="" class="profile-form">
                        <!-- Hidden action tells POST handler which form this is -->
                        <input type="hidden" name="action" value="update_profile">
                        <div class="form-row">
                            <div class="form-group <?= isset($errors['first_name']) ? 'form-group--error' : '' ?>">
                                <label for="first_name">First Name</label>
                                <input type="text" id="first_name" name="first_name"
                                       value="<?= h($user['first_name']) ?>" required>
                                <?php if (isset($errors['first_name'])): ?>
                                <span class="form-error"><?= h($errors['first_name']) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group <?= isset($errors['last_name']) ? 'form-group--error' : '' ?>">
                                <label for="last_name">Last Name</label>
                                <input type="text" id="last_name" name="last_name"
                                       value="<?= h($user['last_name']) ?>" required>
                                <?php if (isset($errors['last_name'])): ?>
                                <span class="form-error"><?= h($errors['last_name']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Email is disabled — cannot be changed after registration -->
                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" value="<?= h($user['email']) ?>" disabled>
                            <span class="form-hint">Email address cannot be changed.</span>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone"
                                   value="<?= h($user['phone'] ?? '') ?>"
                                   placeholder="519-555-0100">
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>

                <!-- Form 2: change password -->
                <div class="profile-card">
                    <h3>Change Password</h3>
                    <form method="POST" action="" class="profile-form">
                        <input type="hidden" name="action" value="change_password">
                        <div class="form-group <?= isset($errors['current_password']) ? 'form-group--error' : '' ?>">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password"
                                   placeholder="Your current password" required>
                            <?php if (isset($errors['current_password'])): ?>
                            <span class="form-error"><?= h($errors['current_password']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?= isset($errors['new_password']) ? 'form-group--error' : '' ?>">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password"
                                   placeholder="Min. 8 characters" required>
                            <?php if (isset($errors['new_password'])): ?>
                            <span class="form-error"><?= h($errors['new_password']) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?= isset($errors['confirm_password']) ? 'form-group--error' : '' ?>">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password"
                                   placeholder="Repeat new password" required>
                            <?php if (isset($errors['confirm_password'])): ?>
                            <span class="form-error"><?= h($errors['confirm_password']) ?></span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-secondary">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.profile-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:var(--space-md);margin-bottom:var(--space-xl)}
.profile-stat{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg);text-align:center}
.profile-stat strong{display:block;font-family:var(--font-display);font-size:1.5rem;font-weight:900;color:var(--color-accent);line-height:1;margin-bottom:.3rem}
.profile-stat span{font-size:.8rem;color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.06em}
.profile-grid{display:grid;grid-template-columns:260px 1fr;gap:var(--space-xl);align-items:start}
.profile-sidebar{display:flex;flex-direction:column;gap:var(--space-md)}
.avatar-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl);text-align:center;display:flex;flex-direction:column;align-items:center;gap:var(--space-sm)}
.avatar-circle{width:80px;height:80px;border-radius:50%;background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:1.8rem;font-weight:900;display:flex;align-items:center;justify-content:center;margin-bottom:var(--space-sm)}
.profile-email{color:var(--color-text-muted);font-size:.85rem}
.role-badge{font-family:var(--font-display);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;padding:.2rem .7rem;border-radius:var(--radius-full)}
.role-badge--member{background:var(--color-accent-glow);color:var(--color-accent);border:1px solid var(--color-accent)}
.role-badge--admin{background:rgba(239,68,68,.1);color:var(--color-danger);border:1px solid var(--color-danger)}
.sidebar-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg)}
.sidebar-card h4{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.membership-status{display:flex;align-items:center;gap:var(--space-sm)}
.membership-status strong{display:block;font-size:.95rem;color:var(--color-text)}
.membership-status p{font-size:.8rem;color:var(--color-text-muted);margin:0}
.status-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.status-dot--green{background:var(--color-success);box-shadow:0 0 6px var(--color-success)}
.status-dot--grey{background:var(--color-text-muted)}
.quick-links{display:flex;flex-direction:column;gap:.4rem}
.quick-links a{color:var(--color-text-muted);font-size:.9rem;padding:.35rem 0;display:block;transition:color var(--transition-fast)}
.quick-links a:hover{color:var(--color-accent)}
.profile-main{display:flex;flex-direction:column;gap:var(--space-lg)}
.profile-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.profile-card h3{margin-bottom:var(--space-lg)}
.profile-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group input{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.95rem;outline:none;transition:border-color var(--transition-fast);width:100%}
.form-group input:focus{border-color:var(--color-accent);box-shadow:0 0 0 3px var(--color-accent-glow)}
.form-group input:disabled{opacity:.5;cursor:not-allowed}
.form-group--error input{border-color:var(--color-danger)}
.form-error{color:var(--color-danger);font-size:.8rem}
.form-hint{color:var(--color-text-muted);font-size:.78rem}
.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-lg)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}
.alert ul{padding-left:1.2rem;margin-top:.4rem}
@media(max-width:900px){.profile-grid{grid-template-columns:1fr}.profile-stats{grid-template-columns:repeat(2,1fr)}.form-row{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
