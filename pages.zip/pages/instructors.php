<?php
/**
 * GymHub - Instructors Page
 * pages/instructors.php
 *
 * Displays all GymHub instructors as full-page profile sections.
 * Each profile shows: photo, name, rating badge, specialties, bio,
 * stats (class count, rating), and the classes they teach.
 *
 * Data sources:
 *   instructors JOIN users  — gets instructor name and email
 *   Second query per instructor — gets their assigned classes
 *
 * The foreach uses a reference (&$inst) to add the 'classes' key
 * directly to each array element without creating a copy.
 * The unset() after the loop breaks the reference to prevent bugs.
 */

$page_title       = 'Our Instructors | GymHub';
$page_description = 'Meet the GymHub certified fitness instructors. Expert coaches in strength, yoga, combat, cardio, and wellness.';
$page_keywords    = 'gym instructors Windsor, personal trainer Windsor, fitness coach, yoga instructor Windsor';
$active_nav       = 'instructors';

require_once __DIR__ . '/../config/db.php';

// ── Load all instructors ordered best-rated first ─────────────────────────────
// JOIN users to get the full name since instructors only stores the user_id
$stmt = $pdo->query("
    SELECT i.*,
           CONCAT(u.first_name, ' ', u.last_name) AS name,
           u.email
    FROM instructors i
    JOIN users u ON i.user_id = u.id
    ORDER BY i.rating DESC
");
$instructors = $stmt->fetchAll();

// ── Load each instructor's active classes ─────────────────────────────────────
// We use a foreach with reference (&$inst) so we can add a 'classes' key
// to the same array element that was fetched above.
// Without the &, PHP would modify a copy and the original wouldn't change.
foreach ($instructors as &$inst) {
    $cs = $pdo->prepare("
        SELECT id, title, category, price, duration_min
        FROM classes
        WHERE instructor_id = ? AND status = 'active'
        ORDER BY title ASC
    ");
    $cs->execute([$inst['id']]);
    $inst['classes'] = $cs->fetchAll(); // add classes sub-array to this instructor
}
unset($inst); // IMPORTANT: break the reference or the last element can be corrupted

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">The Team</span>
        <h1>Meet Our Instructors</h1>
        <p>Certified professionals passionate about helping you reach your fitness goals.</p>
    </div>
</section>

<section class="instructors-page section-pad">
    <div class="container">

        <!-- Loop through each instructor and render a full profile card -->
        <?php foreach ($instructors as $inst): ?>
        <div class="instructor-profile" id="instructor-<?= $inst['id'] ?>">

            <!-- Two-column header: photo left, info right -->
            <div class="instructor-profile-header">

                <!-- Photo with rating badge overlaid on bottom-right corner -->
                <div class="instructor-profile-photo">
                    <img src="<?= SITE_URL ?>/public/assets/images/instructors/<?= h($inst['photo']) ?>"
                         alt="<?= h($inst['name']) ?> GymHub instructor"
                         onerror="this.src='<?= SITE_URL ?>/public/assets/images/instructors/default-instructor.png'">
                    <!-- Rating badge — shows average star score -->
                    <div class="instructor-rating-badge">
                        ⭐ <?= number_format($inst['rating'], 2) ?>
                    </div>
                </div>

                <!-- Name, specialties, bio, stats, CTA button -->
                <div class="instructor-profile-info">
                    <h2><?= h($inst['name']) ?></h2>

                    <!-- Specialties in orange uppercase — visually distinct -->
                    <p class="instructor-specialties-large"><?= h($inst['specialties']) ?></p>

                    <!-- Full bio paragraph -->
                    <p class="instructor-bio-full"><?= h($inst['bio']) ?></p>

                    <!-- Stats row: classes count, rating, max possible score -->
                    <div class="instructor-stats">
                        <div class="inst-stat">
                            <!-- count() the classes array we loaded above -->
                            <strong><?= count($inst['classes']) ?></strong>
                            <span>Classes</span>
                        </div>
                        <div class="inst-stat">
                            <strong><?= number_format($inst['rating'], 2) ?></strong>
                            <span>Rating</span>
                        </div>
                        <div class="inst-stat">
                            <strong>5.0</strong>
                            <span>Max Score</span>
                        </div>
                    </div>

                    <!-- CTA: ask this specific instructor a question
                         explode() splits full name on space, [0] gets just first name -->
                    <a href="ask-trainer.php" class="btn btn-primary btn-sm">
                        💬 Ask <?= h(explode(' ', $inst['name'])[0]) ?> a Question
                    </a>
                </div>
            </div>

            <!-- Classes this instructor teaches -->
            <?php if (!empty($inst['classes'])): ?>
            <div class="instructor-classes">
                <h3>Classes by <?= h(explode(' ', $inst['name'])[0]) ?></h3>
                <div class="instructor-classes-grid">
                    <?php foreach ($inst['classes'] as $c): ?>
                    <!-- Each card links to the class detail/booking page -->
                    <a href="class-detail.php?id=<?= $c['id'] ?>" class="inst-class-card">
                        <span class="class-category-badge"><?= h($c['category']) ?></span>
                        <h4><?= h($c['title']) ?></h4>
                        <div class="inst-class-meta">
                            <span>⏱ <?= $c['duration_min'] ?> min</span>
                            <span>$<?= number_format($c['price'], 2) ?></span>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
        <?php endforeach; ?>

        <!-- Bottom CTA -->
        <div class="instructors-cta">
            <h2>Want to Train with Our Experts?</h2>
            <p>Browse the full class schedule and book a session today.</p>
            <div style="display:flex;gap:var(--space-md);justify-content:center;flex-wrap:wrap;margin-top:var(--space-xl);">
                <a href="schedule.php"    class="btn btn-primary">View Schedule</a>
                <a href="ask-trainer.php" class="btn btn-secondary">Ask a Trainer</a>
            </div>
        </div>

    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.instructor-profile{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-2xl);margin-bottom:var(--space-xl);overflow:hidden}
.instructor-profile-header{display:grid;grid-template-columns:260px 1fr;gap:var(--space-2xl);margin-bottom:var(--space-xl)}
.instructor-profile-photo{position:relative}
.instructor-profile-photo img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:var(--radius-lg)}
.instructor-rating-badge{position:absolute;bottom:.75rem;right:.75rem;background:rgba(0,0,0,.8);color:var(--color-accent);font-family:var(--font-display);font-size:.9rem;font-weight:700;padding:.25rem .65rem;border-radius:var(--radius-full);backdrop-filter:blur(4px)}
.instructor-profile-info{display:flex;flex-direction:column;gap:var(--space-md);justify-content:center}
.instructor-profile-info h2{font-size:2rem;margin:0}
.instructor-specialties-large{color:var(--color-accent);font-family:var(--font-display);font-size:.9rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em}
.instructor-bio-full{color:var(--color-text-light);line-height:1.7}
.instructor-stats{display:flex;gap:var(--space-xl)}
.inst-stat{display:flex;flex-direction:column}
.inst-stat strong{font-family:var(--font-display);font-size:1.6rem;font-weight:900;color:var(--color-accent);line-height:1}
.inst-stat span{font-size:.75rem;color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.06em}
.instructor-classes{border-top:1px solid var(--color-border);padding-top:var(--space-xl)}
.instructor-classes h3{margin-bottom:var(--space-lg);font-size:1.1rem}
.instructor-classes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:var(--space-md)}
.inst-class-card{background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-md);display:flex;flex-direction:column;gap:.4rem;transition:all var(--transition-normal);text-decoration:none}
.inst-class-card:hover{border-color:var(--color-accent);transform:translateY(-2px)}
.inst-class-card h4{font-size:.95rem;color:var(--color-text)}
.inst-class-meta{display:flex;justify-content:space-between;font-size:.8rem;color:var(--color-text-muted);margin-top:auto}
.instructors-cta{text-align:center;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-2xl) var(--space-xl);margin-top:var(--space-2xl)}
.instructors-cta h2{margin-bottom:var(--space-sm)}
.instructors-cta p{color:var(--color-text-muted)}
@media(max-width:768px){.instructor-profile-header{grid-template-columns:1fr}.instructor-profile-photo img{max-height:300px}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
