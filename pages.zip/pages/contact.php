<?php
/**
 * GymHub - Contact Us
 * pages/contact.php
 *
 * Static contact page showing location info, phone, email,
 * and a contact form. The form currently shows a success message
 * on submission — in production it would send an email via PHP mail().
 *
 * No database queries needed on this page.
 */

$page_title       = 'Contact Us | GymHub';
$page_description = 'Get in touch with GymHub. Contact us by phone, email, or by filling in our online form. Three Windsor locations available.';
$page_keywords    = 'contact GymHub, gym Windsor phone, gym email, gym address Windsor';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';

$form_success = false;
$errors       = [];

// ── Handle contact form submission ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Collect and sanitize form inputs
    $name    = trim($_POST['name']    ?? '');
    $email   = trim($_POST['email']   ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    // Basic validation
    if (empty($name))                                  $errors[] = 'Name is required.';
    if (empty($email))                                 $errors[] = 'Email address is required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Please enter a valid email address.';
    if (empty($subject))                               $errors[] = 'Subject is required.';
    if (empty($message))                               $errors[] = 'Message is required.';

    if (empty($errors)) {
        // In production, you would send an email here using PHP mail() or a library like PHPMailer.
        // For now, we just show a success message to demonstrate the form works.
        // Example: mail('info@gymhub.com', $subject, $message, 'From: ' . $email);
        $form_success = true;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Get In Touch</span>
        <h1>Contact Us</h1>
        <p>We'd love to hear from you. Our team responds within 24 hours.</p>
    </div>
</section>

<section class="contact-page section-pad">
    <div class="container">
        <div class="contact-grid">

            <!-- ── Left: contact info ── -->
            <div class="contact-info">
                <h2>Reach Out</h2>
                <p style="color:var(--color-text-muted);margin-bottom:var(--space-xl);">
                    Have a question about membership, classes, or anything else?
                    Fill in the form or contact us directly using the details below.
                </p>

                <!-- Contact detail blocks -->
                <div class="contact-details">
                    <div class="contact-detail">
                        <span class="contact-icon">📍</span>
                        <div>
                            <strong>Main Location</strong>
                            <p>123 King St W, Windsor, ON N9A 5K6</p>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <span class="contact-icon">📞</span>
                        <div>
                            <strong>Phone</strong>
                            <p><a href="tel:+15199550100">(519) 955-0100</a></p>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <span class="contact-icon">📧</span>
                        <div>
                            <strong>Email</strong>
                            <p><a href="mailto:info@gymhub.com">info@gymhub.com</a></p>
                        </div>
                    </div>
                    <div class="contact-detail">
                        <span class="contact-icon">🕐</span>
                        <div>
                            <strong>Hours</strong>
                            <p>Mon–Fri: 5:30 AM – 10:00 PM<br>
                               Sat–Sun: 7:00 AM – 8:00 PM</p>
                        </div>
                    </div>
                </div>

                <!-- Quick links to other help resources -->
                <div class="contact-alt">
                    <h4>Other Ways to Get Help</h4>
                    <ul class="contact-links">
                        <li><a href="faq.php">📋 Read our FAQ</a></li>
                        <li><a href="ask-trainer.php">💬 Ask a Trainer directly</a></li>
                        <li><a href="<?= SITE_URL ?>/wiki/getting-started.php">📖 Getting Started Guide</a></li>
                    </ul>
                </div>
            </div>

            <!-- ── Right: contact form ── -->
            <div class="contact-form-card">
                <?php if ($form_success): ?>
                <!-- Success state — shown after form submitted successfully -->
                <div class="form-success">
                    <div class="success-icon">✅</div>
                    <h3>Message Sent!</h3>
                    <p>Thank you for reaching out. We'll get back to you within 24 hours.</p>
                    <a href="contact.php" class="btn btn-secondary btn-sm">Send Another Message</a>
                </div>

                <?php else: ?>
                <h3>Send Us a Message</h3>

                <!-- Show validation errors if any -->
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
                </div>
                <?php endif; ?>

                <!-- Contact form — novalidate lets PHP handle validation -->
                <form method="POST" action="" class="contact-form" novalidate>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Your Name *</label>
                            <!-- value repopulated so user doesn't retype on error -->
                            <input type="text" id="name" name="name"
                                   value="<?= h($_POST['name'] ?? '') ?>"
                                   placeholder="Jane Smith" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email"
                                   value="<?= h($_POST['email'] ?? '') ?>"
                                   placeholder="jane@example.com" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="subject">Subject *</label>
                        <select id="subject" name="subject" required>
                            <option value="">-- Select a topic --</option>
                            <option value="Membership Inquiry"    <?= ($_POST['subject'] ?? '') === 'Membership Inquiry'    ? 'selected' : '' ?>>Membership Inquiry</option>
                            <option value="Class Information"     <?= ($_POST['subject'] ?? '') === 'Class Information'     ? 'selected' : '' ?>>Class Information</option>
                            <option value="Booking Issue"         <?= ($_POST['subject'] ?? '') === 'Booking Issue'         ? 'selected' : '' ?>>Booking Issue</option>
                            <option value="Technical Support"     <?= ($_POST['subject'] ?? '') === 'Technical Support'     ? 'selected' : '' ?>>Technical Support</option>
                            <option value="General Question"      <?= ($_POST['subject'] ?? '') === 'General Question'      ? 'selected' : '' ?>>General Question</option>
                            <option value="Other"                 <?= ($_POST['subject'] ?? '') === 'Other'                 ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="message">Message *</label>
                        <textarea id="message" name="message" rows="6"
                                  placeholder="How can we help you?"
                                  required><?= h($_POST['message'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-full">Send Message</button>
                </form>
                <?php endif; ?>
            </div>

        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}

/* Two-column layout */
.contact-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-2xl);align-items:start}

/* Contact detail rows */
.contact-details{display:flex;flex-direction:column;gap:var(--space-lg);margin-bottom:var(--space-xl)}
.contact-detail{display:flex;gap:var(--space-md);align-items:flex-start}
.contact-icon{font-size:1.5rem;flex-shrink:0}
.contact-detail strong{display:block;font-size:.95rem;color:var(--color-text);margin-bottom:.2rem}
.contact-detail p{color:var(--color-text-muted);font-size:.875rem;line-height:1.6;margin:0}
.contact-detail a{color:var(--color-accent)}

/* Alternative links */
.contact-alt h4{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.contact-links{display:flex;flex-direction:column;gap:.4rem}
.contact-links a{color:var(--color-text-muted);font-size:.875rem;padding:.3rem 0;display:block;transition:color var(--transition-fast)}
.contact-links a:hover{color:var(--color-accent)}

/* Form card */
.contact-form-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-2xl)}
.contact-form-card h3{margin-bottom:var(--space-lg)}
.contact-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group input,.form-group select,.form-group textarea{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.9rem;outline:none;width:100%;transition:border-color var(--transition-fast)}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{border-color:var(--color-accent)}
.form-group textarea{resize:vertical}
.btn-full{width:100%;justify-content:center}

/* Success state */
.form-success{text-align:center;padding:var(--space-2xl) var(--space-lg);display:flex;flex-direction:column;align-items:center;gap:var(--space-md)}
.success-icon{font-size:3rem}
.form-success h3{color:var(--color-success)}
.form-success p{color:var(--color-text-muted)}

.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-md)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert ul{padding-left:1.2rem;margin-top:.4rem}

@media(max-width:768px){.contact-grid{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
