<?php
/**
 * GymHub - Terms of Service
 * pages/terms.php
 *
 * Static legal page outlining the rules and conditions for using
 * the GymHub platform. Users must agree to these terms when
 * registering — the register.php form has a required checkbox.
 *
 * No database queries needed — entirely static content.
 */

$page_title       = 'Terms of Service | GymHub';
$page_description = 'GymHub Terms of Service — rules and conditions for using our fitness class booking platform.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Legal</span>
        <h1>Terms of Service</h1>
        <p>Last updated: January 2025. Please read these terms carefully before using GymHub.</p>
    </div>
</section>

<section class="legal-page section-pad">
    <div class="container">
        <div class="legal-layout">

            <!-- Sidebar navigation -->
            <nav class="legal-nav">
                <h4>Sections</h4>
                <ul>
                    <li><a href="#acceptance">Acceptance</a></li>
                    <li><a href="#accounts">Accounts</a></li>
                    <li><a href="#bookings">Bookings</a></li>
                    <li><a href="#conduct">Conduct</a></li>
                    <li><a href="#health">Health & Safety</a></li>
                    <li><a href="#payments">Payments</a></li>
                    <li><a href="#ip">Intellectual Property</a></li>
                    <li><a href="#termination">Termination</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </nav>

            <!-- Main content -->
            <div class="legal-content">

                <div class="legal-intro">
                    <p>
                        These Terms of Service ("Terms") govern your use of GymHub and all related
                        services. By creating an account or using our platform, you agree to be
                        bound by these Terms. If you do not agree, please do not use GymHub.
                    </p>
                </div>

                <div class="legal-section" id="acceptance">
                    <h2>1. Acceptance of Terms</h2>
                    <p>
                        By accessing or using GymHub you confirm that you are at least 16 years of
                        age and have the legal capacity to enter into a binding agreement. If you
                        are under 18, a parent or guardian must agree to these Terms on your behalf.
                    </p>
                </div>

                <div class="legal-section" id="accounts">
                    <h2>2. User Accounts</h2>
                    <ul class="legal-list">
                        <li>You must provide accurate and complete information when registering.</li>
                        <li>You are responsible for maintaining the confidentiality of your password.</li>
                        <li>You must notify us immediately of any unauthorised use of your account.</li>
                        <li>One account per person — creating multiple accounts is not permitted.</li>
                        <li>We reserve the right to suspend or terminate accounts that violate these Terms.</li>
                    </ul>
                </div>

                <div class="legal-section" id="bookings">
                    <h2>3. Class Bookings and Cancellations</h2>
                    <ul class="legal-list">
                        <li>Bookings are confirmed immediately upon submission and subject to availability.</li>
                        <li>Free cancellation is available up to 24 hours before the class start time.</li>
                        <li>Cancellations made within 24 hours of the class may not be eligible for a refund.</li>
                        <li>No-shows without prior cancellation forfeit the session fee.</li>
                        <li>GymHub reserves the right to cancel or reschedule sessions due to low enrolment or unforeseen circumstances.</li>
                    </ul>
                </div>

                <div class="legal-section" id="conduct">
                    <h2>4. Code of Conduct</h2>
                    <p>When using GymHub — in person or online — you agree to:</p>
                    <ul class="legal-list">
                        <li>Treat all members, instructors, and staff with respect.</li>
                        <li>Not submit false, misleading, or defamatory content in reviews or questions.</li>
                        <li>Not attempt to access other users' accounts or data.</li>
                        <li>Not use the platform for any unlawful purpose.</li>
                        <li>Follow all facility rules at GymHub locations.</li>
                    </ul>
                </div>

                <div class="legal-section" id="health">
                    <h2>5. Health and Safety</h2>
                    <p>
                        By booking a class you confirm that you are in suitable physical condition
                        to participate. GymHub strongly recommends consulting a physician before
                        starting any new fitness programme.
                    </p>
                    <p>
                        GymHub and its instructors are not responsible for injuries resulting
                        from failure to disclose pre-existing medical conditions or from ignoring
                        an instructor's safety guidance.
                    </p>
                </div>

                <div class="legal-section" id="payments">
                    <h2>6. Payments and Memberships</h2>
                    <ul class="legal-list">
                        <li>All prices are in Canadian dollars (CAD) and include applicable taxes.</li>
                        <li>Membership fees are billed monthly in advance.</li>
                        <li>You may cancel your membership at any time — cancellation takes effect at the end of the current billing period.</li>
                        <li>GymHub reserves the right to change pricing with 30 days' notice.</li>
                    </ul>
                </div>

                <div class="legal-section" id="ip">
                    <h2>7. Intellectual Property</h2>
                    <p>
                        All content on GymHub — including text, images, logos, and code — is owned
                        by GymHub or its licensors. You may not copy, reproduce, or distribute any
                        content without prior written permission.
                    </p>
                </div>

                <div class="legal-section" id="termination">
                    <h2>8. Termination</h2>
                    <p>
                        GymHub may suspend or terminate your account at any time for violations of
                        these Terms. Upon termination, your right to use the platform ceases
                        immediately. Provisions that by their nature should survive termination
                        (including payment obligations and intellectual property) will do so.
                    </p>
                </div>

                <div class="legal-section" id="contact">
                    <h2>9. Contact</h2>
                    <p>Questions about these Terms? Contact us:</p>
                    <ul class="legal-list">
                        <li>Email: <a href="mailto:legal@gymhub.com">legal@gymhub.com</a></li>
                        <li>Address: 123 King St W, Windsor, ON N9A 5K6</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.legal-layout{display:grid;grid-template-columns:200px 1fr;gap:var(--space-2xl);align-items:start}
.legal-nav{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg);position:sticky;top:90px}
.legal-nav h4{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.legal-nav ul{list-style:none;display:flex;flex-direction:column;gap:.25rem}
.legal-nav a{display:block;padding:.4rem .6rem;color:var(--color-text-muted);font-size:.875rem;border-radius:var(--radius-sm);transition:all var(--transition-fast);text-decoration:none}
.legal-nav a:hover{color:var(--color-accent);background:var(--color-accent-glow)}
.legal-content{display:flex;flex-direction:column;gap:var(--space-xl)}
.legal-intro p{color:var(--color-text-light);font-size:1rem;line-height:1.8;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.legal-section h2{font-size:1.2rem;margin-bottom:var(--space-md);padding-bottom:var(--space-sm);border-bottom:1px solid var(--color-border)}
.legal-section p{color:var(--color-text-light);line-height:1.8;margin-bottom:var(--space-md)}
.legal-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.5rem}
.legal-list li{color:var(--color-text-light);font-size:.9rem;line-height:1.7}
.legal-list a{color:var(--color-accent)}
@media(max-width:768px){.legal-layout{grid-template-columns:1fr}.legal-nav{position:static}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
