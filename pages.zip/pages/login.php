<?php
/**
 * GymHub - User Login
 * pages/login.php
 *
 * Authenticates users with email + password.
 * Uses password_verify() against bcrypt hash.
 * Sets session variables on success.
 */

$page_title       = 'Log In | GymHub';
$page_description = 'Log in to your GymHub account to book classes, track progress, and manage your membership.';
$page_keywords    = 'gym login, GymHub sign in, member login';
$active_nav       = 'login';

require_once __DIR__ . '/../config/db.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect(SITE_URL . '/pages/profile.php');
}

$errors  = [];
$old_email = '';

// ── Handle form submission ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';
    $old_email = $email;

    // Basic validation
    if (empty($email)) {
        $errors['email'] = 'Email address is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    }

    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    }

    // ── Attempt authentication ────────────────────────────────────────────────
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            // Generic error — don't reveal whether email exists
            $errors['general'] = 'Invalid email or password. Please try again.';
        } elseif ($user['status'] === 'disabled') {
            $errors['general'] = 'Your account has been disabled. Please contact support.';
        } else {
            // ── Success — set session ─────────────────────────────────────────
            session_regenerate_id(true); // prevent session fixation
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name']  = $user['last_name'];
            $_SESSION['email']      = $user['email'];
            $_SESSION['role']       = $user['role'];

            // Redirect to intended page or default
            $redirect = $_GET['redirect'] ?? '';
            if ($redirect && strpos($redirect, SITE_URL) === 0) {
                redirect($redirect);
            } elseif ($user['role'] === 'admin') {
                redirect(SITE_URL . '/admin/dashboard.php');
            } else {
                redirect(SITE_URL . '/pages/profile.php');
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-page">
    <div class="auth-container auth-container--login">

        <!-- Brand panel -->
        <div class="auth-panel auth-panel--brand">
            <a href="<?= SITE_URL ?>/index.php" class="auth-logo">
                <span>⚡</span> GYM<strong>HUB</strong>
            </a>
            <h2>Welcome Back, Champion</h2>
            <p>Log in to access your bookings, track your progress, and connect with your instructors.</p>
            <ul class="auth-perks">
                <li>✓ View and manage your class bookings</li>
                <li>✓ Check your fitness progress charts</li>
                <li>✓ Get answers from our expert trainers</li>
                <li>✓ Rate classes you've attended</li>
            </ul>
            <div class="auth-switch">
                Don't have an account?
                <a href="register.php">Sign up free →</a>
            </div>
        </div>

        <!-- Login form -->
        <div class="auth-panel auth-panel--form">
            <h2>Log In to GymHub</h2>
            <p class="auth-subtitle">Enter your credentials to continue.</p>

            <?php if (isset($_GET['registered'])): ?>
            <div class="alert alert-success" role="alert">
                ✅ Account created! Please log in below.
            </div>
            <?php endif; ?>

            <?php if (isset($errors['general'])): ?>
            <div class="alert alert-danger" role="alert">
                <?= h($errors['general']) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="" class="auth-form" novalidate>

                <div class="form-group <?= isset($errors['email']) ? 'form-group--error' : '' ?>">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email"
                           value="<?= h($old_email) ?>"
                           placeholder="jane@example.com"
                           required autocomplete="email"
                           autofocus>
                    <?php if (isset($errors['email'])): ?>
                    <span class="form-error"><?= h($errors['email']) ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group <?= isset($errors['password']) ? 'form-group--error' : '' ?>">
                    <label for="password">
                        Password
                        <a href="forgot-password.php" class="forgot-link">Forgot password?</a>
                    </label>
                    <div class="input-password">
                        <input type="password" id="password" name="password"
                               placeholder="Your password"
                               required autocomplete="current-password">
                        <button type="button" class="toggle-password" aria-label="Show password"
                                onclick="togglePassword('password', this)">👁</button>
                    </div>
                    <?php if (isset($errors['password'])): ?>
                    <span class="form-error"><?= h($errors['password']) ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group form-group--checkbox">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        Keep me logged in
                    </label>
                </div>

                <button type="submit" class="btn btn-primary btn-full">
                    Log In →
                </button>

                <div class="auth-divider"><span>or</span></div>

                <p class="auth-login-link">
                    New to GymHub? <a href="register.php">Create a free account</a>
                </p>

            </form>
        </div>

    </div>
</section>

<script>
function togglePassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '🙈';
    } else {
        input.type = 'password';
        btn.textContent = '👁';
    }
}
</script>

<style>
/* Re-use auth styles from register.php, add login-specific tweaks */
.auth-page {
    min-height: calc(100vh - 70px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--space-xl) var(--space-lg);
}

.auth-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    width: 100%;
    max-width: 900px;
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-lg);
    overflow: hidden;
    box-shadow: var(--shadow-lg);
}

.auth-panel { padding: var(--space-2xl); }

.auth-panel--brand {
    background: linear-gradient(160deg, var(--color-accent) 0%, var(--color-accent-dark) 100%);
    display: flex;
    flex-direction: column;
    gap: var(--space-lg);
}
.auth-logo {
    font-family: var(--font-display);
    font-size: 1.5rem;
    font-weight: 400;
    color: #000;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 0.4rem;
}
.auth-logo strong { font-weight: 900; }
.auth-panel--brand h2 { color: #000; }
.auth-panel--brand p  { color: rgba(0,0,0,0.7); }
.auth-perks { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; }
.auth-perks li { font-size: 0.9rem; color: rgba(0,0,0,0.8); }
.auth-switch { margin-top: auto; font-size: 0.9rem; color: rgba(0,0,0,0.7); }
.auth-switch a { color: #000; font-weight: 700; }

.auth-panel--form h2 { margin-bottom: 0.25rem; }
.auth-subtitle { color: var(--color-text-muted); margin-bottom: var(--space-lg); font-size: 0.95rem; }

.auth-form { display: flex; flex-direction: column; gap: var(--space-md); }

.form-group { display: flex; flex-direction: column; gap: 0.35rem; }
.form-group label {
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--color-text);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.forgot-link {
    font-size: 0.8rem;
    font-weight: 400;
    color: var(--color-accent);
}

.form-group input[type="email"],
.form-group input[type="password"] {
    background: var(--color-surface-2);
    border: 1px solid var(--color-border);
    color: var(--color-text);
    padding: 0.65rem 0.9rem;
    border-radius: var(--radius-sm);
    font-family: var(--font-body);
    font-size: 0.95rem;
    outline: none;
    transition: border-color var(--transition-fast);
    width: 100%;
}
.form-group input:focus {
    border-color: var(--color-accent);
    box-shadow: 0 0 0 3px var(--color-accent-glow);
}
.form-group--error input { border-color: var(--color-danger); }
.form-error { color: var(--color-danger); font-size: 0.8rem; }

.input-password { position: relative; }
.input-password input { padding-right: 2.5rem; }
.toggle-password {
    position: absolute; right: 0.6rem; top: 50%; transform: translateY(-50%);
    background: none; border: none; cursor: pointer; font-size: 1rem; padding: 0.25rem;
}

.form-group--checkbox .checkbox-label {
    display: flex; align-items: center; gap: 0.5rem;
    font-size: 0.875rem; color: var(--color-text-muted); cursor: pointer; font-weight: 400;
}
.form-group--checkbox input[type="checkbox"] {
    width: 16px; height: 16px; accent-color: var(--color-accent);
}

.btn-full { width: 100%; justify-content: center; }

.auth-divider {
    display: flex; align-items: center; gap: var(--space-md);
    color: var(--color-text-muted); font-size: 0.85rem;
}
.auth-divider::before, .auth-divider::after {
    content: ''; flex: 1; height: 1px; background: var(--color-border);
}

.auth-login-link { text-align: center; font-size: 0.875rem; color: var(--color-text-muted); }

.alert {
    padding: var(--space-md); border-radius: var(--radius-sm);
    font-size: 0.9rem; border: 1px solid transparent;
}
.alert-danger  { background: rgba(239,68,68,0.1);  border-color: var(--color-danger);  color: var(--color-danger); }
.alert-success { background: rgba(34,197,94,0.1);  border-color: var(--color-success); color: var(--color-success); }

.demo-hint {
    background: var(--color-surface-2);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: var(--space-md);
    font-size: 0.8rem;
    color: var(--color-text-muted);
    line-height: 1.8;
}
.demo-hint strong { color: var(--color-text); }
.demo-hint code {
    background: var(--color-bg);
    padding: 0.1rem 0.4rem;
    border-radius: 3px;
    font-size: 0.8rem;
    color: var(--color-accent);
}

@media (max-width: 768px) {
    .auth-container { grid-template-columns: 1fr; }
    .auth-panel--brand { display: none; }
    .auth-page { padding: 0; align-items: flex-start; }
    .auth-container { border-radius: 0; border: none; }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
