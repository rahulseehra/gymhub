<?php
/**
 * GymHub - Privacy Policy
 * pages/privacy.php
 *
 * Static legal page describing how GymHub collects, uses, and
 * protects user personal data. Required for any website that
 * collects user information such as names, emails, and bookings.
 *
 * No database queries — entirely static content.
 */

$page_title       = 'Privacy Policy | GymHub';
$page_description = 'GymHub Privacy Policy — how we collect, use, and protect your personal information.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Legal</span>
        <h1>Privacy Policy</h1>
        <p>Last updated: January 2025</p>
    </div>
</section>

<section class="legal-page section-pad">
    <div class="container">
        <div class="legal-layout">

            <!-- Sidebar navigation for jumping to sections -->
            <nav class="legal-nav">
                <h4>Sections</h4>
                <ul>
                    <li><a href="#collection">Information We Collect</a></li>
                    <li><a href="#use">How We Use It</a></li>
                    <li><a href="#sharing">Sharing</a></li>
                    <li><a href="#security">Security</a></li>
                    <li><a href="#cookies">Cookies</a></li>
                    <li><a href="#rights">Your Rights</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </nav>

            <!-- Main content -->
            <div class="legal-content">

                <div class="legal-intro">
                    <p>
                        GymHub ("we", "us", or "our") is committed to protecting your personal
                        information. This Privacy Policy explains what data we collect, how we use
                        it, and your rights regarding that data when you use our website and services.
                    </p>
                </div>

                <!-- Section 1 -->
                <div class="legal-section" id="collection">
                    <h2>1. Information We Collect</h2>
                    <p>We collect the following types of personal information when you use GymHub:</p>
                    <ul class="legal-list">
                        <li><strong>Account information:</strong> First name, last name, email address, and phone number provided during registration.</li>
                        <li><strong>Booking data:</strong> Class bookings, session dates, option choices, and booking history.</li>
                        <li><strong>Progress data:</strong> Weight log entries and fitness notes you voluntarily enter in the Progress Tracker.</li>
                        <li><strong>Communications:</strong> Questions submitted via Ask a Trainer, including any file attachments.</li>
                        <li><strong>Ratings and reviews:</strong> Star ratings and written reviews you submit for classes.</li>
                        <li><strong>Technical data:</strong> IP address, browser type, and pages visited (standard server logs).</li>
                    </ul>
                </div>

                <!-- Section 2 -->
                <div class="legal-section" id="use">
                    <h2>2. How We Use Your Information</h2>
                    <p>We use the information collected to:</p>
                    <ul class="legal-list">
                        <li>Create and manage your GymHub account</li>
                        <li>Process and confirm class bookings</li>
                        <li>Allow instructors to respond to your questions</li>
                        <li>Display your fitness progress charts</li>
                        <li>Send booking confirmations and reminders</li>
                        <li>Improve our website and services</li>
                        <li>Comply with legal obligations</li>
                    </ul>
                </div>

                <!-- Section 3 -->
                <div class="legal-section" id="sharing">
                    <h2>3. Sharing Your Information</h2>
                    <p>
                        We do not sell, rent, or trade your personal information to third parties.
                        Your data may be shared only in the following limited circumstances:
                    </p>
                    <ul class="legal-list">
                        <li><strong>GymHub instructors</strong> — to respond to your trainer questions</li>
                        <li><strong>Legal requirements</strong> — if required by law or to protect our rights</li>
                        <li><strong>Service providers</strong> — hosting and technical partners who are bound by confidentiality agreements</li>
                    </ul>
                </div>

                <!-- Section 4 -->
                <div class="legal-section" id="security">
                    <h2>4. Data Security</h2>
                    <p>
                        We take reasonable technical and organisational measures to protect your
                        personal information. Passwords are hashed using bcrypt before storage —
                        we never store plain-text passwords. Our database is protected by access
                        controls and is not publicly accessible.
                    </p>
                    <p>
                        However, no method of transmission over the internet is 100% secure. We
                        encourage you to use a strong, unique password for your GymHub account.
                    </p>
                </div>

                <!-- Section 5 -->
                <div class="legal-section" id="cookies">
                    <h2>5. Cookies and Sessions</h2>
                    <p>
                        GymHub uses PHP session cookies to keep you logged in while you browse
                        the site. These cookies are temporary — they expire when you close your
                        browser or log out. We do not use advertising or tracking cookies.
                    </p>
                </div>

                <!-- Section 6 -->
                <div class="legal-section" id="rights">
                    <h2>6. Your Rights</h2>
                    <p>You have the right to:</p>
                    <ul class="legal-list">
                        <li>Access the personal data we hold about you</li>
                        <li>Correct inaccurate data (via your Profile page)</li>
                        <li>Request deletion of your account and data</li>
                        <li>Withdraw consent for data processing at any time</li>
                    </ul>
                    <p>To exercise any of these rights, please contact us using the details below.</p>
                </div>

                <!-- Section 7 -->
                <div class="legal-section" id="contact">
                    <h2>7. Contact Us</h2>
                    <p>
                        If you have any questions about this Privacy Policy or how we handle your
                        data, please contact us:
                    </p>
                    <ul class="legal-list">
                        <li>Email: <a href="mailto:privacy@gymhub.com">privacy@gymhub.com</a></li>
                        <li>Address: 123 King St W, Windsor, ON N9A 5K6</li>
                        <li>Phone: (519) 955-0100</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.legal-layout{display:grid;grid-template-columns:200px 1fr;gap:var(--space-2xl);align-items:start}
.legal-nav{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg);position:sticky;top:90px}
.legal-nav h4{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.legal-nav ul{list-style:none;display:flex;flex-direction:column;gap:.25rem}
.legal-nav a{display:block;padding:.4rem .6rem;color:var(--color-text-muted);font-size:.875rem;border-radius:var(--radius-sm);transition:all var(--transition-fast);text-decoration:none}
.legal-nav a:hover{color:var(--color-accent);background:var(--color-accent-glow)}
.legal-content{display:flex;flex-direction:column;gap:var(--space-xl)}
.legal-intro p{color:var(--color-text-light);font-size:1rem;line-height:1.8;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-lg)}
.legal-section h2{font-size:1.2rem;margin-bottom:var(--space-md);padding-bottom:var(--space-sm);border-bottom:1px solid var(--color-border)}
.legal-section p{color:var(--color-text-light);line-height:1.8;margin-bottom:var(--space-md)}
.legal-list{list-style:disc;padding-left:1.5rem;display:flex;flex-direction:column;gap:.5rem}
.legal-list li{color:var(--color-text-light);font-size:.9rem;line-height:1.7}
.legal-list strong{color:var(--color-text)}
.legal-list a{color:var(--color-accent)}
@media(max-width:768px){.legal-layout{grid-template-columns:1fr}.legal-nav{position:static}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
