<?php
/**
 * GymHub - About Us
 * pages/about.php
 *
 * Static page describing the GymHub business, its mission, values,
 * and key statistics. This is a required page for the assignment.
 *
 * REQUIREMENT 1: This page satisfies the "business case description"
 * requirement — it contains at least one paragraph describing what
 * the project is about and the catalogue being developed (fitness classes).
 *
 * No database queries needed — all content is static HTML.
 */

$page_title       = 'About GymHub | Windsor\'s Premier Fitness Community';
$page_description = 'Learn about GymHub — Windsor Ontario\'s premier fitness community. Our mission, values, instructors, and world-class facilities.';
$page_keywords    = 'about GymHub, gym Windsor Ontario, fitness community, gym mission';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Our Story</span>
        <h1>About GymHub</h1>
        <p>Windsor's premier fitness community — built for real people chasing real results.</p>
    </div>
</section>

<!-- ── Mission statement ── -->
<section class="about-section section-pad">
    <div class="container">
        <div class="about-intro">
            <div class="about-intro-text">
                <span class="section-tag">Who We Are</span>
                <h2>More Than a Gym</h2>
                <!-- REQUIREMENT 1: Business case description paragraph -->
                <p>
                    GymHub is Windsor Ontario's premier fitness class booking platform, offering over
                    20 world-class fitness classes across three convenient locations. We believe that
                    fitness should be accessible, enjoyable, and tailored to every individual —
                    whether you're a complete beginner or a seasoned athlete.
                </p>
                <p>
                    Our platform allows members to browse classes, book sessions online, track their
                    fitness progress, and connect directly with certified instructors. From high-intensity
                    HIIT and CrossFit sessions to calming yoga and pilates, GymHub offers something
                    for every fitness goal and lifestyle.
                </p>
                <p>
                    Founded in Windsor, Ontario, GymHub was built on the belief that access to
                    quality fitness coaching shouldn't require a long-term contract or confusing
                    pricing. Our flexible membership tiers — Basic, Pro, and Elite — give members
                    the freedom to train the way they want, when they want.
                </p>
            </div>
            <!-- Stats on the right side -->
            <div class="about-stats">
                <div class="about-stat">
                    <strong>20+</strong>
                    <span>Fitness Classes</span>
                </div>
                <div class="about-stat">
                    <strong>3</strong>
                    <span>Windsor Locations</span>
                </div>
                <div class="about-stat">
                    <strong>4</strong>
                    <span>Elite Instructors</span>
                </div>
                <div class="about-stat">
                    <strong>3</strong>
                    <span>Membership Tiers</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── Values section ── -->
<section class="values-section section-pad" style="background:var(--color-surface);">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">What We Stand For</span>
            <h2 class="section-title">Our Core Values</h2>
        </div>
        <div class="values-grid">
            <div class="value-card">
                <div class="value-icon">💪</div>
                <h3>Results First</h3>
                <p>Every class, every instructor, and every programme is designed with one goal: getting you real, measurable results.</p>
            </div>
            <div class="value-card">
                <div class="value-icon">🤝</div>
                <h3>Community</h3>
                <p>We're more than a gym — we're a community of people supporting each other through every rep, every set, and every milestone.</p>
            </div>
            <div class="value-card">
                <div class="value-icon">🎓</div>
                <h3>Expert Coaching</h3>
                <p>All GymHub instructors are fully certified professionals with years of real-world coaching experience across multiple disciplines.</p>
            </div>
            <div class="value-card">
                <div class="value-icon">🌱</div>
                <h3>Accessibility</h3>
                <p>Fitness is for everyone. We offer beginner-friendly options in every class and flexible membership plans to suit every budget.</p>
            </div>
        </div>
    </div>
</section>

<!-- ── What we offer ── -->
<section class="offer-section section-pad">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">The Platform</span>
            <h2 class="section-title">Everything You Need in One Place</h2>
        </div>
        <div class="offer-grid">
            <div class="offer-item">
                <span class="offer-icon">📅</span>
                <div>
                    <h4>Online Booking</h4>
                    <p>Browse and book any of our 20+ classes directly from your phone or desktop. No phone calls, no waiting.</p>
                </div>
            </div>
            <div class="offer-item">
                <span class="offer-icon">📈</span>
                <div>
                    <h4>Progress Tracking</h4>
                    <p>Log your workouts and weight daily. Interactive charts show your improvement over weeks and months.</p>
                </div>
            </div>
            <div class="offer-item">
                <span class="offer-icon">💬</span>
                <div>
                    <h4>Ask a Trainer</h4>
                    <p>Got a question? Submit it directly to our certified instructors and get a personalised response within 24 hours.</p>
                </div>
            </div>
            <div class="offer-item">
                <span class="offer-icon">🗺️</span>
                <div>
                    <h4>Three Locations</h4>
                    <p>Downtown, Westside, and Riverside — all equipped with free weights, group studios, and locker rooms.</p>
                </div>
            </div>
            <div class="offer-item">
                <span class="offer-icon">🏆</span>
                <div>
                    <h4>Flexible Membership</h4>
                    <p>Month-to-month plans with no long-term commitment. Upgrade or cancel anytime from your account page.</p>
                </div>
            </div>
            <div class="offer-item">
                <span class="offer-icon">⭐</span>
                <div>
                    <h4>Class Reviews</h4>
                    <p>Every class can be rated by members after attending. Honest reviews help the whole community make better choices.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ── CTA ── -->
<section class="cta-banner">
    <div class="container">
        <div class="cta-content">
            <h2>Ready to Join the GymHub Community?</h2>
            <p>Create your free account and book your first class today.</p>
            <div class="cta-actions">
                <a href="register.php" class="btn btn-primary btn-lg">Get Started Free</a>
                <a href="classes.php"  class="btn btn-outline btn-lg">Browse Classes</a>
            </div>
        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}

/* Intro: text left, stats grid right */
.about-intro{display:grid;grid-template-columns:1fr 280px;gap:var(--space-2xl);align-items:start}
.about-intro-text{display:flex;flex-direction:column;gap:var(--space-lg)}
.about-intro-text p{color:var(--color-text-light);line-height:1.8}

/* Stats grid */
.about-stats{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-md)}
.about-stat{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg);text-align:center}
.about-stat strong{display:block;font-family:var(--font-display);font-size:2rem;font-weight:900;color:var(--color-accent);line-height:1}
.about-stat span{font-size:.78rem;color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.06em}

/* Values grid */
.values-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:var(--space-lg)}
.value-card{background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl);display:flex;flex-direction:column;gap:var(--space-sm)}
.value-icon{font-size:2rem}
.value-card h3{font-size:1.05rem}
.value-card p{color:var(--color-text-muted);font-size:.9rem;line-height:1.6}

/* What we offer list */
.offer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:var(--space-lg)}
.offer-item{display:flex;gap:var(--space-md);align-items:flex-start}
.offer-icon{font-size:1.8rem;flex-shrink:0;margin-top:.2rem}
.offer-item h4{font-size:1rem;margin-bottom:.3rem}
.offer-item p{color:var(--color-text-muted);font-size:.875rem;line-height:1.6;margin:0}

@media(max-width:768px){.about-intro{grid-template-columns:1fr}.about-stats{grid-template-columns:repeat(2,1fr)}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
