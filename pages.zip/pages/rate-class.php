<?php
/**
 * GymHub - Rate a Class
 * pages/rate-class.php
 *
 * Allows logged-in members to submit a star rating (1-5) and optional
 * written review for any fitness class.
 *
 * DYNAMIC FORM #2 REQUIREMENT: This interactive star rating input
 * satisfies the second dynamic HTML form requirement. Stars respond
 * to hover (highlight) and click (lock in selection) using JavaScript.
 * The actual rating value is stored in a hidden <input> field that
 * gets submitted with the form.
 *
 * UPSERT logic: the ratings table has a UNIQUE KEY on (user_id, class_id)
 * so each member can only have one rating per class. If they already
 * rated a class, submitting the form UPDATES their existing rating
 * instead of inserting a duplicate.
 *
 * The class ID can be pre-selected via URL: rate-class.php?id=5
 */

$page_title       = 'Rate a Class | GymHub';
$page_description = 'Leave a star rating and review for GymHub fitness classes. Help other members find the best classes.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';

// Redirect guests to login
if (!is_logged_in()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/rate-class.php'));
}

$user_id = $_SESSION['user_id'];
$success = '';
$errors  = [];

// ── Load all active classes for the dropdown selector ─────────────────────────
$all_classes = $pdo->query("
    SELECT id, title, category FROM classes WHERE status = 'active' ORDER BY title ASC
")->fetchAll();

// ── Pre-select class from URL if ?id= was passed ──────────────────────────────
// This happens when clicking "Rate" from the My Bookings page
$selected_class_id = (int)($_GET['id'] ?? 0);

// ── Load the user's existing rating for the selected class ───────────────────
// UNIQUE KEY on user_id + class_id means only one rating per class is allowed
$existing_rating = null;
if ($selected_class_id) {
    $stmt = $pdo->prepare("SELECT * FROM ratings WHERE user_id = ? AND class_id = ?");
    $stmt->execute([$user_id, $selected_class_id]);
    $existing_rating = $stmt->fetch(); // null if not yet rated
}

// ── Handle rating form submission ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_rating'])) {

    // Cast class ID to int to prevent injection
    $rate_class_id = (int)($_POST['class_id'] ?? 0);
    $stars         = (int)($_POST['stars']    ?? 0);
    $comment       = trim($_POST['comment']   ?? '');

    // Validate inputs
    if (!$rate_class_id)           $errors[] = 'Please select a class.';
    if ($stars < 1 || $stars > 5) $errors[] = 'Please select a star rating between 1 and 5.';

    if (empty($errors)) {
        // Check if user already rated this class — UPDATE or INSERT accordingly
        // (database has UNIQUE KEY on user_id + class_id to enforce one rating per class)
        $check = $pdo->prepare("SELECT id FROM ratings WHERE user_id = ? AND class_id = ?");
        $check->execute([$user_id, $rate_class_id]);

        if ($check->fetch()) {
            // Existing rating found — update it
            $pdo->prepare("
                UPDATE ratings SET stars = ?, comment = ? WHERE user_id = ? AND class_id = ?
            ")->execute([$stars, $comment ?: null, $user_id, $rate_class_id]);
            $success = 'Your rating has been updated! Thank you for your feedback.';
        } else {
            // No existing rating — insert a new one
            $pdo->prepare("
                INSERT INTO ratings (user_id, class_id, stars, comment) VALUES (?, ?, ?, ?)
            ")->execute([$user_id, $rate_class_id, $stars, $comment ?: null]);
            $success = 'Rating submitted! Thank you for your feedback.';
        }

        // Reload the existing rating so the form shows the saved values
        $stmt = $pdo->prepare("SELECT * FROM ratings WHERE user_id = ? AND class_id = ?");
        $stmt->execute([$user_id, $rate_class_id]);
        $existing_rating   = $stmt->fetch();
        $selected_class_id = $rate_class_id;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Share Your Experience</span>
        <h1>Rate a Class</h1>
        <p>Your feedback helps other members find the best classes at GymHub.</p>
    </div>
</section>

<section class="rate-page section-pad">
    <div class="container">
        <div class="rate-grid">

            <!-- ── Rating form ── -->
            <div class="rate-form-card">
                <h3><?= $existing_rating ? 'Update Your Rating' : 'Leave a Rating' ?></h3>

                <!-- Feedback messages -->
                <?php if ($success): ?>
                <div class="alert alert-success flash-message"><?= h($success) ?></div>
                <?php endif; ?>
                <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
                </div>
                <?php endif; ?>

                <form method="POST" action="" class="rate-form">

                    <!-- Class selector dropdown -->
                    <div class="form-group">
                        <label for="class_id">Select Class *</label>
                        <select id="class_id" name="class_id" required
                                onchange="loadExistingRating(this.value)">
                            <option value="">-- Choose a class --</option>
                            <?php foreach ($all_classes as $c): ?>
                            <option value="<?= $c['id'] ?>"
                                    <?= $c['id'] == $selected_class_id ? 'selected' : '' ?>>
                                <?= h($c['category']) ?> — <?= h($c['title']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- ── Star rating input (DYNAMIC FORM #2) ── -->
                    <!-- Stars respond to hover and click via JavaScript below.
                         The actual value is stored in the hidden input #stars-value
                         which gets submitted with the form. -->
                    <div class="form-group">
                        <label>Your Rating *</label>
                        <!-- Hidden input stores the selected star count for form submission -->
                        <input type="hidden" id="stars-value" name="stars"
                               value="<?= $existing_rating ? $existing_rating['stars'] : '0' ?>">
                        <div class="star-rating-input"
                             data-selected="<?= $existing_rating ? $existing_rating['stars'] : '0' ?>">
                            <!-- Five star buttons — JavaScript controls their appearance -->
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="star-btn"
                                    data-value="<?= $i ?>"
                                    aria-label="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>">
                                <!-- Show filled star if within existing rating, empty otherwise -->
                                <?= ($existing_rating && $i <= $existing_rating['stars']) ? '⭐' : '☆' ?>
                            </button>
                            <?php endfor; ?>
                            <span class="star-label" id="star-label">
                                <?= $existing_rating ? ['','Terrible','Poor','OK','Good','Excellent'][$existing_rating['stars']] : 'Click to rate' ?>
                            </span>
                        </div>
                    </div>

                    <!-- Optional written review -->
                    <div class="form-group">
                        <label for="comment">Written Review <span class="optional">(optional)</span></label>
                        <textarea id="comment" name="comment" rows="4"
                                  placeholder="Tell us about your experience with this class..."><?= h($existing_rating['comment'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" name="submit_rating" class="btn btn-primary">
                        <?= $existing_rating ? 'Update Rating' : 'Submit Rating' ?>
                    </button>
                </form>
            </div>

            <!-- ── Info sidebar ── -->
            <aside class="rate-sidebar">
                <div class="sidebar-card">
                    <h4>Rating Guide</h4>
                    <ul class="rating-guide">
                        <li><span class="stars-preview">⭐⭐⭐⭐⭐</span> Excellent — exceeded expectations</li>
                        <li><span class="stars-preview">⭐⭐⭐⭐</span> Good — really enjoyed it</li>
                        <li><span class="stars-preview">⭐⭐⭐</span> OK — decent but room to improve</li>
                        <li><span class="stars-preview">⭐⭐</span> Poor — wasn't what I expected</li>
                        <li><span class="stars-preview">⭐</span> Terrible — very disappointing</li>
                    </ul>
                </div>
                <div class="sidebar-card">
                    <h4>Tips for a Helpful Review</h4>
                    <ul class="tips-list">
                        <li>Mention the instructor by name</li>
                        <li>Describe the difficulty level</li>
                        <li>Note anything that stood out</li>
                        <li>Be specific and constructive</li>
                    </ul>
                </div>
                <div class="sidebar-card">
                    <h4>More Options</h4>
                    <ul class="quick-links">
                        <li><a href="bookings.php">📅 My Bookings</a></li>
                        <li><a href="classes.php">🏋️ All Classes</a></li>
                        <li><a href="ask-trainer.php">💬 Ask a Trainer</a></li>
                    </ul>
                </div>
            </aside>

        </div>
    </div>
</section>

<script>
// ── Star rating JavaScript ─────────────────────────────────────────────────────
// Makes the star buttons interactive. Hovering highlights stars up to the
// hovered position. Clicking locks in that rating and saves it to the hidden input.

// Descriptive labels for each star count
const labels = ['', 'Terrible', 'Poor', 'OK', 'Good', 'Excellent'];

// Track which star was last clicked (starts with existing rating or 0)
let selected = parseInt(document.getElementById('stars-value').value) || 0;

document.querySelectorAll('.star-btn').forEach(btn => {
    const value = parseInt(btn.dataset.value);

    // Hover: highlight all stars up to hovered position
    btn.addEventListener('mouseover', () => {
        highlightStars(value);
        document.getElementById('star-label').textContent = labels[value];
    });

    // Mouse leave: reset display to the currently selected (clicked) rating
    btn.addEventListener('mouseout', () => {
        highlightStars(selected);
        document.getElementById('star-label').textContent = selected ? labels[selected] : 'Click to rate';
    });

    // Click: lock in this rating and store in hidden input for form submission
    btn.addEventListener('click', () => {
        selected = value;
        document.getElementById('stars-value').value = value; // update hidden form field
        highlightStars(value);
        document.getElementById('star-label').textContent = labels[value];
    });
});

/**
 * highlightStars(upTo) — Fills stars 1 through upTo with ⭐, empties the rest
 * @param {number} upTo - Number of filled stars to show (0-5)
 */
function highlightStars(upTo) {
    document.querySelectorAll('.star-btn').forEach(btn => {
        btn.textContent = parseInt(btn.dataset.value) <= upTo ? '⭐' : '☆';
    });
}

/**
 * loadExistingRating(classId) — Refreshes the page with the new class ID
 * so PHP can load any existing rating for that class into the form.
 * Called when the user changes the class selector dropdown.
 */
function loadExistingRating(classId) {
    if (classId) {
        window.location.href = 'rate-class.php?id=' + classId;
    }
}
</script>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.rate-grid{display:grid;grid-template-columns:1fr 280px;gap:var(--space-xl);align-items:start}
.rate-form-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.rate-form-card h3{margin-bottom:var(--space-lg)}
.rate-form{display:flex;flex-direction:column;gap:var(--space-lg)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group select,.form-group textarea{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.9rem;outline:none;width:100%;transition:border-color var(--transition-fast)}
.form-group select:focus,.form-group textarea:focus{border-color:var(--color-accent)}
.form-group textarea{resize:vertical}
.optional{color:var(--color-text-muted);font-size:.78rem;font-weight:400}

/* Star rating widget */
.star-rating-input{display:flex;align-items:center;gap:.25rem}
.star-btn{background:none;border:none;font-size:2rem;cursor:pointer;padding:.1rem;transition:transform var(--transition-fast);line-height:1}
.star-btn:hover{transform:scale(1.15)}
.star-label{margin-left:var(--space-sm);color:var(--color-text-muted);font-size:.9rem}

/* Sidebar */
.rate-sidebar{display:flex;flex-direction:column;gap:var(--space-md);position:sticky;top:90px}
.sidebar-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg)}
.sidebar-card h4{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.rating-guide{list-style:none;display:flex;flex-direction:column;gap:.5rem}
.rating-guide li{font-size:.85rem;color:var(--color-text-light);display:flex;flex-direction:column;gap:.1rem}
.stars-preview{font-size:.8rem}
.tips-list{list-style:disc;padding-left:1.2rem;display:flex;flex-direction:column;gap:.4rem}
.tips-list li{color:var(--color-text-muted);font-size:.85rem}
.quick-links{display:flex;flex-direction:column;gap:.4rem}
.quick-links a{color:var(--color-text-muted);font-size:.875rem;padding:.3rem 0;display:block;transition:color var(--transition-fast)}
.quick-links a:hover{color:var(--color-accent)}

.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-md)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}
.alert ul{padding-left:1.2rem;margin-top:.4rem}

@media(max-width:900px){.rate-grid{grid-template-columns:1fr}.rate-sidebar{position:static}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
