<?php
/**
 * GymHub - Membership Plans
 * pages/membership.php
 *
 * Shows the three membership tiers (Basic, Pro, Elite) with features
 * and prices loaded from the database. Includes the quote calculator.
 *
 * DYNAMIC FORM #1 REQUIREMENT: The quote calculator on this page
 * satisfies the "dynamic HTML form" requirement. Users select their
 * workout preferences (frequency, types, locations) and JavaScript
 * calculates a recommended plan and estimated monthly cost in real time
 * — without any page reload.
 *
 * Logged-in members can activate a membership plan via a POST form.
 * The selected plan is saved to the user_memberships table.
 * Any existing active membership is deleted first so only one plan
 * is active per user at a time.
 */

$page_title       = 'Membership Plans | GymHub';
$page_description = 'Choose the perfect GymHub membership plan. Basic, Pro, and Elite tiers with flexible month-to-month pricing and no long-term contracts.';
$page_keywords    = 'gym membership Windsor, fitness membership plans, monthly gym membership';
$active_nav       = 'membership';

// Context-sensitive help link for new members
$help_link = 'getting-started.php';
$help_text = 'New member? Read the Getting Started guide';

require_once __DIR__ . '/../config/db.php';

$success = '';
$error   = '';

// ── Handle membership plan activation ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_plan'])) {

    // Must be logged in to activate a plan
    if (!is_logged_in()) {
        redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/membership.php'));
    }

    // Cast to int to prevent SQL injection via the hidden form field
    $membership_id = (int)($_POST['membership_id'] ?? 0);

    // Verify the selected membership ID actually exists in the database
    $stmt = $pdo->prepare("SELECT * FROM memberships WHERE id = ? AND status = 'active'");
    $stmt->execute([$membership_id]);
    $plan = $stmt->fetch();

    if ($plan) {
        // Remove any existing active membership before adding the new one
        // (only one active plan per user is allowed at a time)
        $pdo->prepare("DELETE FROM user_memberships WHERE user_id = ?")
            ->execute([$_SESSION['user_id']]);

        // Calculate start and end dates — plans last 30 days (one month)
        $start = date('Y-m-d');
        $end   = date('Y-m-d', strtotime('+' . $plan['duration'] . ' days'));

        // Insert the new membership record linking user to plan with dates
        $pdo->prepare("
            INSERT INTO user_memberships (user_id, membership_id, start_date, end_date)
            VALUES (?, ?, ?, ?)
        ")->execute([$_SESSION['user_id'], $membership_id, $start, $end]);

        $success = "You're now on the {$plan['name']} plan! Enjoy your membership.";
    } else {
        $error = 'Invalid membership plan selected.';
    }
}

// ── Load all active membership plans ─────────────────────────────────────────
// Ordered cheapest first so they display as Basic → Pro → Elite
$memberships = $pdo->query("
    SELECT * FROM memberships WHERE status = 'active' ORDER BY price ASC
")->fetchAll();

// ── Check if the logged-in user already has an active membership ──────────────
$current_membership = null;
if (is_logged_in()) {
    $stmt = $pdo->prepare("
        SELECT um.*, m.name
        FROM user_memberships um
        JOIN memberships m ON um.membership_id = m.id
        WHERE um.user_id = ? AND um.end_date >= CURDATE()
        ORDER BY um.end_date DESC LIMIT 1
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $current_membership = $stmt->fetch(); // null if no active plan
}

// Emoji icons used for each tier in the cards
$tier_icons = ['Basic' => '🥉', 'Pro' => '🥈', 'Elite' => '🥇'];

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Choose Your Plan</span>
        <h1>Membership Plans</h1>
        <p>Month-to-month flexibility. No long-term contracts. Cancel anytime.</p>
    </div>
</section>

<section class="membership-page section-pad">
    <div class="container">

        <!-- Success/error feedback from plan activation -->
        <?php if ($success): ?>
        <div class="alert alert-success flash-message"><?= h($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>

        <!-- Show current plan banner if member already has one -->
        <?php if ($current_membership): ?>
        <div class="current-plan-banner">
            <span>✅ You are currently on the <strong><?= h($current_membership['name']) ?></strong> plan
            — expires <?= date('M j, Y', strtotime($current_membership['end_date'])) ?></span>
            <a href="profile.php" class="btn btn-secondary btn-sm">Manage in Profile →</a>
        </div>
        <?php endif; ?>

        <!-- ── Membership plan cards ── -->
        <div class="membership-grid">
            <?php foreach ($memberships as $i => $plan):
                // Decode the JSON features array stored in the database
                // e.g. '["Group class access","Locker rooms"]' → PHP array
                $features  = json_decode($plan['features'], true) ?? [];

                // The middle card (index 1 = Pro) gets the "popular" highlight styling
                $is_popular = ($i === 1);

                // Check if this is the user's current active plan
                $is_current = $current_membership && $current_membership['name'] === $plan['name'];
            ?>
            <div class="membership-card <?= $is_popular ? 'membership-card--popular' : '' ?>">

                <!-- "Most Popular" badge only on the middle Pro card -->
                <?php if ($is_popular): ?>
                <div class="popular-badge">Most Popular</div>
                <?php endif; ?>

                <!-- Tier emoji icon -->
                <div class="membership-icon"><?= $tier_icons[$plan['name']] ?? '⭐' ?></div>
                <h3 class="membership-name"><?= h($plan['name']) ?></h3>

                <!-- Price display -->
                <div class="membership-price">
                    <span class="price-amount">$<?= number_format($plan['price'], 2) ?></span>
                    <span class="price-period">/month</span>
                </div>

                <!-- Features list decoded from JSON -->
                <ul class="membership-features">
                    <?php foreach ($features as $feature): ?>
                    <li>✓ <?= h($feature) ?></li>
                    <?php endforeach; ?>
                </ul>

                <!-- Action button: activate plan or show current badge -->
                <?php if ($is_current): ?>
                <span class="btn btn-secondary" style="opacity:.6;cursor:default;">
                    ✅ Current Plan
                </span>

                <?php elseif (is_logged_in()): ?>
                <!-- POST form activates this plan for the logged-in user -->
                <form method="POST" action="">
                    <input type="hidden" name="select_plan"   value="1">
                    <input type="hidden" name="membership_id" value="<?= $plan['id'] ?>">
                    <button type="submit"
                            class="btn <?= $is_popular ? 'btn-primary' : 'btn-secondary' ?> btn-full">
                        Get <?= h($plan['name']) ?> Plan
                    </button>
                </form>

                <?php else: ?>
                <!-- Guest prompt — must register/login to activate -->
                <a href="register.php" class="btn <?= $is_popular ? 'btn-primary' : 'btn-secondary' ?> btn-full">
                    Get Started Free
                </a>
                <?php endif; ?>

            </div>
            <?php endforeach; ?>
        </div>

        <!-- ══════════════════════════════════════════════════════════
             DYNAMIC FORM #1 — Membership Quote Calculator
             Users answer questions about their workout preferences.
             JavaScript scores the answers and recommends a plan
             with a calculated monthly price — no page reload needed.
             ══════════════════════════════════════════════════════════ -->
        <div class="quote-calculator">
            <div class="quote-header">
                <span class="section-tag">Interactive Tool</span>
                <h2>Not Sure Which Plan? Get a Quote</h2>
                <p>Answer a few questions and we'll recommend the best plan for you.</p>
            </div>

            <div class="quote-form-card">
                <form id="quote-form" class="quote-form">

                    <!-- Question 1: how often do you train? -->
                    <div class="quote-field">
                        <label>How many times per week do you plan to train?</label>
                        <div class="option-buttons" data-field="frequency">
                            <button type="button" class="opt-btn" data-value="1-2">1–2 times</button>
                            <button type="button" class="opt-btn" data-value="3-4">3–4 times</button>
                            <button type="button" class="opt-btn" data-value="5+">5+ times</button>
                        </div>
                    </div>

                    <!-- Question 2: what types of classes? -->
                    <div class="quote-field">
                        <label>What types of classes interest you? (select all that apply)</label>
                        <div class="option-buttons" data-field="types">
                            <button type="button" class="opt-btn" data-value="cardio">Cardio / HIIT</button>
                            <button type="button" class="opt-btn" data-value="strength">Strength</button>
                            <button type="button" class="opt-btn" data-value="yoga">Yoga / Wellness</button>
                            <button type="button" class="opt-btn" data-value="combat">Combat Sports</button>
                        </div>
                    </div>

                    <!-- Question 3: how many locations? -->
                    <div class="quote-field">
                        <label>How many GymHub locations would you like to access?</label>
                        <div class="option-buttons" data-field="locations">
                            <button type="button" class="opt-btn" data-value="one">Just one</button>
                            <button type="button" class="opt-btn" data-value="multiple">Multiple</button>
                        </div>
                    </div>

                    <!-- Question 4: billing preference -->
                    <div class="quote-field">
                        <label>Billing preference?</label>
                        <div class="option-buttons" data-field="commitment">
                            <button type="button" class="opt-btn" data-value="monthly">Monthly</button>
                            <button type="button" class="opt-btn" data-value="annual">Annual (save 15%)</button>
                        </div>
                    </div>

                    <button type="button" id="calc-btn" class="btn btn-primary"
                            onclick="calculateQuote()">
                        Calculate My Quote
                    </button>
                </form>

                <!-- Result panel — hidden until Calculate is clicked -->
                <div id="quote-result" class="quote-result" hidden>
                    <div class="result-icon">💪</div>
                    <h3 id="result-plan"></h3>
                    <div id="result-price" class="result-price"></div>
                    <p id="result-desc"></p>
                    <a href="register.php" class="btn btn-primary">Get Started →</a>
                </div>
            </div>
        </div>

    </div>
</section>

<script>
/**
 * calculateQuote() — Reads form selections and recommends a membership plan.
 * DYNAMIC FORM #1: This JavaScript runs when the Calculate button is clicked.
 * No page reload — the result appears instantly below the form.
 */
function calculateQuote() {
    // Collect selected values from each option-buttons group
    const freq       = document.querySelector('[data-field="frequency"] .opt-btn--active')?.dataset.value;
    const locs       = document.querySelector('[data-field="locations"] .opt-btn--active')?.dataset.value;
    const commitment = document.querySelector('[data-field="commitment"] .opt-btn--active')?.dataset.value;
    const types      = document.querySelectorAll('[data-field="types"] .opt-btn--active').length;

    // Require all fields to be filled before calculating
    if (!freq || !locs || !commitment) {
        alert('Please answer all the questions before calculating your quote.');
        return;
    }

    // Score accumulates based on usage patterns.
    // Higher score = more features needed = higher tier recommended.
    let score = 0;
    if (freq === '3-4') score += 2;
    if (freq === '5+')  score += 4;
    if (locs === 'multiple') score += 3;
    if (types >= 3)     score += 2;

    // Convert score to a plan recommendation with base monthly prices
    let recommended, basePrice, description;
    if (score <= 2) {
        recommended = 'Basic';
        basePrice   = 29.99;
        description = 'Perfect for getting started with group classes at one location.';
    } else if (score <= 5) {
        recommended = 'Pro';
        basePrice   = 59.99;
        description = 'Ideal for regular training across multiple class types and locations.';
    } else {
        recommended = 'Elite';
        basePrice   = 99.99;
        description = 'For serious athletes who train frequently and want all the perks.';
    }

    // Apply 15% discount for annual billing
    if (commitment === 'annual') basePrice = Math.round(basePrice * 0.85 * 100) / 100;

    // Show the result panel with calculated values
    document.getElementById('result-plan').textContent  = recommended + ' Plan Recommended';
    document.getElementById('result-price').textContent = '$' + basePrice.toFixed(2) + '/month' + (commitment === 'annual' ? ' (annual billing, 15% off)' : '');
    document.getElementById('result-desc').textContent  = description;
    document.getElementById('quote-result').hidden       = false;

    // Scroll smoothly to the result
    document.getElementById('quote-result').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ── Option button toggle behaviour ───────────────────────────────────────────
// Makes buttons in each group behave like radio buttons (single select)
// except for the "types" group which allows multiple selections
document.querySelectorAll('.option-buttons').forEach(group => {
    const field       = group.dataset.field;
    const isMultiSelect = field === 'types'; // types group allows multiple

    group.querySelectorAll('.opt-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!isMultiSelect) {
                // Single select: deactivate all siblings first
                group.querySelectorAll('.opt-btn').forEach(b => b.classList.remove('opt-btn--active'));
            }
            // Toggle this button's active state
            btn.classList.toggle('opt-btn--active');
        });
    });
});
</script>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}

/* Current plan banner */
.current-plan-banner{background:rgba(34,197,94,.08);border:1px solid var(--color-success);border-radius:var(--radius-md);padding:var(--space-md) var(--space-lg);display:flex;align-items:center;justify-content:space-between;gap:var(--space-md);margin-bottom:var(--space-xl);flex-wrap:wrap;font-size:.9rem;color:var(--color-text-light)}

/* Three-column plan cards */
.membership-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--space-lg);margin-bottom:var(--space-3xl)}
.membership-card{background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl);position:relative;transition:all var(--transition-normal);text-align:center;display:flex;flex-direction:column;gap:var(--space-md)}
.membership-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-lg)}
.membership-card--popular{border-color:var(--color-accent);box-shadow:var(--shadow-accent);transform:scale(1.03)}
.popular-badge{position:absolute;top:-.75rem;left:50%;transform:translateX(-50%);background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:.2rem .8rem;border-radius:var(--radius-full);white-space:nowrap}
.membership-icon{font-size:2.5rem}
.membership-name{font-size:1.4rem;margin:0}
.membership-price{display:flex;align-items:baseline;justify-content:center;gap:.25rem}
.price-amount{font-family:var(--font-display);font-size:2.5rem;font-weight:900;color:var(--color-accent)}
.price-period{color:var(--color-text-muted);font-size:.9rem}
.membership-features{text-align:left;list-style:none;display:flex;flex-direction:column;gap:var(--space-sm);flex:1}
.membership-features li{color:var(--color-text-light);font-size:.9rem}
.btn-full{width:100%;justify-content:center;margin-top:auto}

/* Quote calculator */
.quote-calculator{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-2xl)}
.quote-header{text-align:center;margin-bottom:var(--space-2xl)}
.quote-header h2{margin:var(--space-sm) 0}
.quote-header p{color:var(--color-text-muted)}
.quote-form-card{max-width:700px;margin:0 auto}
.quote-form{display:flex;flex-direction:column;gap:var(--space-xl)}
.quote-field label{display:block;font-weight:600;color:var(--color-text);margin-bottom:var(--space-md)}
.option-buttons{display:flex;gap:var(--space-sm);flex-wrap:wrap}
.opt-btn{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text-muted);font-family:var(--font-body);font-size:.9rem;padding:.55rem 1.1rem;border-radius:var(--radius-sm);cursor:pointer;transition:all var(--transition-fast)}
.opt-btn:hover{border-color:var(--color-accent);color:var(--color-accent)}
.opt-btn--active{background:var(--color-accent);border-color:var(--color-accent);color:#000;font-weight:600}
.quote-result{background:var(--color-surface-2);border:1px solid var(--color-accent);border-radius:var(--radius-lg);padding:var(--space-xl);margin-top:var(--space-xl);text-align:center;display:flex;flex-direction:column;align-items:center;gap:var(--space-md)}
.result-icon{font-size:2.5rem}
.quote-result h3{font-size:1.4rem;margin:0}
.result-price{font-family:var(--font-display);font-size:1.8rem;font-weight:900;color:var(--color-accent)}
.quote-result p{color:var(--color-text-muted);font-size:.9rem;margin:0}

.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-xl)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}

@media(max-width:900px){.membership-grid{grid-template-columns:1fr}.membership-card--popular{transform:scale(1)}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
