<?php
/**
 * GymHub - Frequently Asked Questions
 * pages/faq.php
 *
 * A comprehensive FAQ page covering membership, booking, facilities,
 * account management, and instructor questions. Uses expandable
 * accordion items (click to reveal answers) implemented with
 * plain JavaScript — no library needed.
 *
 * Questions are defined as a PHP array grouped by category.
 * To add a new question, simply add to the $faqs array below.
 * No database changes needed.
 */

$page_title       = 'Frequently Asked Questions | GymHub';
$page_description = 'Find answers to the most common questions about GymHub classes, membership, booking, and facilities.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';

// Questions are stored as a PHP array — easy to add new ones without touching the DB
$faqs = [
    'Membership' => [
        ['Can I cancel my membership anytime?', 'Yes — all GymHub memberships are month-to-month with no long-term commitment. Cancel before your next billing date and you won\'t be charged again.'],
        ['Can I upgrade or downgrade my plan?', 'Absolutely. You can change your plan at any time from the Membership page. Your new plan takes effect immediately.'],
        ['Is there a free trial?', 'New members can attend one free class before committing to a membership. Simply register an account and book any available class.'],
        ['What\'s included in each membership?', 'Basic includes group class access and locker rooms. Pro adds unlimited bookings and multi-location access. Elite adds personal training, nutrition consultation, and priority booking.'],
    ],
    'Classes & Booking' => [
        ['How do I book a class?', 'Browse to Classes, click any class, choose your option and session time in the booking panel, then click Confirm Booking. You must be logged in to book.'],
        ['Can I cancel a booking?', 'Yes — free cancellation up to 24 hours before the class. Go to My Bookings and click Cancel Booking. Cancellations within 24 hours cannot be refunded.'],
        ['What happens if a class is full?', 'Sessions showing 0 spots remaining cannot be booked. Check the Schedule page for other available times for the same class.'],
        ['What are class options?', 'Each class offers two format choices — for example Beginner or Advanced, Morning or Evening. You select your preferred option when booking.'],
    ],
    'Facilities' => [
        ['Where are GymHub locations?', 'We have three locations in Windsor: Downtown (123 King St W), Westside (456 Tecumseh Rd W), and Riverside (789 Riverside Dr E). See the Locations page for hours and directions.'],
        ['What facilities are available?', 'All locations include free weights, group studios, locker rooms with showers, a combat zone, and free Wi-Fi. Select locations have pool access.'],
        ['Is parking available?', 'Yes — free parking is available at all three GymHub locations.'],
    ],
    'Account & Technical' => [
        ['How do I reset my password?', 'Log in and go to My Profile. Use the Change Password section. You\'ll need to enter your current password first.'],
        ['Can I change my email address?', 'Email addresses cannot be changed once an account is created. Contact us if you need help with your account.'],
        ['How do I track my fitness progress?', 'Visit the Progress Tracker page while logged in. Log your weight and notes daily to see charts update automatically.'],
    ],
    'Instructors & Training' => [
        ['How do I ask an instructor a question?', 'Go to Ask a Trainer while logged in. Submit your question and our certified instructors will respond within 24 hours.'],
        ['How are instructors rated?', 'Members leave star ratings and reviews after attending classes. Instructor ratings are the average of all their class reviews.'],
    ],
];
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Help</span>
        <h1>Frequently Asked Questions</h1>
        <p>Can't find your answer? <a href="contact.php">Contact us</a> or <a href="ask-trainer.php">ask a trainer</a>.</p>
    </div>
</section>

<section class="faq-page section-pad">
    <div class="container">
        <div class="faq-layout">

            <!-- Sidebar: category anchor links -->
            <nav class="faq-nav">
                <h4>Categories</h4>
                <ul>
                    <?php foreach (array_keys($faqs) as $cat): ?>
                    <li>
                        <a href="#<?= h(strtolower(str_replace([' ', '&'], ['-', ''], $cat))) ?>">
                            <?= h($cat) ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <div style="margin-top:var(--space-xl);">
                    <h4>Still need help?</h4>
                    <ul>
                        <li><a href="contact.php">📧 Contact Us</a></li>
                        <li><a href="ask-trainer.php">💬 Ask a Trainer</a></li>
                        <li><a href="<?= SITE_URL ?>/wiki/getting-started.php">📖 Help Wiki</a></li>
                    </ul>
                </div>
            </nav>

            <!-- Main FAQ content — grouped by category -->
            <div class="faq-content">
                <?php foreach ($faqs as $category => $questions):
                    $anchor = strtolower(str_replace([' ', '&'], ['-', ''], $category));
                ?>
                <div class="faq-section" id="<?= h($anchor) ?>">
                    <h2><?= h($category) ?></h2>
                    <div class="faq-list">
                        <?php foreach ($questions as $qa): ?>
                        <div class="faq-item">
                            <!-- Button toggles the answer visibility -->
                            <button class="faq-question" onclick="toggleFaq(this)" aria-expanded="false">
                                <span><?= h($qa[0]) ?></span>
                                <span class="faq-icon">+</span>
                            </button>
                            <!-- Answer hidden by default — JS toggles the hidden attribute -->
                            <div class="faq-answer" hidden>
                                <p><?= h($qa[1]) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
</section>

<script>
/**
 * toggleFaq — Opens or closes a FAQ accordion item
 * @param {HTMLElement} btn - The clicked question button
 */
function toggleFaq(btn) {
    const answer = btn.nextElementSibling;        // the div below the button
    const icon   = btn.querySelector('.faq-icon');
    const isOpen = !answer.hidden;                // true if currently open

    answer.hidden    = isOpen;                    // toggle visibility
    icon.textContent = isOpen ? '+' : '−';        // change icon
    btn.setAttribute('aria-expanded', !isOpen);   // accessibility attribute
}
</script>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.faq-layout{display:grid;grid-template-columns:220px 1fr;gap:var(--space-2xl);align-items:start}
.faq-nav{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg);position:sticky;top:90px}
.faq-nav h4{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.faq-nav ul{list-style:none;display:flex;flex-direction:column;gap:.25rem}
.faq-nav a{display:block;padding:.4rem .6rem;color:var(--color-text-muted);font-size:.875rem;border-radius:var(--radius-sm);transition:all var(--transition-fast);text-decoration:none}
.faq-nav a:hover{color:var(--color-accent);background:var(--color-accent-glow)}
.faq-content{display:flex;flex-direction:column;gap:var(--space-2xl)}
.faq-section h2{font-size:1.3rem;margin-bottom:var(--space-lg);padding-bottom:var(--space-sm);border-bottom:1px solid var(--color-border)}
.faq-list{display:flex;flex-direction:column;gap:var(--space-sm)}
.faq-item{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);overflow:hidden}
.faq-question{width:100%;display:flex;justify-content:space-between;align-items:center;gap:var(--space-md);padding:var(--space-md) var(--space-lg);background:none;border:none;cursor:pointer;text-align:left;color:var(--color-text);font-family:var(--font-body);font-size:.95rem;font-weight:600;transition:background var(--transition-fast)}
.faq-question:hover{background:var(--color-surface-2)}
.faq-question[aria-expanded=true]{background:var(--color-accent-glow);color:var(--color-accent)}
.faq-icon{font-size:1.3rem;flex-shrink:0;color:var(--color-accent);font-weight:300;line-height:1}
.faq-answer{padding:0 var(--space-lg) var(--space-md)}
.faq-answer p{color:var(--color-text-light);font-size:.9rem;line-height:1.7;margin:0}
@media(max-width:768px){.faq-layout{grid-template-columns:1fr}.faq-nav{position:static}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
