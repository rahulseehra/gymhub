<?php
/**
 * GymHub - Workout Media
 * pages/media.php
 *
 * Audio and video media page for workout content.
 *
 * MULTIMEDIA REQUIREMENT: This page satisfies the "3 video/audio files"
 * requirement. It contains:
 *   1. GymHub promo video   → public/assets/videos/gymhub-promo.mp4
 *   2. Workout audio track  → public/assets/videos/workout-track-1.mp3
 *   3. Meditation audio     → public/assets/videos/meditation-audio.mp3
 *
 * All three files use native HTML5 <video> and <audio> elements.
 * No external library is needed — the browser handles playback.
 *
 * To add more audio/video:
 *   1. Upload MP3/MP4 to public/assets/videos/
 *   2. Copy one of the player blocks below and update the filename
 */

$page_title       = 'Workout Audio & Media | GymHub';
$page_description = 'Workout videos, music, and audio tracks from GymHub. Watch our facility tour and listen to curated workout playlists.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Media</span>
        <h1>Workout Audio &amp; Video</h1>
        <p>Watch our facility tour and pump up your training with our curated audio tracks.</p>
    </div>
</section>

<section class="media-page section-pad">
    <div class="container">

        <!-- ── Video section ── -->
        <div class="media-section">
            <h2>🎬 GymHub Videos</h2>
            <p style="color:var(--color-text-muted);margin-bottom:var(--space-xl);">
                Watch our facility tour and class preview videos.
            </p>

            <div class="media-grid">
                <!-- GymHub promo video — File 1 of 3 (satisfies video requirement) -->
                <div class="media-card">
                    <div class="video-thumb">
                        <!-- Native HTML5 video element — browser provides built-in controls.
                             The <source> tag lets the browser pick the right format.
                             Fallback text shown if the browser doesn't support video. -->
                        <video controls width="100%"
                               poster="<?= SITE_URL ?>/public/assets/images/video-thumbnail.jpg">
                            <source src="<?= SITE_URL ?>/public/assets/videos/gymhub-promo.mp4"
                                    type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    </div>
                    <div class="media-card-info">
                        <h3>GymHub Facility Tour</h3>
                        <p>Take a virtual tour of our world-class facilities and see what GymHub has to offer.</p>
                        <span class="media-tag">🎬 Video</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- ── Audio section ── -->
        <div class="media-section">
            <h2>🎵 Workout Audio Tracks</h2>
            <p style="color:var(--color-text-muted);margin-bottom:var(--space-xl);">
                Use these tracks during your workouts. All audio is royalty-free.
            </p>

            <div class="audio-list">

                <!-- Audio track 1 — File 2 of 3 (satisfies first audio requirement)
                     Upload workout-track-1.mp3 to public/assets/videos/ to activate -->
                <div class="audio-card">
                    <div class="audio-icon">🎵</div>
                    <div class="audio-info">
                        <h3>High Energy Workout Mix</h3>
                        <p>Perfect for HIIT, CrossFit, and Boot Camp classes.</p>
                        <!-- Native HTML5 audio player — browser renders the controls.
                             Multiple <source> tags let browser pick ogg or mp3 support. -->
                        <audio controls style="width:100%;margin-top:var(--space-sm);">
                            <source src="<?= SITE_URL ?>/public/assets/videos/workout-track-1.mp3"
                                    type="audio/mpeg">
                            <source src="<?= SITE_URL ?>/public/assets/videos/workout-track-1.ogg"
                                    type="audio/ogg">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                    <span class="media-tag">🎵 Audio</span>
                </div>

                <!-- Audio track 2 — File 3 of 3 (satisfies second audio requirement)
                     Upload meditation-audio.mp3 to public/assets/videos/ to activate -->
                <div class="audio-card">
                    <div class="audio-icon">🧘</div>
                    <div class="audio-info">
                        <h3>Calm Meditation Sounds</h3>
                        <p>Ambient sounds for yoga, pilates, and meditation sessions.</p>
                        <audio controls style="width:100%;margin-top:var(--space-sm);">
                            <source src="<?= SITE_URL ?>/public/assets/videos/meditation-audio.mp3"
                                    type="audio/mpeg">
                            <source src="<?= SITE_URL ?>/public/assets/videos/meditation-audio.ogg"
                                    type="audio/ogg">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                    <span class="media-tag">🎵 Audio</span>
                </div>

            </div>

            <!-- Instructions for adding more audio files -->
            <div class="audio-instructions">
                <h4>📥 How to Add More Audio Tracks</h4>
                <ol>
                    <li>Download free royalty-free music from <a href="https://pixabay.com/music/" target="_blank" rel="noopener">pixabay.com/music</a> or <a href="https://freesound.org" target="_blank" rel="noopener">freesound.org</a></li>
                    <li>Upload the MP3 file to <code>public/assets/videos/</code> on your server</li>
                    <li>Copy one of the audio card blocks above in this file and update the filename</li>
                    <li>Refresh — the new audio player will appear automatically</li>
                </ol>
            </div>
        </div>

        <!-- CTA linking to class booking -->
        <div class="media-cta">
            <h2>Ready to Work Out?</h2>
            <p>Browse our class schedule and book a session today.</p>
            <div style="display:flex;gap:var(--space-md);justify-content:center;flex-wrap:wrap;margin-top:var(--space-xl);">
                <a href="classes.php"  class="btn btn-primary">Browse Classes</a>
                <a href="schedule.php" class="btn btn-secondary">View Schedule</a>
            </div>
        </div>

    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.media-section{margin-bottom:var(--space-3xl)}
.media-section h2{margin-bottom:var(--space-sm)}
.media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:var(--space-lg)}
.media-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;transition:all var(--transition-normal)}
.media-card:hover{border-color:var(--color-accent);transform:translateY(-4px)}
.video-thumb{background:#000}
.media-card-info{padding:var(--space-lg)}
.media-card-info h3{margin-bottom:var(--space-sm);font-size:1.1rem}
.media-card-info p{color:var(--color-text-muted);font-size:.875rem;margin-bottom:var(--space-sm)}
.media-tag{display:inline-block;font-family:var(--font-display);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;background:var(--color-accent-glow);color:var(--color-accent);border:1px solid var(--color-accent);padding:.15rem .5rem;border-radius:var(--radius-full)}
.audio-list{display:flex;flex-direction:column;gap:var(--space-md);margin-bottom:var(--space-xl)}
.audio-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg);display:flex;align-items:flex-start;gap:var(--space-lg)}
.audio-icon{font-size:2.5rem;flex-shrink:0}
.audio-info{flex:1}
.audio-info h3{font-size:1rem;margin-bottom:.25rem}
.audio-info p{color:var(--color-text-muted);font-size:.875rem;margin:0}
audio{accent-color:var(--color-accent)} /* style native audio controls */
.audio-instructions{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.audio-instructions h4{margin-bottom:var(--space-md)}
.audio-instructions ol{padding-left:1.5rem;display:flex;flex-direction:column;gap:.5rem}
.audio-instructions li{color:var(--color-text-light);font-size:.9rem;line-height:1.6}
.audio-instructions code{background:var(--color-surface-2);padding:.1rem .4rem;border-radius:3px;font-size:.85rem;color:var(--color-accent)}
.media-cta{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-2xl);text-align:center}
.media-cta h2{margin-bottom:var(--space-sm)}
.media-cta p{color:var(--color-text-muted)}
@media(max-width:768px){.audio-card{flex-direction:column}.media-grid{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
