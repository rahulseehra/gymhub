<?php
/**
 * GymHub - User Registration
 * pages/register.php
 *
 * Handles new member sign-up with server-side validation,
 * bcrypt password hashing, duplicate email checking,
 * and auto-login after successful registration.
 */

ob_start();
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$page_title       = 'Join GymHub — Create Your Account';
$page_description = 'Sign up for a free GymHub account. Book classes, track your progress, and connect with elite instructors.';
$page_keywords    = 'gym membership sign up, join gym Windsor, create gym account';
$active_nav       = 'register';

require_once __DIR__ . '/../config/db.php';

// Redirect already-logged-in users straight to their profile
if (is_logged_in()) { header('Location: profile.php'); exit; }

$errors = []; // validation error messages keyed by field name
$old    = []; // repopulate form fields if validation fails

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Collect sanitized inputs (trim removes leading/trailing spaces)
    $old = [
        'first_name' => trim($_POST['first_name'] ?? ''),
        'last_name'  => trim($_POST['last_name']  ?? ''),
        'email'      => trim($_POST['email']      ?? ''),
        'phone'      => trim($_POST['phone']      ?? ''),
    ];
    $password  = $_POST['password']  ?? '';
    $password2 = $_POST['password2'] ?? '';

    // Validate each required field
    if (empty($old['first_name'])) $errors['first_name'] = 'First name is required.';
    elseif (strlen($old['first_name']) > 50) $errors['first_name'] = 'First name must be 50 chars or fewer.';

    if (empty($old['last_name'])) $errors['last_name'] = 'Last name is required.';
    elseif (strlen($old['last_name']) > 50) $errors['last_name'] = 'Last name must be 50 chars or fewer.';

    if (empty($old['email'])) {
        $errors['email'] = 'Email address is required.';
    } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Please enter a valid email address.';
    } else {
        // Check for duplicate email — each account must be unique
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$old['email']]);
        if ($stmt->fetch()) $errors['email'] = 'An account with this email already exists.';
    }

    // Password strength checks
    if (empty($password))                          $errors['password'] = 'Password is required.';
    elseif (strlen($password) < 8)                 $errors['password'] = 'Password must be at least 8 characters.';
    elseif (!preg_match('/[A-Z]/', $password))     $errors['password'] = 'Password must contain at least one uppercase letter.';
    elseif (!preg_match('/[0-9]/', $password))     $errors['password'] = 'Password must contain at least one number.';
    if ($password !== $password2)                   $errors['password2'] = 'Passwords do not match.';

    // Agree to terms
    if (empty($_POST['agree_terms'])) {
    $errors['agree_terms'] = 'You must agree to the Terms of Service.';}

    if (empty($errors)) {
        // Hash password with bcrypt — NEVER store plain text passwords
        $hashed = password_hash($password, PASSWORD_BCRYPT);

        $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, password, phone, role, status) VALUES (?,?,?,?,?,'member','active')");
        $stmt->execute([$old['first_name'], $old['last_name'], $old['email'], $hashed, $old['phone'] ?: null]);

        // Auto-login: store user info in session immediately after registering
        $_SESSION['user_id']    = $pdo->lastInsertId();
        $_SESSION['first_name'] = $old['first_name'];
        $_SESSION['last_name']  = $old['last_name'];
        $_SESSION['email']      = $old['email'];
        $_SESSION['role']       = 'member';

        header('Location: profile.php?welcome=1');
        exit;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<section class="auth-page">
    <div class="auth-container">
        <div class="auth-panel auth-panel--brand">
            <a href="<?= SITE_URL ?>/index.php" class="auth-logo"><span>⚡</span> GYM<strong>HUB</strong></a>
            <h2>Start Your Fitness Journey Today</h2>
            <p>Join thousands of members who have transformed their lives at GymHub.</p>
            <ul class="auth-perks">
                <li>✓ Book any of our 20+ classes instantly</li>
                <li>✓ Track your fitness progress over time</li>
                <li>✓ Ask questions directly to our instructors</li>
                <li>✓ Access exclusive member resources</li>
            </ul>
            <div class="auth-switch">Already have an account? <a href="login.php">Log In →</a></div>
        </div>

        <div class="auth-panel auth-panel--form">
            <h2>Create Your Account</h2>
            <p class="auth-subtitle">It's free and takes less than a minute.</p>

            <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" role="alert">
                <strong>Please fix the following errors:</strong>
                <ul><?php foreach ($errors as $err): ?><li><?= h($err) ?></li><?php endforeach; ?></ul>
            </div>
            <?php endif; ?>

            <form method="POST" action="" class="auth-form" novalidate>
                <div class="form-row">
                    <div class="form-group <?= isset($errors['first_name']) ? 'form-group--error' : '' ?>">
                        <label for="first_name">First Name <span class="required">*</span></label>
                        <input type="text" id="first_name" name="first_name" value="<?= h($old['first_name'] ?? '') ?>" placeholder="Jane" required autocomplete="given-name">
                        <?php if (isset($errors['first_name'])): ?><span class="form-error"><?= h($errors['first_name']) ?></span><?php endif; ?>
                    </div>
                    <div class="form-group <?= isset($errors['last_name']) ? 'form-group--error' : '' ?>">
                        <label for="last_name">Last Name <span class="required">*</span></label>
                        <input type="text" id="last_name" name="last_name" value="<?= h($old['last_name'] ?? '') ?>" placeholder="Smith" required autocomplete="family-name">
                        <?php if (isset($errors['last_name'])): ?><span class="form-error"><?= h($errors['last_name']) ?></span><?php endif; ?>
                    </div>
                </div>

                <div class="form-group <?= isset($errors['email']) ? 'form-group--error' : '' ?>">
                    <label for="email">Email Address <span class="required">*</span></label>
                    <input type="email" id="email" name="email" value="<?= h($old['email'] ?? '') ?>" placeholder="jane@example.com" required autocomplete="email">
                    <?php if (isset($errors['email'])): ?><span class="form-error"><?= h($errors['email']) ?></span><?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number <span class="optional">(optional)</span></label>
                    <input type="tel" id="phone" name="phone" value="<?= h($old['phone'] ?? '') ?>" placeholder="519-555-0100" autocomplete="tel">
                </div>

                <div class="form-group <?= isset($errors['password']) ? 'form-group--error' : '' ?>">
                    <label for="password">Password <span class="required">*</span></label>
                    <div class="input-password">
                        <input type="password" id="password" name="password" placeholder="Min. 8 chars, 1 uppercase, 1 number" required autocomplete="new-password">
                        <button type="button" class="toggle-password" onclick="togglePassword('password',this)">👁</button>
                    </div>
                    <?php if (isset($errors['password'])): ?><span class="form-error"><?= h($errors['password']) ?></span><?php endif; ?>
                </div>

                <div class="form-group <?= isset($errors['password2']) ? 'form-group--error' : '' ?>">
                    <label for="password2">Confirm Password <span class="required">*</span></label>
                    <div class="input-password">
                        <input type="password" id="password2" name="password2" placeholder="Repeat your password" required autocomplete="new-password">
                        <button type="button" class="toggle-password" onclick="togglePassword('password2',this)">👁</button>
                    </div>
                    <?php if (isset($errors['password2'])): ?><span class="form-error"><?= h($errors['password2']) ?></span><?php endif; ?>
                </div>

                <div class="form-group form-group--checkbox">
                    <label class="checkbox-label">
                        <input type="checkbox" name="agree_terms" required>
                        I agree to the <a href="terms.php" target="_blank">Terms of Service</a> and <a href="privacy.php" target="_blank">Privacy Policy</a>
                    </label>
                </div>

                <button type="submit" class="btn btn-primary btn-full">Create My Account</button>
                <p class="auth-login-link">Already have an account? <a href="login.php">Log in here</a></p>
            </form>
        </div>
    </div>
</section>

<script>
function togglePassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.textContent = input.type === 'password' ? '👁' : '🙈';
}
</script>

<style>
.auth-page{min-height:calc(100vh - 70px);display:flex;align-items:stretch}
.auth-container{display:grid;grid-template-columns:1fr 1fr;width:100%;max-width:1000px;margin:var(--space-2xl) auto;background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-lg)}
.auth-panel{padding:var(--space-2xl)}
.auth-panel--brand{background:linear-gradient(160deg,var(--color-accent) 0%,var(--color-accent-dark) 100%);color:#000;display:flex;flex-direction:column;gap:var(--space-lg)}
.auth-logo{font-family:var(--font-display);font-size:1.5rem;font-weight:400;color:#000;text-decoration:none;display:flex;align-items:center;gap:.4rem}
.auth-logo strong{font-weight:900}
.auth-panel--brand h2{color:#000;font-size:1.8rem}
.auth-panel--brand p{color:rgba(0,0,0,.7)}
.auth-perks{list-style:none;display:flex;flex-direction:column;gap:var(--space-sm)}
.auth-perks li{font-size:.95rem;color:rgba(0,0,0,.8)}
.auth-switch{margin-top:auto;font-size:.9rem;color:rgba(0,0,0,.7)}
.auth-switch a{color:#000;font-weight:700}
.auth-panel--form h2{margin-bottom:.25rem}
.auth-subtitle{color:var(--color-text-muted);margin-bottom:var(--space-lg);font-size:.95rem}
.auth-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group input[type=text],.form-group input[type=email],.form-group input[type=password],.form-group input[type=tel]{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.95rem;outline:none;transition:border-color var(--transition-fast);width:100%}
.form-group input:focus{border-color:var(--color-accent);box-shadow:0 0 0 3px var(--color-accent-glow)}
.form-group--error input{border-color:var(--color-danger)}
.form-error{color:var(--color-danger);font-size:.8rem}
.required{color:var(--color-accent)}
.optional{color:var(--color-text-muted);font-size:.8rem;font-weight:400}
.input-password{position:relative}
.input-password input{padding-right:2.5rem}
.toggle-password{position:absolute;right:.6rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;padding:.25rem}
.form-group--checkbox .checkbox-label{display:flex;align-items:center;gap:.5rem;font-size:.875rem;color:var(--color-text-muted);cursor:pointer}
.form-group--checkbox input[type=checkbox]{width:16px;height:16px;accent-color:var(--color-accent);flex-shrink:0}
.btn-full{width:100%;justify-content:center}
.auth-login-link{text-align:center;font-size:.875rem;color:var(--color-text-muted)}
.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert ul{padding-left:1.2rem;margin-top:.4rem}
@media(max-width:768px){.auth-container{grid-template-columns:1fr;margin:0;border-radius:0}.auth-panel--brand{display:none}.form-row{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
