<?php
/**
 * GymHub - Progress Tracker
 * pages/progress.php
 *
 * Lets logged-in members log their weight daily and see their
 * fitness progress visualized with three interactive charts.
 *
 * DATA VISUALIZATION REQUIREMENT: This page satisfies it with:
 *   1. Line chart  — weight over time (shows trend)
 *   2. Bar chart   — sessions attended per log entry
 *   3. Doughnut    — bookings broken down by class category
 *
 * Charts are built using Chart.js loaded from CDN.
 * Chart colours are read from CSS variables so they match the active theme.
 *
 * UPSERT pattern used: if an entry exists for today, UPDATE it.
 * If not, INSERT a new row. This prevents duplicate daily entries.
 *
 * Sessions attended is auto-counted from the bookings table for each
 * log date rather than asking the user to enter it manually.
 */

$page_title       = 'Progress Tracker | GymHub';
$page_description = 'Track your fitness progress at GymHub. Log your weight, view charts, and monitor your improvement over time.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';

// Redirect guests to login
if (!is_logged_in()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/progress.php'));
}

$user_id = $_SESSION['user_id'];
$success = '';
$error   = '';

// ── Handle log entry form submission ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log_progress'])) {

    // Collect form inputs — trim removes whitespace from text fields
    $log_date  = trim($_POST['log_date']   ?? '');
    $weight_kg = trim($_POST['weight_kg']  ?? '');
    $notes     = trim($_POST['notes']      ?? '');

    // Validate: date must be valid and weight must be a positive number
    if (!$log_date || !strtotime($log_date)) {
        $error = 'Please enter a valid date.';
    } elseif ($weight_kg !== '' && (!is_numeric($weight_kg) || $weight_kg <= 0)) {
        $error = 'Please enter a valid weight (e.g. 75.5).';
    } else {
        // Auto-count sessions attended on this date from the bookings table
        // This saves the user from having to enter it manually
        $s = $pdo->prepare("
            SELECT COUNT(*) FROM bookings b
            JOIN class_schedule cs ON b.schedule_id = cs.id
            WHERE b.user_id = ? AND cs.date = ? AND b.status = 'confirmed'
        ");
        $s->execute([$user_id, $log_date]);
        $sessions_count = (int)$s->fetchColumn();

        // UPSERT pattern: check if a log entry already exists for this date
        $existing = $pdo->prepare("SELECT id FROM progress WHERE user_id = ? AND log_date = ?");
        $existing->execute([$user_id, $log_date]);
        $exists = $existing->fetch();

        if ($exists) {
            // Entry exists for this date — UPDATE it instead of inserting a duplicate
            $pdo->prepare("
                UPDATE progress
                SET weight_kg = ?, sessions_attended = ?, notes = ?
                WHERE user_id = ? AND log_date = ?
            ")->execute([
                $weight_kg ?: null, // store NULL if weight field was left blank
                $sessions_count,
                $notes ?: null,
                $user_id,
                $log_date
            ]);
            $success = 'Progress entry updated!';
        } else {
            // No entry for this date — INSERT a new row
            $pdo->prepare("
                INSERT INTO progress (user_id, log_date, weight_kg, sessions_attended, notes)
                VALUES (?, ?, ?, ?, ?)
            ")->execute([
                $user_id,
                $log_date,
                $weight_kg ?: null,
                $sessions_count,
                $notes ?: null
            ]);
            $success = 'Progress entry saved!';
        }
    }
}

// ── Load progress entries for charts ─────────────────────────────────────────
// Last 30 entries ordered oldest first so charts read left to right over time
$entries = $pdo->prepare("
    SELECT * FROM progress
    WHERE user_id = ?
    ORDER BY log_date ASC
    LIMIT 30
");
$entries->execute([$user_id]);
$entries = $entries->fetchAll();

// ── Build chart data arrays from entries ─────────────────────────────────────
// Chart.js needs separate arrays for labels (X axis) and data (Y axis)
$chart_labels   = [];
$chart_weights  = [];
$chart_sessions = [];

foreach ($entries as $e) {
    // Format date as "Apr 6" for readable X axis labels
    $chart_labels[]   = date('M j', strtotime($e['log_date']));
    // Use null for missing weights so Chart.js skips those points instead of showing 0
    $chart_weights[]  = $e['weight_kg'] ? (float)$e['weight_kg'] : null;
    $chart_sessions[] = (int)$e['sessions_attended'];
}

// ── Load class category breakdown for doughnut chart ─────────────────────────
// Counts all confirmed bookings grouped by class category
$cat_data = $pdo->prepare("
    SELECT c.category, COUNT(*) AS cnt
    FROM bookings b
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    WHERE b.user_id = ? AND b.status = 'confirmed'
    GROUP BY c.category
    ORDER BY cnt DESC
");
$cat_data->execute([$user_id]);
$cat_data = $cat_data->fetchAll();

// Today's date as default value for the log date input field
$today = date('Y-m-d');

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">My Fitness</span>
        <h1>Progress Tracker</h1>
        <p>Log your workouts and watch your improvement over time.</p>
    </div>
</section>

<section class="progress-page section-pad">
    <div class="container">

        <!-- Form feedback -->
        <?php if ($success): ?>
        <div class="alert alert-success flash-message"><?= h($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
        <?php endif; ?>

        <!-- Two-column layout: log form left, chart panel right -->
        <div class="progress-grid">

            <!-- ── Log entry form ── -->
            <div class="log-form-card">
                <h3>Log Today's Progress</h3>
                <p style="color:var(--color-text-muted);font-size:.9rem;margin-bottom:var(--space-lg);">
                    Sessions attended are counted automatically from your bookings.
                </p>
                <form method="POST" action="" class="log-form">
                    <div class="form-group">
                        <label for="log_date">Date</label>
                        <!-- Default to today but allow logging past dates -->
                        <input type="date" id="log_date" name="log_date"
                               value="<?= h($today) ?>" max="<?= h($today) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="weight_kg">Weight (kg) <span class="optional">(optional)</span></label>
                        <input type="number" id="weight_kg" name="weight_kg"
                               placeholder="e.g. 75.5" step="0.1" min="20" max="300">
                    </div>
                    <div class="form-group">
                        <label for="notes">Notes <span class="optional">(optional)</span></label>
                        <textarea id="notes" name="notes" rows="3"
                                  placeholder="How did you feel? What did you work on?"></textarea>
                    </div>
                    <button type="submit" name="log_progress" class="btn btn-primary">
                        Save Entry
                    </button>
                </form>
            </div>

            <!-- ── Recent log entries ── -->
            <div class="log-history-card">
                <h3>Recent Entries</h3>
                <?php if (empty($entries)): ?>
                <p style="color:var(--color-text-muted);font-size:.9rem;">
                    No entries yet. Start logging to see your progress!
                </p>
                <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="log-table">
                        <thead>
                            <tr><th>Date</th><th>Weight</th><th>Sessions</th><th>Notes</th></tr>
                        </thead>
                        <tbody>
                            <?php
                            // Show most recent entries first in the table (reverse the array)
                            foreach (array_reverse($entries) as $e):
                            ?>
                            <tr>
                                <td><?= date('M j, Y', strtotime($e['log_date'])) ?></td>
                                <!-- Show em dash if weight wasn't logged that day -->
                                <td><?= $e['weight_kg'] ? h($e['weight_kg']) . ' kg' : '—' ?></td>
                                <td><?= $e['sessions_attended'] ?></td>
                                <td style="max-width:200px;font-size:.8rem;color:var(--color-text-muted);">
                                    <?= $e['notes'] ? h(substr($e['notes'], 0, 60)) . '...' : '—' ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- ── Charts section ── -->
        <?php if (!empty($entries)): ?>
        <div class="charts-section">
            <h2>Your Progress Charts</h2>

            <div class="charts-grid">
                <!-- Chart 1: Weight over time (line chart) -->
                <div class="chart-card">
                    <h3>Weight Over Time</h3>
                    <canvas id="weightChart" height="200"></canvas>
                </div>

                <!-- Chart 2: Sessions attended per entry (bar chart) -->
                <div class="chart-card">
                    <h3>Sessions Attended</h3>
                    <canvas id="sessionsChart" height="200"></canvas>
                </div>

                <!-- Chart 3: Class category breakdown (doughnut) -->
                <?php if (!empty($cat_data)): ?>
                <div class="chart-card">
                    <h3>Classes by Category</h3>
                    <canvas id="catChart" height="200"></canvas>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Chart.js from CDN — renders all three charts -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
        <script>
        // ── Pass PHP data arrays to JavaScript ────────────────────────────────
        // json_encode() converts PHP arrays to valid JavaScript arrays
        const labels   = <?= json_encode($chart_labels) ?>;
        const weights  = <?= json_encode($chart_weights) ?>;
        const sessions = <?= json_encode($chart_sessions) ?>;
        const catData  = <?= json_encode($cat_data) ?>;

        // Read the accent colour from the active CSS theme variable
        const accent = getComputedStyle(document.documentElement)
                           .getPropertyValue('--color-accent').trim();

        // Shared chart options used on all three charts
        const sharedOpts = {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                x: { ticks: { color: '#888' }, grid: { color: '#2e2e2e' } },
                y: { ticks: { color: '#888' }, grid: { color: '#2e2e2e' }, beginAtZero: false }
            }
        };

        // ── Chart 1: Weight line chart ────────────────────────────────────────
        new Chart(document.getElementById('weightChart'), {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Weight (kg)',
                    data: weights,
                    borderColor: accent,          // orange line
                    backgroundColor: accent + '22', // transparent fill below line
                    tension: 0.4,                 // smooth curve
                    spanGaps: true,               // skip null values instead of breaking the line
                    pointBackgroundColor: accent,
                    pointRadius: 4
                }]
            },
            options: { ...sharedOpts }
        });

        // ── Chart 2: Sessions bar chart ───────────────────────────────────────
        new Chart(document.getElementById('sessionsChart'), {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: 'Sessions',
                    data: sessions,
                    backgroundColor: accent + '44', // transparent orange bars
                    borderColor: accent,
                    borderWidth: 2,
                    borderRadius: 4  // rounded bar tops
                }]
            },
            options: {
                ...sharedOpts,
                scales: {
                    ...sharedOpts.scales,
                    y: { ...sharedOpts.scales.y, beginAtZero: true, ticks: { stepSize: 1, color: '#888' } }
                }
            }
        });

        // ── Chart 3: Category doughnut ────────────────────────────────────────
        if (document.getElementById('catChart')) {
            // Generate a range of colours based on the accent for each slice
            const colours = catData.map((_, i) =>
                `hsl(${(i * 45 + 25)}deg, 80%, 55%)`
            );
            new Chart(document.getElementById('catChart'), {
                type: 'doughnut',
                data: {
                    labels: catData.map(d => d.category),
                    datasets: [{ data: catData.map(d => d.cnt), backgroundColor: colours }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'bottom', labels: { color: '#888', padding: 12 } }
                    }
                }
            });
        }
        </script>
        <?php endif; ?>

    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.progress-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--space-xl);margin-bottom:var(--space-3xl)}
.log-form-card,.log-history-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.log-form-card h3,.log-history-card h3{margin-bottom:var(--space-md)}
.log-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group input[type=date],.form-group input[type=number],.form-group textarea{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.9rem;outline:none;width:100%;transition:border-color var(--transition-fast)}
.form-group input:focus,.form-group textarea:focus{border-color:var(--color-accent)}
.form-group textarea{resize:vertical}
.optional{color:var(--color-text-muted);font-size:.78rem;font-weight:400}
.log-table{width:100%;border-collapse:collapse;font-size:.875rem}
.log-table th{text-align:left;padding:.6rem .75rem;background:var(--color-surface-2);border-bottom:1px solid var(--color-border);font-family:var(--font-display);font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--color-text-muted)}
.log-table td{padding:.6rem .75rem;border-bottom:1px solid var(--color-border);color:var(--color-text-light)}
.charts-section h2{margin-bottom:var(--space-xl)}
.charts-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:var(--space-lg)}
.chart-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg)}
.chart-card h3{font-size:1rem;margin-bottom:var(--space-md)}
.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-lg)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}
@media(max-width:768px){.progress-grid{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
