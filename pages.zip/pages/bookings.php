<?php
/**
 * GymHub - My Bookings
 * pages/bookings.php
 *
 * Shows the logged-in member's upcoming and past class bookings.
 *
 * What this page does:
 *   - Displays upcoming confirmed bookings as visual cards with class image,
 *     date, time, room, option chosen, instructor, and price
 *   - Shows past bookings in a compact history table
 *   - Allows cancellation of upcoming bookings (free if 24+ hours away)
 *   - Each past booking has a Rate button linking to the review form
 *
 * Cancellation rule:
 *   The class date+time is converted to a Unix timestamp and compared
 *   to now. If the difference is less than 24 hours, cancellation is blocked.
 *   When a booking is cancelled, spots_left is restored so others can book.
 */

$page_title       = 'My Bookings | GymHub';
$page_description = 'View and manage your GymHub class bookings.';
$active_nav       = '';

// Context-sensitive help bar — links to the booking wiki guide
$help_link = 'booking-guide.php';
$help_text = 'Learn how to manage your bookings';

require_once __DIR__ . '/../config/db.php';

// Redirect guests to login — pass the return URL so they come back here after
if (!is_logged_in()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/bookings.php'));
}

$user_id = $_SESSION['user_id'];
$success = '';
$error   = '';

// ── Handle cancellation POST ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {

    // Cast to int to prevent SQL injection via the hidden form field
    $booking_id = (int)($_POST['booking_id'] ?? 0);

    // Verify booking exists, belongs to THIS user, and is still confirmed.
    // The user_id = ? check prevents users cancelling each other's bookings.
    $stmt = $pdo->prepare("
        SELECT b.*, cs.date, cs.time
        FROM bookings b
        JOIN class_schedule cs ON b.schedule_id = cs.id
        WHERE b.id = ? AND b.user_id = ? AND b.status = 'confirmed'
    ");
    $stmt->execute([$booking_id, $user_id]);
    $booking = $stmt->fetch();

    if ($booking) {
        // Convert the date and time strings to a Unix timestamp for arithmetic
        $class_datetime = strtotime($booking['date'] . ' ' . $booking['time']);

        // Calculate hours until class — time() is current Unix timestamp in seconds
        $hours_until = ($class_datetime - time()) / 3600;

        if ($hours_until >= 24) {
            // Enough time — allow the cancellation
            $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=?")
                ->execute([$booking_id]);

            // Restore the spot so another member can book it
            $pdo->prepare("UPDATE class_schedule SET spots_left = spots_left + 1 WHERE id=?")
                ->execute([$booking['schedule_id']]);

            $success = 'Booking cancelled successfully. Your spot has been released.';
        } else {
            // Too close to class time — block the cancellation
            $error = 'Cancellations must be made at least 24 hours before the class.';
        }
    }
}

// ── Fetch upcoming confirmed bookings ─────────────────────────────────────────
// Gets sessions from today onwards where status is still confirmed.
// Multiple JOINs needed: bookings → schedule → classes → instructors → users
$stmt = $pdo->prepare("
    SELECT b.*, c.title, c.category, c.image, c.price, c.id AS class_id,
           cs.date, cs.time, cs.room,
           CONCAT(u.first_name, ' ', u.last_name) AS instructor_name
    FROM bookings b
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    LEFT JOIN instructors i ON c.instructor_id = i.id
    LEFT JOIN users u       ON i.user_id = u.id
    WHERE b.user_id = ? AND b.status = 'confirmed' AND cs.date >= CURDATE()
    ORDER BY cs.date ASC, cs.time ASC
");
$stmt->execute([$user_id]);
$upcoming = $stmt->fetchAll();

// ── Fetch past and cancelled bookings ─────────────────────────────────────────
// Shows sessions that have passed OR were cancelled.
// LIMIT 20 keeps the page manageable for active members.
$stmt = $pdo->prepare("
    SELECT b.*, c.title, c.category, c.image, c.id AS class_id,
           cs.date, cs.time, cs.room
    FROM bookings b
    JOIN class_schedule cs ON b.schedule_id = cs.id
    JOIN classes c         ON cs.class_id   = c.id
    WHERE b.user_id = ? AND (b.status != 'confirmed' OR cs.date < CURDATE())
    ORDER BY cs.date DESC
    LIMIT 20
");
$stmt->execute([$user_id]);
$past = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">My Account</span>
        <h1>My Bookings</h1>
        <p>Manage your upcoming sessions and view your class history.</p>
    </div>
</section>

<section class="bookings-page section-pad">
    <div class="container">

        <!-- Success/error feedback from cancellation form -->
        <?php if ($success): ?>
        <div class="alert alert-success flash-message"><?= h($success) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger flash-message"><?= h($error) ?></div>
        <?php endif; ?>

        <!-- ── Upcoming bookings section ── -->
        <div class="bookings-section">
            <h2>Upcoming Classes
                <!-- Orange count badge next to heading -->
                <span class="count-badge"><?= count($upcoming) ?></span>
            </h2>

            <?php if (empty($upcoming)): ?>
            <!-- Empty state — shown when no upcoming bookings exist -->
            <div class="empty-state">
                <div class="empty-icon">📅</div>
                <h3>No upcoming bookings</h3>
                <p>Browse our schedule and book your first session!</p>
                <a href="classes.php" class="btn btn-primary">Browse Classes</a>
            </div>

            <?php else: ?>
            <div class="bookings-grid">
                <?php foreach ($upcoming as $b):
                    // Check if this booking can still be cancelled (24hr rule)
                    $class_datetime = strtotime($b['date'] . ' ' . $b['time']);
                    $hours_until    = ($class_datetime - time()) / 3600;
                    $can_cancel     = $hours_until >= 24;
                ?>
                <div class="booking-card booking-card--upcoming">
                    <!-- Class image with Confirmed badge overlaid -->
                    <div class="booking-card-image">
                        <img src="<?= SITE_URL ?>/public/assets/images/classes/<?= h($b['image']) ?>"
                             alt="<?= h($b['title']) ?>"
                             onerror="this.src='<?= SITE_URL ?>/public/assets/images/classes/default-class.jpg'">
                        <span class="booking-status-badge booking-status-badge--confirmed">Confirmed</span>
                    </div>

                    <div class="booking-card-body">
                        <span class="class-category-badge"><?= h($b['category']) ?></span>
                        <h3><?= h($b['title']) ?></h3>

                        <!-- Session details: date, time, room, option, instructor, price -->
                        <div class="booking-details">
                            <div class="booking-detail">
                                <span class="detail-label">📅 Date</span>
                                <!-- 'l, F j, Y' = Tuesday, April 8, 2025 -->
                                <span><?= date('l, F j, Y', strtotime($b['date'])) ?></span>
                            </div>
                            <div class="booking-detail">
                                <span class="detail-label">🕐 Time</span>
                                <!-- 'g:i A' = 7:00 AM (12-hour clock) -->
                                <span><?= date('g:i A', strtotime($b['time'])) ?></span>
                            </div>
                            <div class="booking-detail">
                                <span class="detail-label">📍 Room</span>
                                <span><?= h($b['room']) ?></span>
                            </div>
                            <div class="booking-detail">
                                <span class="detail-label">🎯 Option</span>
                                <span><?= h($b['option_choice']) ?></span>
                            </div>
                            <?php if ($b['instructor_name']): ?>
                            <div class="booking-detail">
                                <span class="detail-label">👤 Instructor</span>
                                <span><?= h($b['instructor_name']) ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="booking-detail">
                                <span class="detail-label">💰 Price</span>
                                <span>$<?= number_format($b['price'], 2) ?></span>
                            </div>
                        </div>

                        <div class="booking-actions">
                            <a href="class-detail.php?id=<?= $b['class_id'] ?>"
                               class="btn btn-secondary btn-sm">View Class</a>

                            <?php if ($can_cancel): ?>
                            <!-- Cancellation form — confirm dialog before submitting -->
                            <form method="POST" style="display:inline;"
                                  onsubmit="return confirm('Cancel this booking?')">
                                <!-- Hidden input passes booking ID to POST handler above -->
                                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                <button type="submit" name="cancel_booking"
                                        class="btn btn-danger btn-sm">Cancel Booking</button>
                            </form>
                            <?php else: ?>
                            <!-- Lock shown when less than 24 hours until class -->
                            <span class="cancel-locked" title="Cannot cancel within 24 hours">
                                🔒 Late cancel
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- ── Booking history table ── -->
        <div class="bookings-section">
            <h2>Booking History
                <span class="count-badge"><?= count($past) ?></span>
            </h2>

            <?php if (empty($past)): ?>
            <p style="color:var(--color-text-muted);">No past bookings yet.</p>
            <?php else: ?>
            <div class="history-table-wrapper">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Class</th><th>Date</th><th>Time</th>
                            <th>Option</th><th>Status</th><th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($past as $b): ?>
                        <tr>
                            <td>
                                <strong><?= h($b['title']) ?></strong><br>
                                <small><?= h($b['category']) ?></small>
                            </td>
                            <td><?= date('M j, Y', strtotime($b['date'])) ?></td>
                            <td><?= date('g:i A', strtotime($b['time'])) ?></td>
                            <td><?= h($b['option_choice']) ?></td>
                            <td>
                                <!-- Colour-coded pill: green=completed, red=cancelled -->
                                <span class="booking-status-pill booking-status-pill--<?= h($b['status']) ?>">
                                    <?= ucfirst($b['status']) ?>
                                </span>
                            </td>
                            <td>
                                <!-- Rate button only shown for past/completed sessions -->
                                <?php if ($b['status'] === 'completed' || strtotime($b['date']) < time()): ?>
                                <a href="rate-class.php?id=<?= $b['class_id'] ?>"
                                   class="btn btn-secondary btn-sm">⭐ Rate</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.bookings-section{margin-bottom:var(--space-3xl)}
.bookings-section h2{display:flex;align-items:center;gap:var(--space-sm);margin-bottom:var(--space-xl)}
.count-badge{background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:.8rem;font-weight:700;padding:.15rem .55rem;border-radius:var(--radius-full)}
.bookings-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:var(--space-lg)}
.booking-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden}
.booking-card--upcoming{border-color:var(--color-accent)}
.booking-card-image{position:relative;height:160px;overflow:hidden}
.booking-card-image img{width:100%;height:100%;object-fit:cover}
.booking-status-badge{position:absolute;top:.75rem;right:.75rem;font-family:var(--font-display);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:.2rem .6rem;border-radius:var(--radius-full)}
.booking-status-badge--confirmed{background:var(--color-success);color:#000}
.booking-card-body{padding:var(--space-lg)}
.booking-card-body h3{margin:var(--space-sm) 0 var(--space-md);font-size:1.1rem}
.booking-details{display:flex;flex-direction:column;gap:.5rem;margin-bottom:var(--space-lg)}
.booking-detail{display:flex;justify-content:space-between;align-items:center;font-size:.875rem}
.detail-label{color:var(--color-text-muted)}
.booking-actions{display:flex;gap:var(--space-sm);align-items:center;flex-wrap:wrap}
.cancel-locked{font-size:.8rem;color:var(--color-text-muted)}
.history-table-wrapper{overflow-x:auto}
.history-table{width:100%;border-collapse:collapse;font-size:.9rem}
.history-table th{text-align:left;padding:.75rem 1rem;background:var(--color-surface);border-bottom:2px solid var(--color-border);font-family:var(--font-display);font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--color-text-muted)}
.history-table td{padding:.75rem 1rem;border-bottom:1px solid var(--color-border);color:var(--color-text-light);vertical-align:middle}
.history-table tr:hover td{background:var(--color-surface)}
.history-table small{color:var(--color-text-muted);font-size:.8rem}
.booking-status-pill{font-family:var(--font-display);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:.2rem .6rem;border-radius:var(--radius-full)}
.booking-status-pill--confirmed{background:rgba(34,197,94,.15);color:var(--color-success)}
.booking-status-pill--cancelled{background:rgba(239,68,68,.15);color:var(--color-danger)}
.booking-status-pill--completed{background:var(--color-accent-glow);color:var(--color-accent)}
.empty-state{text-align:center;padding:var(--space-2xl);display:flex;flex-direction:column;align-items:center;gap:var(--space-md)}
.empty-icon{font-size:3rem}
.empty-state h3{color:var(--color-text-muted)}
.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-lg)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}
@media(max-width:600px){.bookings-grid{grid-template-columns:1fr}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
