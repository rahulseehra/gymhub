<?php
/**
 * GymHub - Gym Locations
 * pages/locations.php
 *
 * Shows all GymHub locations on an interactive Leaflet.js map.
 *
 * INTERACTIVE MAP REQUIREMENT: This page satisfies that requirement.
 * Leaflet.js is a free open-source mapping library that uses
 * OpenStreetMap tiles — no API key needed.
 *
 * How the map works:
 *   1. PHP loads all locations from the database (lat/lng coordinates)
 *   2. json_encode() converts the PHP array to a JavaScript variable
 *   3. JavaScript loops through the locations and adds a custom marker pin
 *      for each one using L.marker() from the Leaflet.js library
 *   4. Clicking a location card calls flyToLocation() which smoothly
 *      pans and zooms the map to that pin and opens its popup
 *
 * Custom marker pins are created using Leaflet's divIcon with
 * HTML/CSS instead of an image file — easier to theme.
 */

$page_title       = 'Our Locations | GymHub';
$page_description = 'Find a GymHub gym near you. Three Windsor Ontario locations — Downtown, Westside, and Riverside. Directions, hours, and facilities.';
$page_keywords    = 'gym Windsor locations, GymHub address, gym near me Windsor Ontario';
$active_nav       = 'locations';

require_once __DIR__ . '/../config/db.php';

// ── Load all locations from database ─────────────────────────────────────────
// lat and lng columns store GPS coordinates used by Leaflet.js
$locations = $pdo->query("
    SELECT * FROM locations ORDER BY id ASC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Find Us</span>
        <h1>Our Locations</h1>
        <p>Three Windsor locations — find the one nearest you.</p>
    </div>
</section>

<section class="locations-page section-pad">
    <div class="container">

        <!-- Two-column layout: location cards left, map right -->
        <div class="locations-grid">

            <!-- ── Location cards (left column) ── -->
            <div class="locations-list">
                <?php foreach ($locations as $i => $loc): ?>
                <!-- Clicking a card flies the map to that location -->
                <div class="location-card" id="loc-card-<?= $loc['id'] ?>"
                     onclick="flyToLocation(<?= $loc['lat'] ?>, <?= $loc['lng'] ?>, '<?= h(addslashes($loc['name'])) ?>')">

                    <!-- Location photo -->
                    <?php if ($loc['photo']): ?>
                    <div class="location-photo">
                        <img src="<?= SITE_URL ?>/public/assets/images/<?= h($loc['photo']) ?>"
                             alt="<?= h($loc['name']) ?>"
                             onerror="this.src='<?= SITE_URL ?>/public/assets/images/hero-bg.jpg'">
                    </div>
                    <?php endif; ?>

                    <div class="location-info">
                        <!-- Location number badge -->
                        <div class="location-number"><?= $i + 1 ?></div>
                        <div class="location-details">
                            <h3><?= h($loc['name']) ?></h3>
                            <p class="location-address">
                                📍 <?= h($loc['address']) ?>, <?= h($loc['city']) ?>
                            </p>
                            <?php if ($loc['phone']): ?>
                            <p class="location-phone">
                                📞 <a href="tel:<?= h(preg_replace('/[^0-9+]/', '', $loc['phone'])) ?>">
                                    <?= h($loc['phone']) ?>
                                </a>
                            </p>
                            <?php endif; ?>
                            <?php if ($loc['hours']): ?>
                            <p class="location-hours">🕐 <?= h($loc['hours']) ?></p>
                            <?php endif; ?>
                            <!-- "View on Map" link triggers flyToLocation -->
                            <button class="btn btn-secondary btn-sm map-btn"
                                    onclick="event.stopPropagation(); flyToLocation(<?= $loc['lat'] ?>, <?= $loc['lng'] ?>, '<?= h(addslashes($loc['name'])) ?>')">
                                🗺 View on Map
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- ── Leaflet.js interactive map (right column) ── -->
            <!-- The div#gymhub-map is where Leaflet renders the map canvas -->
            <div class="map-container">
                <div id="gymhub-map"></div>
            </div>

        </div>

        <!-- ── Facilities section ── -->
        <div class="facilities-section">
            <h2>Facilities at Every Location</h2>
            <p style="color:var(--color-text-muted);margin-bottom:var(--space-xl);">
                All three GymHub locations are equipped with everything you need for a complete workout.
            </p>
            <div class="facilities-grid">
                <?php
                // Array of amenity icons and labels — easy to add new ones
                $facilities = [
                    ['🏋️', 'Free Weights'],
                    ['🧘', 'Group Studios'],
                    ['🚿', 'Locker Rooms & Showers'],
                    ['🥊', 'Combat Zone'],
                    ['📶', 'Free Wi-Fi'],
                    ['🅿️', 'Free Parking'],
                    ['💊', 'First Aid On-Site'],
                    ['🎵', 'Sound System'],
                ];
                foreach ($facilities as [$icon, $label]):
                ?>
                <div class="facility-item">
                    <span class="facility-icon"><?= $icon ?></span>
                    <span><?= $label ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>

<!-- Leaflet.js CSS — loaded from CDN, no installation needed -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<!-- Leaflet.js JavaScript library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>

<script>
// ── Pass PHP location data to JavaScript ──────────────────────────────────────
// json_encode() converts the PHP array to a valid JavaScript array.
// We only pass the fields JavaScript needs — not the full database row.
const locations = <?= json_encode(array_map(fn($l) => [
    'id'      => $l['id'],
    'name'    => $l['name'],
    'address' => $l['address'] . ', ' . $l['city'],
    'phone'   => $l['phone'],
    'hours'   => $l['hours'],
    'lat'     => (float)$l['lat'],
    'lng'     => (float)$l['lng'],
], $locations)) ?>;

// ── Initialize the Leaflet map ────────────────────────────────────────────────
// Centre on Windsor, Ontario at zoom level 13 (shows whole city)
const map = L.map('gymhub-map').setView([42.3149, -83.0364], 13);

// ── Add OpenStreetMap tile layer ──────────────────────────────────────────────
// OpenStreetMap is free — no API key required unlike Google Maps
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
    maxZoom: 19
}).addTo(map);

// ── Create a custom HTML/CSS marker pin icon ──────────────────────────────────
// Using divIcon so we can style it with CSS to match the site's orange theme
const gymIcon = L.divIcon({
    className: 'gym-marker',
    html: '<div class="marker-pin">⚡</div>',
    iconSize: [36, 36],
    iconAnchor: [18, 36],    // anchor point — bottom-centre of the pin
    popupAnchor: [0, -36]    // popup appears above the pin
});

// ── Add a marker for each location ───────────────────────────────────────────
// Keep markers in an array so flyToLocation() can reference them later
const markers = {};
locations.forEach(loc => {
    // Create marker at the location's GPS coordinates
    const marker = L.marker([loc.lat, loc.lng], { icon: gymIcon }).addTo(map);

    // Bind a popup with the location name, address, and hours
    marker.bindPopup(`
        <div class="map-popup">
            <strong>${loc.name}</strong>
            <p>${loc.address}</p>
            ${loc.phone ? `<p>📞 ${loc.phone}</p>` : ''}
            ${loc.hours ? `<p>🕐 ${loc.hours}</p>` : ''}
        </div>
    `);

    // Store marker by location name so flyToLocation() can open its popup
    markers[loc.name] = marker;
});

/**
 * flyToLocation(lat, lng, name) — Smoothly pans map to a location
 * Called when user clicks a location card or "View on Map" button.
 * Uses Leaflet's flyTo() for a smooth animated transition.
 *
 * @param {number} lat  - Latitude coordinate
 * @param {number} lng  - Longitude coordinate
 * @param {string} name - Location name (used to find and open the marker popup)
 */
function flyToLocation(lat, lng, name) {
    // Animate the map moving to the new location at zoom level 16 (street level)
    map.flyTo([lat, lng], 16, { duration: 1.2 });

    // Open the popup for this location's marker after a short delay
    // (delay lets the animation complete before popup appears)
    setTimeout(() => {
        if (markers[name]) markers[name].openPopup();
    }, 1200);
}
</script>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}

/* Two-column layout: cards left, map right */
.locations-grid{display:grid;grid-template-columns:380px 1fr;gap:var(--space-xl);margin-bottom:var(--space-3xl);align-items:start}

/* Location cards */
.locations-list{display:flex;flex-direction:column;gap:var(--space-md)}
.location-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;cursor:pointer;transition:all var(--transition-normal)}
.location-card:hover{border-color:var(--color-accent);transform:translateY(-2px);box-shadow:var(--shadow-accent)}
.location-photo{height:140px;overflow:hidden}
.location-photo img{width:100%;height:100%;object-fit:cover}
.location-info{padding:var(--space-lg);display:flex;gap:var(--space-md);align-items:flex-start}
.location-number{width:32px;height:32px;border-radius:50%;background:var(--color-accent);color:#000;font-family:var(--font-display);font-size:.9rem;font-weight:900;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.location-details{flex:1;display:flex;flex-direction:column;gap:.35rem}
.location-details h3{font-size:1rem;margin:0}
.location-address,.location-phone,.location-hours{font-size:.85rem;color:var(--color-text-muted);margin:0}
.location-phone a{color:var(--color-accent)}
.map-btn{margin-top:var(--space-sm);align-self:flex-start}

/* Leaflet map container */
.map-container{position:sticky;top:90px}
#gymhub-map{height:500px;border-radius:var(--radius-lg);border:1px solid var(--color-border);z-index:1}

/* Custom orange marker pin */
.marker-pin{width:36px;height:36px;background:var(--color-accent);border-radius:50% 50% 50% 0;transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.4)}
.marker-pin span{transform:rotate(45deg);font-size:1rem}
.gym-marker{background:none;border:none}

/* Map popup styles */
.map-popup strong{display:block;font-family:var(--font-display);font-size:1rem;margin-bottom:.3rem}
.map-popup p{font-size:.85rem;margin:.2rem 0;color:#333}

/* Facilities grid */
.facilities-section h2{margin-bottom:var(--space-sm)}
.facilities-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:var(--space-md)}
.facility-item{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-md);display:flex;align-items:center;gap:var(--space-sm);font-size:.9rem;color:var(--color-text-light)}
.facility-icon{font-size:1.3rem}

@media(max-width:900px){.locations-grid{grid-template-columns:1fr}.map-container{position:static}#gymhub-map{height:350px}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
