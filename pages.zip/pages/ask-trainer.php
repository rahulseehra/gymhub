<?php
/**
 * GymHub - Ask a Trainer
 * pages/ask-trainer.php
 *
 * Lets logged-in members submit fitness questions to GymHub trainers.
 * Trainers respond from the admin panel at admin/qa.php.
 * Members see all their questions and responses on this page.
 *
 * Features:
 *   - Subject and body text fields for the question
 *   - Optional file attachment (JPG, PNG, PDF — max 5MB)
 *   - Displays all previous questions with inline trainer responses
 *   - Status badges: open (yellow), answered (green), closed (grey)
 *
 * File uploads are saved to public/assets/uploads/ with a unique
 * prefix to prevent filename collisions between users.
 */

$page_title       = 'Ask a Trainer | GymHub';
$page_description = 'Have a fitness question? Submit it to our GymHub certified trainers and get a personalised response within 24 hours.';
$active_nav       = '';

require_once __DIR__ . '/../config/db.php';

// Redirect guests to login with return URL
if (!is_logged_in()) {
    redirect(SITE_URL . '/pages/login.php?redirect=' . urlencode(SITE_URL . '/pages/ask-trainer.php'));
}

$user_id = $_SESSION['user_id'];
$success = '';
$errors  = [];

// ── Handle question form submission ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_question'])) {

    // Collect and trim text inputs
    $title      = trim($_POST['title'] ?? '');
    $body       = trim($_POST['body']  ?? '');
    $attachment = null; // will be set if a valid file is uploaded

    // Validate required text fields
    if (empty($title))        $errors['title'] = 'Please enter a subject for your question.';
    if (empty($body))         $errors['body']  = 'Please enter your question.';
    if (strlen($title) > 200) $errors['title'] = 'Subject must be 200 characters or fewer.';

    // ── Optional file attachment handling ─────────────────────────────────────
    if (!empty($_FILES['attachment']['name'])) {

        // Whitelist allowed MIME types — reject anything not in this list
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
        $max_size      = 5 * 1024 * 1024; // 5MB in bytes

        if (!in_array($_FILES['attachment']['type'], $allowed_types)) {
            $errors['attachment'] = 'Only JPG, PNG, GIF, and PDF files are allowed.';
        } elseif ($_FILES['attachment']['size'] > $max_size) {
            $errors['attachment'] = 'File must be under 5MB.';
        } else {
            // Build the upload directory path — go up from /pages/ to project root
            $upload_dir = __DIR__ . '/../public/assets/uploads/';

            // Create directory if it doesn't exist yet
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

            // Prefix with uniqid() to avoid filename collisions between users
            $filename = uniqid() . '_' . basename($_FILES['attachment']['name']);

            // move_uploaded_file() safely moves file from PHP temp location to our folder
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $upload_dir . $filename)) {
                $attachment = $filename; // store filename for database
            } else {
                $errors['attachment'] = 'File upload failed. Please try again.';
            }
        }
    }

    // ── Save question if no errors ────────────────────────────────────────────
    if (empty($errors)) {
        $pdo->prepare("
            INSERT INTO questions (user_id, title, body, attachment, status)
            VALUES (?, ?, ?, ?, 'open')
        ")->execute([$user_id, $title, $body, $attachment]);

        $success = 'Your question has been submitted! A trainer will respond within 24 hours.';
    }
}

// ── Load this user's questions with trainer responses ─────────────────────────
// LEFT JOIN means questions with no answer yet still appear (answer fields = NULL)
// We join users twice: once for the question author (not needed here) and
// again aliased as 'au' for the admin who wrote the answer
$stmt = $pdo->prepare("
    SELECT q.*,
           a.body       AS answer_body,
           a.created_at AS answer_date,
           CONCAT(au.first_name, ' ', au.last_name) AS answered_by
    FROM questions q
    LEFT JOIN answers a  ON a.question_id = q.id
    LEFT JOIN users au   ON a.admin_id    = au.id
    WHERE q.user_id = ?
    ORDER BY q.created_at DESC
");
$stmt->execute([$user_id]);
$questions = $stmt->fetchAll();

// ── Load instructors for the sidebar ─────────────────────────────────────────
$trainers = $pdo->query("
    SELECT i.specialties, i.rating,
           CONCAT(u.first_name, ' ', u.last_name) AS name
    FROM instructors i
    JOIN users u ON i.user_id = u.id
    ORDER BY i.rating DESC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<section class="page-hero">
    <div class="container">
        <span class="section-tag">Expert Advice</span>
        <h1>Ask a Trainer</h1>
        <p>Got a fitness question? Our certified instructors are here to help within 24 hours.</p>
    </div>
</section>

<section class="ask-trainer-page section-pad">
    <div class="container">
        <div class="ask-grid">

            <!-- ── Left: question form + history ── -->
            <div class="ask-main">

                <!-- Question submission form -->
                <div class="ask-form-card">
                    <h3>Submit a Question</h3>
                    <p style="color:var(--color-text-muted);font-size:.9rem;margin-bottom:var(--space-lg);">
                        Ask anything about training, nutrition, classes, or scheduling.
                    </p>

                    <!-- Feedback messages -->
                    <?php if ($success): ?>
                    <div class="alert alert-success flash-message"><?= h($success) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul><?php foreach ($errors as $e): ?><li><?= h($e) ?></li><?php endforeach; ?></ul>
                    </div>
                    <?php endif; ?>

                    <!-- enctype required for file uploads to work -->
                    <form method="POST" action="" enctype="multipart/form-data" class="ask-form">

                        <div class="form-group <?= isset($errors['title']) ? 'form-group--error' : '' ?>">
                            <label for="title">Question Subject *</label>
                            <!-- Repopulate value after failed submission -->
                            <input type="text" id="title" name="title"
                                   placeholder="e.g. Which class is best for weight loss?"
                                   value="<?= h($_POST['title'] ?? '') ?>"
                                   maxlength="200" required>
                            <?php if (isset($errors['title'])): ?>
                            <span class="form-error"><?= h($errors['title']) ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group <?= isset($errors['body']) ? 'form-group--error' : '' ?>">
                            <label for="body">Your Question *</label>
                            <textarea id="body" name="body" rows="5"
                                      placeholder="Describe your question in detail. More context = better advice."
                                      required><?= h($_POST['body'] ?? '') ?></textarea>
                            <?php if (isset($errors['body'])): ?>
                            <span class="form-error"><?= h($errors['body']) ?></span>
                            <?php endif; ?>
                        </div>

                        <!-- Optional file attachment — accept limits the file picker -->
                        <div class="form-group <?= isset($errors['attachment']) ? 'form-group--error' : '' ?>">
                            <label for="attachment">Attach a File <span class="optional">(optional)</span></label>
                            <input type="file" id="attachment" name="attachment"
                                   accept=".jpg,.jpeg,.png,.gif,.pdf">
                            <span class="form-hint">JPG, PNG, GIF or PDF — max 5MB</span>
                            <?php if (isset($errors['attachment'])): ?>
                            <span class="form-error"><?= h($errors['attachment']) ?></span>
                            <?php endif; ?>
                        </div>

                        <button type="submit" name="submit_question" class="btn btn-primary">
                            Submit Question
                        </button>
                    </form>
                </div>

                <!-- ── Previous questions and responses ── -->
                <?php if (!empty($questions)): ?>
                <div class="questions-list">
                    <h3>Your Questions</h3>

                    <?php foreach ($questions as $q): ?>
                    <!-- Left border colour reflects status: orange=open, green=answered -->
                    <div class="question-card question-card--<?= h($q['status']) ?>">

                        <!-- Header: title, date, status badge -->
                        <div class="question-header">
                            <div>
                                <h4><?= h($q['title']) ?></h4>
                                <span class="question-date">
                                    Asked <?= date('M j, Y', strtotime($q['created_at'])) ?>
                                </span>
                            </div>
                            <span class="status-pill status-pill--<?= h($q['status']) ?>">
                                <?= ucfirst($q['status']) ?>
                            </span>
                        </div>

                        <!-- Question body text -->
                        <p class="question-body"><?= h($q['body']) ?></p>

                        <!-- File attachment link if one was uploaded -->
                        <?php if ($q['attachment']): ?>
                        <a href="<?= SITE_URL ?>/public/assets/uploads/<?= h($q['attachment']) ?>"
                           target="_blank" class="attachment-link">📎 View Attachment</a>
                        <?php endif; ?>

                        <!-- Trainer response — green box shown when answered -->
                        <?php if ($q['answer_body']): ?>
                        <div class="trainer-answer">
                            <div class="answer-header">
                                <span>💬</span>
                                <strong>Trainer Response</strong>
                                <span class="answer-meta">
                                    by <?= h($q['answered_by']) ?>
                                    · <?= date('M j, Y', strtotime($q['answer_date'])) ?>
                                </span>
                            </div>
                            <p><?= h($q['answer_body']) ?></p>
                        </div>
                        <?php else: ?>
                        <!-- Pending message while question is awaiting response -->
                        <p class="answer-pending">⏳ Awaiting trainer response — typically within 24 hours.</p>
                        <?php endif; ?>

                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

            </div><!-- end ask-main -->

            <!-- ── Right sidebar ── -->
            <aside class="ask-sidebar">

                <div class="sidebar-card">
                    <h4>Tips for a Great Question</h4>
                    <ul class="tips-list">
                        <li>🎯 Be specific about your fitness goal</li>
                        <li>📊 Include your current fitness level</li>
                        <li>🤕 Mention any injuries or limitations</li>
                        <li>📅 Include your weekly availability</li>
                        <li>📎 Attach a photo or document if helpful</li>
                    </ul>
                </div>

                <!-- Trainer list in sidebar -->
                <div class="sidebar-card">
                    <h4>Our Trainers</h4>
                    <?php foreach ($trainers as $t): ?>
                    <div class="trainer-mini">
                        <!-- Avatar: first letter of trainer's name -->
                        <div class="trainer-mini-avatar">
                            <?= strtoupper(substr($t['name'], 0, 1)) ?>
                        </div>
                        <div>
                            <strong><?= h($t['name']) ?></strong>
                            <p><?= h($t['specialties']) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <a href="instructors.php" class="btn btn-secondary btn-sm"
                       style="margin-top:var(--space-md);width:100%;justify-content:center;">
                        View All Instructors
                    </a>
                </div>

                <div class="sidebar-card">
                    <h4>Quick Links</h4>
                    <ul class="quick-links">
                        <li><a href="classes.php">🏋️ All Classes</a></li>
                        <li><a href="<?= SITE_URL ?>/wiki/getting-started.php">📖 Getting Started Guide</a></li>
                        <li><a href="<?= SITE_URL ?>/pages/faq.php">❓ FAQ</a></li>
                    </ul>
                </div>
            </aside>

        </div>
    </div>
</section>

<style>
.page-hero{background:var(--color-surface);border-bottom:1px solid var(--color-border);padding:var(--space-2xl) 0 var(--space-xl);text-align:center}
.page-hero p{color:var(--color-text-muted);margin-top:var(--space-sm)}
.ask-grid{display:grid;grid-template-columns:1fr 300px;gap:var(--space-xl);align-items:start}
.ask-main{display:flex;flex-direction:column;gap:var(--space-lg)}
.ask-form-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl)}
.ask-form-card h3{margin-bottom:var(--space-sm)}
.ask-form{display:flex;flex-direction:column;gap:var(--space-md)}
.form-group{display:flex;flex-direction:column;gap:.35rem}
.form-group label{font-size:.875rem;font-weight:600;color:var(--color-text)}
.form-group input[type=text],.form-group input[type=file],.form-group textarea{background:var(--color-surface-2);border:1px solid var(--color-border);color:var(--color-text);padding:.65rem .9rem;border-radius:var(--radius-sm);font-family:var(--font-body);font-size:.9rem;outline:none;width:100%;transition:border-color var(--transition-fast)}
.form-group input:focus,.form-group textarea:focus{border-color:var(--color-accent)}
.form-group textarea{resize:vertical}
.form-group input[type=file]{padding:.5rem;cursor:pointer}
.form-group--error input,.form-group--error textarea{border-color:var(--color-danger)}
.form-error{color:var(--color-danger);font-size:.8rem}
.form-hint{color:var(--color-text-muted);font-size:.78rem}
.optional{color:var(--color-text-muted);font-size:.78rem;font-weight:400}
.questions-list h3{margin-bottom:var(--space-lg)}
.question-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-xl);margin-bottom:var(--space-md)}
.question-card--answered{border-left:3px solid var(--color-success)}
.question-card--open{border-left:3px solid var(--color-warning)}
.question-card--closed{border-left:3px solid var(--color-text-muted)}
.question-header{display:flex;justify-content:space-between;align-items:flex-start;gap:var(--space-md);margin-bottom:var(--space-md);flex-wrap:wrap}
.question-header h4{font-size:1rem;margin-bottom:.2rem}
.question-date{color:var(--color-text-muted);font-size:.8rem}
.question-body{color:var(--color-text-light);font-size:.9rem;line-height:1.6;margin-bottom:var(--space-md)}
.status-pill{font-family:var(--font-display);font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;padding:.2rem .6rem;border-radius:var(--radius-full);white-space:nowrap;flex-shrink:0}
.status-pill--open{background:rgba(245,158,11,.15);color:var(--color-warning)}
.status-pill--answered{background:rgba(34,197,94,.15);color:var(--color-success)}
.status-pill--closed{background:var(--color-surface-2);color:var(--color-text-muted)}
.attachment-link{color:var(--color-accent);font-size:.875rem;display:block;margin-bottom:var(--space-md)}
.trainer-answer{background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-md);padding:var(--space-md)}
.answer-header{display:flex;align-items:center;gap:var(--space-sm);margin-bottom:var(--space-sm)}
.answer-header strong{color:var(--color-text);font-size:.9rem}
.answer-meta{color:var(--color-text-muted);font-size:.8rem;margin-left:auto}
.trainer-answer p{color:var(--color-text-light);font-size:.9rem;line-height:1.6;margin:0}
.answer-pending{color:var(--color-text-muted);font-size:.85rem;font-style:italic}
.ask-sidebar{display:flex;flex-direction:column;gap:var(--space-md);position:sticky;top:90px}
.sidebar-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);padding:var(--space-lg)}
.sidebar-card h4{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--color-text-muted);margin-bottom:var(--space-md)}
.tips-list{display:flex;flex-direction:column;gap:.6rem}
.tips-list li{font-size:.875rem;color:var(--color-text-light)}
.trainer-mini{display:flex;align-items:center;gap:var(--space-sm);margin-bottom:var(--space-sm)}
.trainer-mini-avatar{width:36px;height:36px;border-radius:50%;background:var(--color-accent);color:#000;font-family:var(--font-display);font-weight:900;font-size:.9rem;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.trainer-mini strong{display:block;font-size:.875rem;color:var(--color-text)}
.trainer-mini p{font-size:.78rem;color:var(--color-text-muted);margin:0}
.quick-links{display:flex;flex-direction:column;gap:.4rem}
.quick-links a{color:var(--color-text-muted);font-size:.875rem;padding:.3rem 0;display:block;transition:color var(--transition-fast)}
.quick-links a:hover{color:var(--color-accent)}
.alert{padding:var(--space-md);border-radius:var(--radius-sm);font-size:.9rem;border:1px solid transparent;margin-bottom:var(--space-lg)}
.alert-danger{background:rgba(239,68,68,.1);border-color:var(--color-danger);color:var(--color-danger)}
.alert-success{background:rgba(34,197,94,.1);border-color:var(--color-success);color:var(--color-success)}
.alert ul{padding-left:1.2rem;margin-top:.4rem}
@media(max-width:900px){.ask-grid{grid-template-columns:1fr}.ask-sidebar{position:static}}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
