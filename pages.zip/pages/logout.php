<?php
/**
 * GymHub - Logout
 * pages/logout.php
 *
 * Destroys the session and redirects to homepage.
 * No HTML output — just PHP logic.
 */

require_once __DIR__ . '/../config/db.php';

// Destroy the session completely
$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}

session_destroy();

// Redirect to homepage with a logged-out message
redirect(SITE_URL . '/index.php?loggedout=1');
