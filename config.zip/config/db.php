<?php
/**
 * GymHub - Database Configuration File
 * config/db.php
 *
 * This is the first file that gets loaded on every single page of the site.
 * It does three important things:
 *   1. Starts output buffering (so redirects work properly on shared hosting)
 *   2. Starts the PHP session (so we can remember who is logged in)
 *   3. Connects to the MySQL database using PDO
 *
 * Every other PHP file on the site includes this one at the top:
 *   require_once __DIR__ . '/../config/db.php';
 */

// ── Output buffering ──────────────────────────────────────────────────────────
// ob_start() tells PHP to hold all output in memory before sending it to the
// browser. This is needed so that header() redirects work correctly on shared
// hosting servers like uWindsor. Without this, redirects can fail silently.
ob_start();

// ── Session start ─────────────────────────────────────────────────────────────
// Sessions let us remember data between page loads — mainly who is logged in.
// We check if a session is already running first because starting one twice
// would cause a PHP warning error.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Database credentials ──────────────────────────────────────────────────────
define('DB_HOST', 'localhost');     
define('DB_NAME', 'seehrar_gymhub');   
define('DB_USER', 'seehrar_gymhub');  
define('DB_PASS', 'COMP3077');        

// ── Site-wide URL and path constants ─────────────────────────────────────────
// SITE_URL is the full web address to the project folder.
define('SITE_URL', 'https://seehrar.myweb.cs.uwindsor.ca/project');
define('SITE_NAME', 'GymHub');

// SITE_ROOT is the absolute folder path on the server filesystem.
// dirname(__DIR__) goes one level up from /config/ to the project root.
define('SITE_ROOT', dirname(__DIR__));

// ── Connect to the database ───────────────────────────────────────────────────
// We use PDO (PHP Data Objects) which is the modern, secure way to talk to
// a MySQL database in PHP. It uses "prepared statements" which automatically
// protect against SQL injection attacks — a common security vulnerability.
try {
    $pdo = new PDO(
        // The DSN (Data Source Name) tells PDO how to connect.
        // charset=utf8mb4 supports all characters including emoji.
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            // Throw a PHP exception whenever a database error occurs.
            // This makes bugs much easier to find during development.
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,

            // Return rows as associative arrays by default.
            // This means we get $row['email'] instead of $row[2].
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

            // Use real prepared statements instead of PHP-emulated ones.
            // More secure and slightly faster on most servers.
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // If the connection fails, show a readable error instead of a blank page.
    // We escape the error message with htmlspecialchars() just to be safe —
    // we never want raw error text to create a security hole.
    die('<div style="font-family:sans-serif;padding:2rem;color:#c0392b;">
        <h2>Database Connection Error</h2>
        <p>Could not connect to the database. Please check your credentials in <code>config/db.php</code>.</p>
        <small>Error: ' . htmlspecialchars($e->getMessage()) . '</small>
    </div>');
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
//
// These small reusable functions are available on every page since this file
// is included everywhere. They are shortcuts for common tasks.
// ══════════════════════════════════════════════════════════════════════════════

/**
 * get_setting($key) — Read a setting from the database
 *
 * Looks up a value from the site_settings table. The main use case is
 * getting the active theme name so header.php can load the right CSS file.
 *
 * Example:
 *   $theme = get_setting('active_theme'); // returns 'powerzone'
 */
function get_setting(string $key): string {
    global $pdo;
    $stmt = $pdo->prepare("SELECT setting_value FROM site_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['setting_value'] : ''; // return empty string if setting not found
}

/**
 * h($str) — Safely output text into HTML
 *
 * This is a security function. It escapes special characters like < > " '
 * so they can't be interpreted as HTML tags or JavaScript.
 * This prevents XSS (Cross-Site Scripting) attacks.
 *
 * RULE: Always use h() when displaying anything from the database or forms.
 *
 * Example:
 *   echo h($user['first_name']); // SAFE — characters are escaped
 *   echo $user['first_name'];    // UNSAFE — never do this with user data
 */
function h(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/**
 * is_logged_in() — Check if someone is currently logged in
 *
 * When a user logs in we save their ID to the session. This function
 * checks if that ID exists — if it does, they're logged in.
 *
 * Example:
 *   if (is_logged_in()) { // show member dashboard }
 */
function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

/**
 * is_admin() — Check if the logged-in user is an administrator
 *
 * Checks the role stored in the session. Admins get access to the
 * admin panel and extra features regular members can't see.
 *
 * Example:
 *   if (is_admin()) { // show admin panel link in nav }
 */
function is_admin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * redirect($url) — Send the user to a different page
 *
 * Sends an HTTP Location header to redirect the browser, then stops
 * the current script with exit so no more code runs after the redirect.
 *
 * Example:
 *   redirect(SITE_URL . '/pages/login.php');
 */
function redirect(string $url): void {
    header("Location: $url");
    exit;
}
