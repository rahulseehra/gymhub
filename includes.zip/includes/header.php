<?php
/**
 * GymHub - Header Include
 * includes/header.php
 *
 * This file is included at the very top of every public-facing page.
 * It handles everything that needs to happen before the page content:
 *
 *   1. Starting the session (so we know who is logged in)
 *   2. Loading the database config (connection + helper functions)
 *   3. Determining which CSS theme to load
 *   4. Outputting the full <head> section with SEO meta tags
 *   5. Rendering the announcement bar and sticky navigation
 *   6. Optionally showing a context-sensitive help link
 *
 * HOW TO USE ON A NEW PAGE:
 * Before including this file, set these variables in your PHP page:
 *
 *   $page_title       = 'My Page Title | GymHub';   // browser tab title
 *   $page_description = 'What this page is about';  // Google search snippet
 *   $page_keywords    = 'comma, separated, keywords'; // SEO keywords
 *   $active_nav       = 'classes';                  // which nav link to highlight
 *   $help_link        = 'booking-guide.php';        // optional wiki link filename
 *   $help_text        = 'Read the booking guide';   // optional help bar text
 *
 * Then include the file:
 *   require_once __DIR__ . '/../includes/header.php';
 */

// ── Session start ─────────────────────────────────────────────────────────────
// We need the session running before anything else so is_logged_in() works.
// The check prevents starting a second session if one is already active.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Load database config ──────────────────────────────────────────────────────
// This gives us $pdo (database connection), SITE_URL, and all helper functions.
// dirname(__DIR__) goes up one folder level from /includes/ to the project root.
require_once dirname(__DIR__) . '/config/db.php';

// ── Get the active theme from the database ────────────────────────────────────
// The admin can change this from admin/theme.php.
// get_setting() reads the site_settings table and returns the value.
// We default to 'powerzone' in case the setting hasn't been set yet.
$active_theme = get_setting('active_theme') ?: 'powerzone';

// ── Default SEO values ────────────────────────────────────────────────────────
// If the page hasn't set these variables, we use sensible defaults.
// The ?? operator means "use this value if the variable doesn't exist".
$page_title       = $page_title       ?? 'GymHub — Train Harder. Live Better.';
$page_description = $page_description ?? 'GymHub offers world-class fitness classes, personal training, and gym memberships. Book a class today and start your fitness journey.';
$page_keywords    = $page_keywords    ?? 'gym, fitness classes, personal training, membership, HIIT, yoga, CrossFit, Windsor';
$active_nav       = $active_nav       ?? ''; // empty string means no nav link is active
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ── Character encoding and viewport ── -->
    <!-- UTF-8 supports all characters. viewport meta makes the site responsive on phones. -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- ── Basic SEO meta tags ── -->
    <!-- title: shown in the browser tab and Google search results -->
    <title><?= h($page_title) ?></title>
    <!-- description: the snippet shown under your link in Google search -->
    <meta name="description" content="<?= h($page_description) ?>">
    <!-- keywords: less important for Google today but still good practice -->
    <meta name="keywords"    content="<?= h($page_keywords) ?>">
    <meta name="author"      content="GymHub">
    <!-- robots: tells search engines to index this page and follow its links -->
    <meta name="robots"      content="index, follow">

    <!-- ── Open Graph meta tags ── -->
    <!-- These control how the page looks when shared on Facebook, LinkedIn etc. -->
    <meta property="og:title"       content="<?= h($page_title) ?>">
    <meta property="og:description" content="<?= h($page_description) ?>">
    <meta property="og:type"        content="website">
    <meta property="og:url"         content="<?= SITE_URL ?>">
    <meta property="og:image"       content="<?= SITE_URL ?>/public/assets/images/og-image.jpg">

    <!-- ── Favicon ── -->
    <!-- The small icon shown in the browser tab and bookmarks -->
    <link rel="icon" type="image/png" href="<?= SITE_URL ?>/public/assets/images/favicon.png">
    <!-- Larger icon used when adding to iPhone home screen -->
    <link rel="apple-touch-icon"      href="<?= SITE_URL ?>/public/assets/images/apple-touch-icon.png">

    <!-- ── Google Fonts ── -->
    <!-- Barlow Condensed: used for headlines, nav, badges — bold and tight -->
    <!-- Barlow: used for body text and forms — clean and readable -->
    <!-- preconnect speeds up the font loading by establishing the connection early -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- ── Main stylesheet ── -->
    <!-- Contains all base styles, layout, components, and animations -->
    <link rel="stylesheet" href="<?= SITE_URL ?>/public/css/main.css">

    <!-- ── Active theme stylesheet ── -->
    <!-- Loaded after main.css so its variables override the defaults.
         The filename changes based on what the admin has selected.
         e.g. theme-powerzone.css, theme-zenfit.css, theme-bluesteel.css -->
    <link rel="stylesheet" id="theme-stylesheet"
          href="<?= SITE_URL ?>/public/css/theme-<?= h($active_theme) ?>.css">
</head>

<!-- The theme class on body (e.g. theme-powerzone) allows theme-specific
     CSS rules to target elements when needed -->
<body class="theme-<?= h($active_theme) ?>">

<!-- ════════════════════════════════════════════════════════════════════
     ANNOUNCEMENT BAR
     The thin strip at the very top. Used for promotions and notices.
     To change the message, edit the text inside the div below.
     ════════════════════════════════════════════════════════════════════ -->
<div class="announcement-bar">
    🔥 New classes added weekly —
    <a href="<?= SITE_URL ?>/pages/classes.php">Browse the schedule</a>
</div>

<!-- ════════════════════════════════════════════════════════════════════
     STICKY NAVIGATION
     Stays at the top of the screen as the user scrolls.
     The hamburger button (hidden on desktop) toggles the mobile menu.
     JS in main.js handles the open/close behaviour.
     ════════════════════════════════════════════════════════════════════ -->
<header class="site-header" id="site-header">
    <nav class="navbar" role="navigation" aria-label="Main navigation">

        <!-- Logo — links back to the homepage -->
        <a href="<?= SITE_URL ?>/index.php" class="nav-logo" aria-label="GymHub Home">
            <span class="logo-icon">⚡</span>
            <span class="logo-text">GYM<strong>HUB</strong></span>
        </a>

        <!-- Desktop navigation links -->
        <!-- The 'active' class is added to the current page's link
             based on the $active_nav variable set by each page -->
        <ul class="nav-links" id="nav-links">
            <li>
                <a href="<?= SITE_URL ?>/index.php"
                   class="<?= $active_nav === 'home' ? 'active' : '' ?>">
                    Home
                </a>
            </li>
            <li>
                <a href="<?= SITE_URL ?>/pages/classes.php"
                   class="<?= $active_nav === 'classes' ? 'active' : '' ?>">
                    Classes
                </a>
            </li>
            <li>
                <a href="<?= SITE_URL ?>/pages/membership.php"
                   class="<?= $active_nav === 'membership' ? 'active' : '' ?>">
                    Membership
                </a>
            </li>
            <li>
                <a href="<?= SITE_URL ?>/pages/instructors.php"
                   class="<?= $active_nav === 'instructors' ? 'active' : '' ?>">
                    Instructors
                </a>
            </li>
            <li>
                <a href="<?= SITE_URL ?>/pages/schedule.php"
                   class="<?= $active_nav === 'schedule' ? 'active' : '' ?>">
                    Schedule
                </a>
            </li>
            <li>
                <a href="<?= SITE_URL ?>/pages/locations.php"
                   class="<?= $active_nav === 'locations' ? 'active' : '' ?>">
                    Locations
                </a>
            </li>

            <!-- These links only show when the user is logged in -->
            <?php if (is_logged_in()): ?>
            <li class="nav-dropdown">
                <!-- Dropdown toggle shows the user's first name -->
                <a href="#" class="nav-dropdown-toggle">
                    👤 <?= h($_SESSION['first_name']) ?> ▾
                </a>
                <!-- Dropdown menu — shown on hover via CSS -->
                <ul class="dropdown-menu">
                    <li><a href="<?= SITE_URL ?>/pages/profile.php">My Profile</a></li>
                    <li><a href="<?= SITE_URL ?>/pages/bookings.php">My Bookings</a></li>
                    <li><a href="<?= SITE_URL ?>/pages/progress.php">Progress Tracker</a></li>
                    <li><a href="<?= SITE_URL ?>/pages/ask-trainer.php">Ask a Trainer</a></li>
                    <!-- Admin panel link only shows for admin users -->
                    <?php if (is_admin()): ?>
                    <li class="dropdown-divider"></li>
                    <li><a href="<?= SITE_URL ?>/admin/dashboard.php">⚙ Admin Panel</a></li>
                    <?php endif; ?>
                    <li class="dropdown-divider"></li>
                    <li><a href="<?= SITE_URL ?>/pages/logout.php">Log Out</a></li>
                </ul>
            </li>

            <?php else: ?>
            <!-- These links only show when the user is NOT logged in -->
            <li>
                <a href="<?= SITE_URL ?>/pages/login.php"
                   class="<?= $active_nav === 'login' ? 'active' : '' ?>">
                    Log In
                </a>
            </li>
            <li>
                <!-- nav-cta gives this link the filled orange button style -->
                <a href="<?= SITE_URL ?>/pages/register.php" class="nav-cta">
                    Join Now
                </a>
            </li>
            <?php endif; ?>
        </ul>

        <!-- Mobile hamburger button — only visible on small screens -->
        <!-- The three <span> elements are the three horizontal lines.
             JavaScript animates them into an X when the menu is open. -->
        <button class="nav-hamburger" id="nav-hamburger"
                aria-label="Toggle mobile menu" aria-expanded="false">
            <span></span>
            <span></span>
            <span></span>
        </button>

    </nav>
</header>

<!-- ════════════════════════════════════════════════════════════════════
     MAIN CONTENT AREA
     All page-specific content is rendered after this opening tag.
     The matching </main> closing tag is in footer.php.
     ════════════════════════════════════════════════════════════════════ -->
<main id="main-content">

<?php
// ── Context-sensitive help bar ────────────────────────────────────────────────
// If a page has set $help_link and $help_text, show a small banner at the top
// linking to the relevant wiki help page. This satisfies the "context-sensitive
// help link" requirement. Pages opt in by setting these variables before
// including header.php.
//
// Example usage in a page:
//   $help_link = 'booking-guide.php';
//   $help_text = 'How does booking work? Read the Booking Guide';
if (!empty($help_link) && !empty($help_text)):
?>
<div class="help-bar">
    <span>💡 Need help?</span>
    <a href="<?= SITE_URL ?>/wiki/<?= h($help_link) ?>"><?= h($help_text) ?></a>
</div>
<?php endif; ?>
