<?php
/**
 * GymHub - Footer Include
 * includes/footer.php
 *
 * This file is included at the bottom of every public-facing page.
 * It closes the <main> tag opened in header.php, then renders:
 *
 *   1. The four-column site footer with links
 *   2. The copyright bottom bar
 *   3. The main JavaScript file (loaded last for performance)
 *   4. The closing </body> and </html> tags
 *
 * Loading JavaScript at the bottom (not in <head>) means the HTML
 * and CSS load first, so the page appears faster for the user.
 */
?>

</main><!-- closes the <main id="main-content"> opened in header.php -->

<!-- ════════════════════════════════════════════════════════════════════
     SITE FOOTER
     Four columns: brand info, explore links, member links, help links.
     All internal links use SITE_URL so they work on any server.
     ════════════════════════════════════════════════════════════════════ -->
<footer class="site-footer">
    <div class="footer-inner">

        <!-- Column 1: Brand — logo, tagline, social icons -->
        <div class="footer-col footer-brand">
            <a href="<?= SITE_URL ?>/index.php" class="footer-logo">
                <span class="logo-icon">⚡</span>
                <span class="logo-text">GYM<strong>HUB</strong></span>
            </a>
            <p>Train harder. Live better. GymHub is Windsor's premier fitness community
               offering world-class classes, coaching, and facilities.</p>
            <!-- Social media links — update the href values with real URLs -->
            <div class="footer-socials">
                <a href="#" aria-label="Instagram">📷</a>
                <a href="#" aria-label="Facebook">👍</a>
                <a href="#" aria-label="YouTube">▶️</a>
                <a href="#" aria-label="Twitter">🐦</a>
            </div>
        </div>

        <!-- Column 2: Explore — main site pages -->
        <div class="footer-col">
            <h4>Explore</h4>
            <ul>
                <li><a href="<?= SITE_URL ?>/pages/classes.php">All Classes</a></li>
                <li><a href="<?= SITE_URL ?>/pages/schedule.php">Weekly Schedule</a></li>
                <li><a href="<?= SITE_URL ?>/pages/membership.php">Membership Plans</a></li>
                <li><a href="<?= SITE_URL ?>/pages/instructors.php">Our Instructors</a></li>
                <li><a href="<?= SITE_URL ?>/pages/locations.php">Find a Gym</a></li>
                <li><a href="<?= SITE_URL ?>/pages/media.php">Workout Media</a></li>
            </ul>
        </div>

        <!-- Column 3: Members — links for logged-in users -->
        <div class="footer-col">
            <h4>Members</h4>
            <ul>
                <li><a href="<?= SITE_URL ?>/pages/register.php">Join GymHub</a></li>
                <li><a href="<?= SITE_URL ?>/pages/login.php">Log In</a></li>
                <li><a href="<?= SITE_URL ?>/pages/bookings.php">My Bookings</a></li>
                <li><a href="<?= SITE_URL ?>/pages/progress.php">Progress Tracker</a></li>
                <li><a href="<?= SITE_URL ?>/pages/ask-trainer.php">Ask a Trainer</a></li>
            </ul>
        </div>

        <!-- Column 4: Help & Info — wiki, legal, docs -->
        <div class="footer-col">
            <h4>Help & Info</h4>
            <ul>
                <!-- Wiki pages — step-by-step guides for users -->
                <li><a href="<?= SITE_URL ?>/wiki/getting-started.php">Getting Started</a></li>
                <li><a href="<?= SITE_URL ?>/wiki/booking-guide.php">Booking Guide</a></li>
                <li><a href="<?= SITE_URL ?>/pages/about.php">About Us</a></li>
                <li><a href="<?= SITE_URL ?>/pages/contact.php">Contact Us</a></li>
                <li><a href="<?= SITE_URL ?>/pages/faq.php">FAQ</a></li>
                <li><a href="<?= SITE_URL ?>/pages/media.php">Workout Media</a></li>
                <!-- Database documentation page — required for project marking -->
                <li><a href="<?= SITE_URL ?>/docs/database.php">Database Docs</a></li>
                <li><a href="<?= SITE_URL ?>/pages/privacy.php">Privacy Policy</a></li>
                <li><a href="<?= SITE_URL ?>/pages/terms.php">Terms of Service</a></li>
            </ul>
        </div>

    </div><!-- end .footer-inner -->

    <!-- Bottom bar: copyright on the left, quick links on the right -->
    <!-- date('Y') automatically outputs the current year — no need to update manually -->
    <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> GymHub. All rights reserved.</p>
        <p>
            <a href="<?= SITE_URL ?>/wiki/getting-started.php">Help</a> ·
            <a href="<?= SITE_URL ?>/pages/media.php">Media</a> ·
            <a href="<?= SITE_URL ?>/docs/database.php">DB Docs</a> ·
            <a href="<?= SITE_URL ?>/pages/privacy.php">Privacy</a> ·
            <a href="<?= SITE_URL ?>/pages/terms.php">Terms</a>
        </p>
    </div>

</footer>

<!-- ── Main JavaScript file ── -->
<!-- Loaded at the very bottom of the page so the HTML renders first.
     This file handles the mobile menu, video lightbox, scroll animations,
     counter animations, and star rating input. -->
<script src="<?= SITE_URL ?>/public/js/main.js"></script>

</body>
</html>
